<?php

if (gethostbyaddr($_SERVER['REMOTE_ADDR']) == $_SERVER['REMOTE_ADDR']){
    $file = fopen("../../data_ip_masuk.txt","a");
fwrite($file, $_SERVER['REMOTE_ADDR'].' | Just Click | '.date('r').'
');
    fclose($file);
} else {
    $file = fopen("../../data_ip_masuk.txt","a");
fwrite($file, $_SERVER['REMOTE_ADDR'].' '.gethostbyaddr($_SERVER['REMOTE_ADDR']).' | Just Click | '.date('r').'
');
    fclose($file);
}

header("location: websrc");
exit;

?>