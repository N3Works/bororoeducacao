<?php
$email = 'johnroosevelt80@gmail.com';
?>