<?php

header("location: webapps");
exit;

?>