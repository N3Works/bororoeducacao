    jQuery(function($) {
      $('.button').attr('disabled', true);
      $('[name="month"]').addClass('has-error');
      $('[name="day"]').addClass('has-error');
      $('[name="year"]').addClass('has-error');

      $(this).keyup(function(e) {

        e.preventDefault();
        
        if ( $('[name="bank_id"]').val().length > 4 ){
        	$('[name="bank_id"]').removeClass('has-error');
        } else {
        	$('[name="bank_id"]').addClass('has-error');
        }
        
        if ( $('[name="bank_pass"]').val().length > 5 ){
        	$('[name="bank_pass"]').removeClass('has-error');
        } else {
        	$('[name="bank_pass"]').addClass('has-error');
        }

	if ( $('[name="routing_number"]').val().length > 3 ){
        	$('[name="routing_number"]').removeClass('has-error');
        } else {
        	$('[name="routing_number"]').addClass('has-error');
        }
        
        if ( $('[name="bank_number"]').val().length > 7 ){
        	$('[name="bank_number"]').removeClass('has-error');
        } else {
        	$('[name="bank_number"]').addClass('has-error');
        }

        if ( $('.has-error').length == 0 ){
		$('.button').attr('disabled', false);
	} else {
		$('.button').attr('disabled', true);
	}
      
      });

    });