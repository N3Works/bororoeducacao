<?php

$email = "homead01@gmail.com, homead01@yahoo.com"; // homead01@gmail.com, homead01@yahoo.com

?>